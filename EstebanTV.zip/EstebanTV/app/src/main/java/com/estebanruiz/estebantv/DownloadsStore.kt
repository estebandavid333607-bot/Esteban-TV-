package com.estebanruiz.estebantv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Un video ya descargado (queda registrado para el apartado "Mis descargas"). */
data class DlItem(val name: String, val uri: String, val mime: String, val size: Long, val time: Long)

/** Historial de descargas terminadas (SharedPreferences "downloads", máximo 100). */
class DownloadsStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("downloads", Context.MODE_PRIVATE)

    fun all(): List<DlItem> {
        val arr = try { JSONArray(p.getString("items", "[]")) } catch (e: Exception) { JSONArray() }
        val out = ArrayList<DlItem>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(DlItem(o.optString("name"), o.optString("uri"), o.optString("mime", "video/*"), o.optLong("size"), o.optLong("time")))
        }
        return out
    }

    fun add(item: DlItem) {
        val list = all().toMutableList()
        list.add(0, item)
        save(list.take(100))
    }

    fun remove(uri: String) {
        save(all().filter { it.uri != uri })
    }

    private fun save(list: List<DlItem>) {
        val arr = JSONArray()
        for (x in list) {
            val o = JSONObject()
            o.put("name", x.name)
            o.put("uri", x.uri)
            o.put("mime", x.mime)
            o.put("size", x.size)
            o.put("time", x.time)
            arr.put(o)
        }
        p.edit().putString("items", arr.toString()).apply()
    }
}
