package com.estebanruiz.estebantv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Películas que se dejaron a medias ("Seguir viendo") o guardadas para más tarde (posición 0).
 * Se guardan por la dirección de la página de la película (SharedPreferences "movieprogress").
 */
class MovieProgress(ctx: Context) {
    data class Entry(val movie: Movie, val posMs: Long, val durMs: Long, val ts: Long)

    private val p = ctx.getSharedPreferences("movieprogress", Context.MODE_PRIVATE)

    fun all(): List<Entry> {
        val out = ArrayList<Entry>()
        try {
            val arr = JSONArray(p.getString("list", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Entry(
                        Movie(
                            o.optString("id"), o.optString("title"), o.optString("year"), o.optString("genre"),
                            o.optString("quality"), o.optString("lang"), o.optString("synopsis"),
                            o.optString("cover"), o.optString("url")
                        ),
                        o.optLong("pos"), o.optLong("dur"), o.optLong("ts")
                    )
                )
            }
        } catch (e: Exception) {
        }
        return out.sortedByDescending { it.ts }
    }

    fun get(url: String): Entry? = all().firstOrNull { it.movie.url == url }

    fun save(m: Movie, posMs: Long, durMs: Long) {
        if (m.url.isEmpty()) return
        val old = get(m.url)?.movie
        // Si esta película llegó con datos incompletos (p. ej. desde "Seguir viendo" del inicio), se conservan los guardados.
        val keep = if (old != null && m.cover.isEmpty()) old else m
        val list = all().filter { it.movie.url != m.url }.toMutableList()
        list.add(0, Entry(keep, posMs, durMs, System.currentTimeMillis()))
        write(list.take(40))
    }

    fun remove(url: String) = write(all().filter { it.movie.url != url })

    private fun write(list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { e ->
            arr.put(
                JSONObject()
                    .put("id", e.movie.id).put("title", e.movie.title).put("year", e.movie.year)
                    .put("genre", e.movie.genre).put("quality", e.movie.quality).put("lang", e.movie.lang)
                    .put("synopsis", e.movie.synopsis).put("cover", e.movie.cover).put("url", e.movie.url)
                    .put("pos", e.posMs).put("dur", e.durMs).put("ts", e.ts)
            )
        }
        p.edit().putString("list", arr.toString()).apply()
    }
}
