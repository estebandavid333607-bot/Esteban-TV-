package com.estebanruiz.estebantv

/** Ayudas del "Reproductor m3u8": limpiar el enlace pegado y reconocer si parece una transmisión. */
object StreamKinds {
    private val SCHEMES = setOf("http", "https", "rtmp", "rtmps", "rtmpe", "rtmpt", "rtsp", "rtsps", "udp")

    /** Deja el texto pegado como enlace usable ("" si no sirve). */
    fun normalize(raw: String): String {
        var t = raw.trim().trim('"', '\'', '<', '>')
        t = t.split(Regex("\\s+")).firstOrNull().orEmpty()
        if (t.isEmpty()) return ""
        if (!t.contains("://")) t = "https://$t"
        val scheme = t.substringBefore("://").lowercase()
        return if (scheme in SCHEMES && t.substringAfter("://").isNotEmpty()) t else ""
    }

    fun looksLikeStream(t: String): Boolean {
        val s = t.trim().lowercase()
        if (!Regex("^(https?|rtmps?|rtsps?|udp)://\\S+$").matches(s)) return false
        return Regex("\\.(m3u8?|mpd|ism|ts|mp4|mkv|flv|webm|aac|mp3)(\\?|$|/)|^(rtmp|rtsp|udp)").containsMatchIn(s)
    }
}
