package com.estebanruiz.estebantv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

data class Channel(val id: String, val name: String, val logoUrl: String, val url: String)

/** Canales de TV que agrega el usuario: nombre, imagen (logo) y URL del video. Todo queda guardado en el celular. */
class ChannelStore(context: Context) {

    private val ctx = context.applicationContext
    private val prefs = ctx.getSharedPreferences("tv_channels", Context.MODE_PRIVATE)
    private val dir = File(ctx.filesDir, "tv").apply { mkdirs() }
    private val cache = HashMap<String, Bitmap>()
    private val io = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    companion object {
        /** Reduce la imagen a 256 px como máximo para ahorrar memoria. */
        fun scale(b: Bitmap): Bitmap {
            val m = maxOf(b.width, b.height)
            if (m <= 256) return b
            val f = 256f / m
            return Bitmap.createScaledBitmap(b, (b.width * f).toInt().coerceAtLeast(1), (b.height * f).toInt().coerceAtLeast(1), true)
        }
    }

    /** Canales incluidos en la app + los que agregó el usuario. */
    fun all(): List<Channel> = DefaultChannels.list + user()

    fun isBuiltin(id: String) = DefaultChannels.list.any { it.id == id }

    private fun user(): List<Channel> {
        val out = ArrayList<Channel>()
        try {
            val arr = JSONArray(prefs.getString("list", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Channel(o.getString("id"), o.getString("name"), o.optString("logo"), o.getString("url")))
            }
        } catch (e: Exception) {
            // lista corrupta: se ignora
        }
        return out
    }

    /** Agrega el canal o, si ya existe ese id, lo reemplaza. */
    fun put(c: Channel) {
        val list = user()
        val exists = list.any { it.id == c.id }
        save(if (exists) list.map { if (it.id == c.id) c else it } else list + c)
    }

    fun remove(id: String) {
        save(user().filter { it.id != id })
        cache.remove(id)
        File(dir, "$id.png").delete()
    }

    private fun save(list: List<Channel>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("logo", it.logoUrl).put("url", it.url))
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    @Synchronized
    fun logo(id: String): Bitmap? {
        cache[id]?.let { return it }
        val f = File(dir, "$id.png")
        if (f.exists()) {
            val b = BitmapFactory.decodeFile(f.absolutePath) ?: return null
            cache[id] = b
            return b
        }
        // Canal incluido con imagen dentro de la app: "res:nombre"
        val ch = DefaultChannels.list.firstOrNull { it.id == id }
        if (ch != null && ch.logoUrl.startsWith("res:")) {
            val resId = ctx.resources.getIdentifier(ch.logoUrl.removePrefix("res:"), "drawable", ctx.packageName)
            if (resId != 0) {
                val b = BitmapFactory.decodeResource(ctx.resources, resId) ?: return null
                cache[id] = b
                return b
            }
        }
        return null
    }

    @Synchronized
    fun saveLogo(id: String, b: Bitmap) {
        try {
            File(dir, "$id.png").outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
            cache[id] = b
        } catch (e: Exception) {
            // sin espacio: se ignora
        }
    }

    /** Descarga la imagen desde una URL en segundo plano; [done] se llama en el hilo principal. */
    fun downloadLogo(id: String, url: String, done: (Boolean) -> Unit) {
        io.execute {
            var ok = false
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                c.instanceFollowRedirects = true
                c.setRequestProperty("User-Agent", "Mozilla/5.0")
                if (c.responseCode == 200) {
                    val b = c.inputStream.use { BitmapFactory.decodeStream(it) }
                    if (b != null) {
                        saveLogo(id, scale(b))
                        ok = true
                    }
                }
            } catch (e: Exception) {
                // sin conexión o URL mala
            }
            main.post { done(ok) }
        }
    }
}
