package com.estebanruiz.estebantv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Marcador de un partido. [state]: "pre" = no empieza, "in" = en juego, "post" = terminado. */
data class Score(
    val home: String, val away: String,
    val homeGoals: Int, val awayGoals: Int,
    val state: String, val detail: String, val epochMs: Long
)

/** Guarda los últimos marcadores descargados (SharedPreferences "scores"). */
class ScoreStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("scores", Context.MODE_PRIVATE)

    fun all(): List<Score> {
        val raw = p.getString("data", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Score(
                    o.optString("h"), o.optString("a"), o.optInt("hg"), o.optInt("ag"),
                    o.optString("s"), o.optString("d"), o.optLong("t")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(list: List<Score>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("h", it.home).put("a", it.away).put("hg", it.homeGoals).put("ag", it.awayGoals)
                    .put("s", it.state).put("d", it.detail).put("t", it.epochMs)
            )
        }
        p.edit().putString("data", arr.toString()).apply()
    }
}

/**
 * Baja los marcadores de la API pública de ESPN (sin clave). Es una fuente no oficial: puede cambiar o no traer
 * todas las ligas. Si un partido no aparece, en la Agenda sale "Terminado" sin resultado.
 * Para agregar una liga, suma su código a [LEAGUES] (ej. "col.1" = Liga colombiana).
 */
object ScoreFetcher {
    private val LEAGUES = listOf(
        "all", "uefa.nations", "concacaf.nations.league", "fifa.friendly", "uefa.champions", "uefa.europa",
        "conmebol.libertadores", "conmebol.sudamericana", "eng.1", "esp.1", "ita.1", "ger.1", "fra.1",
        "arg.1", "bra.1", "col.1", "mex.1", "chi.1", "per.1", "ecu.1", "uru.1", "usa.1"
    )

    private val DATE_FMT = arrayOf("yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'")

    private fun parseDate(s: String): Long {
        for (f in DATE_FMT) {
            try {
                val df = SimpleDateFormat(f, Locale.US)
                df.timeZone = TimeZone.getTimeZone("UTC")
                return df.parse(s)?.time ?: continue
            } catch (e: Exception) { }
        }
        return -1L
    }

    private fun get(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13)")
            if (c.responseCode !in 200..299) null else c.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        } finally {
            c.disconnect()
        }
    }

    fun parseBoard(json: String, out: MutableList<Score>) {
        try {
            val evs = JSONObject(json).optJSONArray("events") ?: return
            for (i in 0 until evs.length()) {
                val e = evs.optJSONObject(i) ?: continue
                val comp = e.optJSONArray("competitions")?.optJSONObject(0) ?: continue
                val cs = comp.optJSONArray("competitors") ?: continue
                var home = ""; var away = ""; var hg = 0; var ag = 0
                for (j in 0 until cs.length()) {
                    val c = cs.optJSONObject(j) ?: continue
                    val name = c.optJSONObject("team")?.optString("displayName").orEmpty()
                    val goals = c.optString("score").toIntOrNull() ?: 0
                    if (c.optString("homeAway") == "away") { away = name; ag = goals } else { home = name; hg = goals }
                }
                if (home.isEmpty() || away.isEmpty()) continue
                val type = e.optJSONObject("status")?.optJSONObject("type")
                val state = type?.optString("state").orEmpty()
                val detail = type?.optString("shortDetail").orEmpty()
                out.add(Score(home, away, hg, ag, state, detail, parseDate(e.optString("date"))))
            }
        } catch (e: Exception) { }
    }

    /** Llamar desde un hilo de fondo. Devuelve null si no llegó ningún marcador. */
    fun fetch(): List<Score>? {
        val df = SimpleDateFormat("yyyyMMdd", Locale.US)
        val from = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        val to = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
        val range = df.format(from.time) + "-" + df.format(to.time)
        val pool = Executors.newFixedThreadPool(6)
        val out = ArrayList<Score>()
        try {
            val jobs = LEAGUES.map { lg ->
                pool.submit(Callable<String?> {
                    get("https://site.api.espn.com/apis/site/v2/sports/soccer/$lg/scoreboard?dates=$range&limit=300")
                })
            }
            jobs.forEach { j ->
                val body = try { j.get(25, TimeUnit.SECONDS) } catch (e: Exception) { null }
                if (body != null) parseBoard(body, out)
            }
        } finally {
            pool.shutdownNow()
        }
        val unique = out.distinctBy { it.home + "|" + it.away + "|" + it.epochMs / 3_600_000L }
        return if (unique.isEmpty()) null else unique
    }

    /** Marcador de un evento de la Agenda (nombre tipo "Liga: A vs B"); [flipped] = los equipos van al revés que en la Agenda. */
    class Match(val score: Score, val goalsFirst: Int, val goalsSecond: Int)

    fun find(scores: List<Score>, title: String, eventEpoch: Long?): Match? {
        val clean = title.replace(AgendaFetcher.OPC2, "").trim()
        val cands = scores.filter { AgendaFetcher.sameMatch(clean, it.home + " vs " + it.away) }
        if (cands.isEmpty()) return null
        val s = if (eventEpoch != null && cands.size > 1)
            cands.minByOrNull { if (it.epochMs < 0) Long.MAX_VALUE else Math.abs(it.epochMs - eventEpoch) }!!
        else cands[0]
        // Un mismo partido no se juega dos veces en 3 días: si la hora difiere más de 20 h, no es este.
        if (eventEpoch != null && s.epochMs > 0 && Math.abs(s.epochMs - eventEpoch) > 20 * 3_600_000L) return null
        val firstIsHome = AgendaFetcher.firstTeamIs(clean, s.home)
        return if (firstIsHome) Match(s, s.homeGoals, s.awayGoals) else Match(s, s.awayGoals, s.homeGoals)
    }
}
