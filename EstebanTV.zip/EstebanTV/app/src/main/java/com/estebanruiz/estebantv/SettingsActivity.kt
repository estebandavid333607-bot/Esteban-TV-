package com.estebanruiz.estebantv

import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

/** Pantalla de Ajustes: se abre desde el menú de los 3 puntos. Todo se guarda en las preferencias "settings". */
class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var list: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val zoomValues = listOf(80, 100, 120, 150, 180)
    private val zoomLabels = listOf("Muy pequeño (80%)", "Normal (100%)", "Grande (120%)", "Muy grande (150%)", "Enorme (180%)")
    private val qualValues = listOf(0, 1080, 720, 480, 360)
    private val qualLabels = listOf("Sin límite", "Hasta 1080p", "Hasta 720p", "Hasta 480p", "Hasta 360p (ahorra datos)")

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = Prefs.of(this)
        setTheme(Palettes.themeFor(prefs.getInt(Prefs.PALETTE, 0)))
        super.onCreate(savedInstanceState)
        requestedOrientation = Prefs.orientationFlag(prefs.getInt(Prefs.ORIENT, 0))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(attrColor(R.attr.etvBg))
        }

        // Barra superior con flecha de regreso
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = ColorDrawable(attrColor(R.attr.etvSurface))
            setPadding(dp(6), dp(6), dp(16), dp(6))
        }
        bar.addView(ImageButton(this).apply {
            setImageResource(R.drawable.ic_back)
            background = selectableBg()
            contentDescription = "Volver"
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
            setOnClickListener { finish() }
        })
        bar.addView(TextView(this).apply {
            text = "Ajustes"
            setTextColor(attrColor(R.attr.etvAccent))
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(8), 0, 0, 0)
        })
        root.addView(bar)

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(24))
        }
        root.addView(
            ScrollView(this).apply { addView(list) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)

        buildRows()
    }

    private fun selectableBg(): Drawable? {
        val a = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackground))
        val d = a.getDrawable(0)
        a.recycle()
        return d
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ contenido

    private fun buildRows() {
        section("APARIENCIA")
        paletteRow()
        choiceRow(
            "Rotación de pantalla", Prefs.ORIENT, 0, (0..4).toList(), Prefs.orientLabels
        ) { requestedOrientation = Prefs.orientationFlag(it) }
        choiceRow("Tamaño del texto de las páginas", Prefs.TEXT_ZOOM, 100, zoomValues, zoomLabels)
        switchRow("Pantalla completa", "Oculta la barra de estado y la de navegación", Prefs.IMMERSIVE, false)
        switchRow("Mantener pantalla encendida", "No se apaga mientras usas la app", Prefs.KEEP_ON, false)

        section("NAVEGACIÓN")
        choiceRow(
            "Buscador", Prefs.ENGINE, 0, Prefs.engines.indices.toList(), Prefs.engines.map { it.name }
        )
        switchRow("Recordar última página", "Al abrir la app vuelves a donde te quedaste", Prefs.RESTORE_LAST, true)
        switchRow("Modo escritorio", "Pide la versión de PC de los sitios", Prefs.DESKTOP, false)
        switchRow("Ocultar imágenes", "Ahorra datos; las páginas cargan más rápido", Prefs.NO_IMAGES, false)
        switchRow("JavaScript", "Apagarlo rompe muchas páginas y sus videos", Prefs.JS, true)
        switchRow("Cookies de terceros", "Necesarias para algunos inicios de sesión", Prefs.THIRD_COOKIES, true)

        section("ANUNCIOS Y VIDEO")
        switchRow("Bloquear popups y anuncios", "Filtra dominios de publicidad y ventanas emergentes", Prefs.BLOCK_ADS, true)
        switchRow("Abrir videos en ExoPlayer", "Detecta .m3u8, .mpd y .mp4 en las páginas", Prefs.AUTO_PLAYER, true)
        switchRow("Preguntar antes de abrir ExoPlayer", "Muestra el aviso Sí / No con el video detectado", Prefs.ASK_PLAYER, true)
        choiceRow("Resolución máxima en ExoPlayer", Prefs.MAX_QUALITY, 0, qualValues, qualLabels)

        section("PRIVACIDAD Y DATOS")
        actionRow("Borrar cookies y datos de sitios", "Cierra tus sesiones en todas las webs") {
            confirm("Borrar cookies y datos", "Se cerrarán tus sesiones en los sitios.") {
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                WebStorage.getInstance().deleteAllData()
                toast("Cookies y datos borrados")
            }
        }
        actionRow("Borrar caché", "Libera espacio ocupado por páginas guardadas") {
            val w = WebView(this)
            w.clearCache(true)
            w.destroy()
            toast("Caché borrada")
        }
        actionRow("Borrar imágenes de favoritos", "Se vuelven a descargar cuando hagan falta") {
            FaviconStore(this).clearAll()
            toast("Imágenes borradas")
        }
        actionRow("Olvidar la última página", "La próxima vez la app abre en el inicio") {
            prefs.edit().remove(Prefs.LAST_URL).apply()
            toast("Listo")
        }
        actionRow("Borrar todos los favoritos", "No se puede deshacer") {
            confirm("Borrar favoritos", "Se eliminarán todos los favoritos del inicio.") {
                FavoritesStore(this).clear()
                toast("Favoritos borrados")
            }
        }

        section("OTROS")
        actionRow("Restablecer ajustes", "Vuelve todo a los valores originales (los favoritos se conservan)") {
            confirm("Restablecer ajustes", "Se restauran todas las opciones de esta pantalla.") {
                prefs.edit().clear().apply()
                recreate()
            }
        }
        actionRow("Acerca de", "Esteban TV · versión ${appVersion()} · Hecho por: Esteban Ruiz") {}
    }

    private fun appVersion(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"
    } catch (e: Exception) {
        "1.0"
    }

    // ------------------------------------------------------------------ filas

    private fun section(label: String) {
        list.addView(TextView(this).apply {
            text = label
            setTextColor(attrColor(R.attr.etvAccent))
            textSize = 12f
            letterSpacing = 0.15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(16), dp(24), dp(16), dp(6))
        })
    }

    /** Fila base: título + subtítulo a la izquierda y, opcionalmente, una vista a la derecha. */
    private fun baseRow(title: String, sub: String, right: View?, onClick: () -> Unit): TextView {
        val subView = TextView(this).apply {
            text = sub
            setTextColor(attrColor(R.attr.etvTextDim))
            textSize = 12f
        }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@SettingsActivity).apply {
                text = title
                setTextColor(Color.WHITE)
                textSize = 15f
            })
            addView(subView)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = selectableBg()
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (right != null) row.addView(right)
        list.addView(row)
        return subView
    }

    private fun switchRow(title: String, sub: String, key: String, def: Boolean) {
        val sw = SwitchCompat(this).apply {
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply() }
        }
        baseRow(title, sub, sw) { sw.toggle() }
    }

    /** Lista de opciones: guarda values[i] en la preferencia (un Int) y muestra el texto elegido como subtítulo. */
    private fun choiceRow(
        title: String, key: String, def: Int, values: List<Int>, labels: List<String>,
        onChosen: ((Int) -> Unit)? = null
    ) {
        fun indexNow(): Int = values.indexOf(prefs.getInt(key, def)).let { if (it >= 0) it else values.indexOf(def).coerceAtLeast(0) }
        lateinit var subView: TextView
        subView = baseRow(title, labels[indexNow()], null) {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(labels.toTypedArray(), indexNow()) { d, which ->
                    prefs.edit().putInt(key, values[which]).apply()
                    subView.text = labels[which]
                    onChosen?.invoke(values[which])
                    d.dismiss()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    private fun actionRow(title: String, sub: String, onClick: () -> Unit) {
        baseRow(title, sub, null, onClick)
    }

    private fun confirm(title: String, msg: String, action: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(msg)
            .setPositiveButton("Aceptar") { _, _ -> action() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ------------------------------------------------------------------ paleta de colores

    private fun paletteRow() {
        val current = prefs.getInt(Prefs.PALETTE, 0).coerceIn(0, Palettes.all.size - 1)
        val dot = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Palettes.all[current].swatch)
            }
            layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        }
        baseRow("Tema de color", Palettes.all[current].name, dot) { showPaletteDialog(current) }
    }

    private fun showPaletteDialog(current: Int) {
        val adapter = object : ArrayAdapter<Palette>(this, 0, Palettes.all) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val p = getItem(position)!!
                val row = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(20), dp(12), dp(20), dp(12))
                }
                row.addView(View(context).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(p.swatch)
                        setStroke(dp(2), if (position == current) Color.WHITE else Color.TRANSPARENT)
                    }
                    layoutParams = LinearLayout.LayoutParams(dp(28), dp(28))
                })
                row.addView(TextView(context).apply {
                    text = if (position == current) "${p.name}  ✓" else p.name
                    setTextColor(Color.WHITE)
                    textSize = 16f
                    setPadding(dp(16), 0, 0, 0)
                })
                return row
            }
        }
        AlertDialog.Builder(this)
            .setTitle("Tema de color")
            .setAdapter(adapter) { _, which ->
                prefs.edit().putInt(Prefs.PALETTE, which).apply()
                recreate() // esta pantalla y, al volver, la principal se pintan con la nueva paleta
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
