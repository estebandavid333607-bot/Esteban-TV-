package com.estebanruiz.estebantv

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Cada 4 horas avisa con 1 o 2 películas al azar de las listas guardadas de los dos catálogos.
 * Al tocar el aviso se abre la ficha de la película. Si todavía no hay listas guardadas (nunca se abrió
 * el catálogo), no manda nada.
 */
class MovieRecommendWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    companion object {
        private const val NAME = "movie_recommend"
        const val CHANNEL = "movie_recs"
        const val EXTRA_MOVIE = "open_movie"

        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<MovieRecommendWorker>(4, TimeUnit.HOURS)
                .setInitialDelay(4, TimeUnit.HOURS)
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
        }

        fun cancel(ctx: Context) {
            WorkManager.getInstance(ctx).cancelUniqueWork(NAME)
        }
    }

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        if (!Prefs(ctx).recommend) return Result.success()
        if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) return Result.success()
        val pool = MovieStore(ctx).allCached().shuffled()
        if (pool.isEmpty()) return Result.success()

        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Recomendaciones de películas", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val count = if (kotlin.random.Random.nextBoolean()) 1 else 2
        pool.take(count).forEach { m ->
            val open = Intent(ctx, MainActivity::class.java)
                .putExtra(EXTRA_MOVIE, movieToJson(m))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pi = PendingIntent.getActivity(
                ctx, m.url.hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val sub = listOf(m.year, m.genre).filter { it.isNotEmpty() }.joinToString(" • ")
            val syn = m.synopsis.take(220)
            val body = listOf(sub, syn).filter { it.isNotEmpty() }.joinToString("\n")
            val n = NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_movie)
                .setContentTitle("🎬 " + m.title)
                .setContentText(sub.ifEmpty { "Te la recomendamos para hoy" })
                .setStyle(NotificationCompat.BigTextStyle().bigText(body.ifEmpty { "Te la recomendamos para hoy" }))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            try {
                nm.notify(("rec" + m.url).hashCode(), n)
            } catch (e: Exception) { }
        }
        return Result.success()
    }
}
