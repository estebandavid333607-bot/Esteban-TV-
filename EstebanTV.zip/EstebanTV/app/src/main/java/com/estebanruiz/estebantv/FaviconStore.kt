package com.estebanruiz.estebantv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.text.Html
import android.util.LruCache
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

private const val UA =
    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

/** Imagen (favicon) de cada web: caché en memoria + disco. Se descarga solo si aún no la tenemos. */
class FaviconStore(context: Context) {

    private val dir = File(context.filesDir, "favicons").also { it.mkdirs() }
    private val mem = LruCache<String, Bitmap>(48)
    private val failed = HashSet<String>() // solo se toca desde el hilo principal
    private val main = Handler(Looper.getMainLooper())

    private fun key(url: String): String {
        var h = AdBlocker.host(url)
        if (h.isEmpty()) h = url.trim().lowercase()
        return h.removePrefix("www.")
    }

    private fun fileFor(k: String) = File(dir, k.replace(Regex("[^a-z0-9.\\-]"), "_") + ".png")

    fun cached(url: String): Bitmap? {
        val k = key(url)
        if (k.isEmpty()) return null
        mem.get(k)?.let { return it }
        val f = fileFor(k)
        if (!f.exists()) return null
        val b = BitmapFactory.decodeFile(f.path) ?: return null
        mem.put(k, b)
        return b
    }

    /** Guarda un icono que ya tenemos (por ejemplo el que entrega el WebView). Solo reemplaza si es mejor. */
    fun put(url: String, bmp: Bitmap) {
        val k = key(url)
        if (k.isEmpty() || bmp.width < 16) return
        val old = cached(url)
        if (old != null && old.width >= bmp.width) return
        mem.put(k, bmp)
        EXEC.execute { writeFile(k, bmp) }
    }

    /** Devuelve el icono (de caché o descargándolo). El callback corre en el hilo principal; null = no hay. */
    fun load(url: String, cb: (Bitmap?) -> Unit) {
        val hit = cached(url)
        if (hit != null) {
            cb(hit)
            return
        }
        val k = key(url)
        if (k.isEmpty() || k in failed) {
            cb(null)
            return
        }
        EXEC.execute {
            val b = download(k)
            if (b != null) writeFile(k, b)
            main.post {
                if (b != null) mem.put(k, b) else failed.add(k)
                cb(b)
            }
        }
    }

    fun clearAll() {
        mem.evictAll()
        failed.clear()
        dir.listFiles()?.forEach { it.delete() }
    }

    private fun writeFile(k: String, bmp: Bitmap) {
        try {
            FileOutputStream(fileFor(k)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (e: Exception) {
            // sin disco: no pasa nada, quedará solo en memoria
        }
    }

    private fun download(host: String): Bitmap? {
        val candidates = listOf(
            "https://www.google.com/s2/favicons?sz=128&domain=$host",
            "https://$host/favicon.ico"
        )
        for (u in candidates) {
            var c: HttpURLConnection? = null
            try {
                c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 6000
                c.readTimeout = 6000
                c.instanceFollowRedirects = true
                c.setRequestProperty("User-Agent", UA)
                if (c.responseCode == 200) {
                    val bytes = c.inputStream.use { it.readBytes() }
                    val b = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (b != null && b.width >= 16) return b
                }
            } catch (e: Exception) {
                // se prueba el siguiente
            } finally {
                c?.disconnect()
            }
        }
        return null
    }

    companion object {
        private val EXEC = Executors.newFixedThreadPool(3)
    }
}

/** Sugerencias de nombre para una web: por dominio y por el título de la página. */
object WebMeta {

    private val EXEC = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    private val brands = mapOf(
        "youtube" to "YouTube", "github" to "GitHub", "facebook" to "Facebook", "twitch" to "Twitch",
        "netflix" to "Netflix", "whatsapp" to "WhatsApp", "tiktok" to "TikTok", "linkedin" to "LinkedIn",
        "wikipedia" to "Wikipedia", "duckduckgo" to "DuckDuckGo", "instagram" to "Instagram",
        "reddit" to "Reddit", "spotify" to "Spotify", "google" to "Google", "amazon" to "Amazon",
        "mercadolibre" to "Mercado Libre", "disneyplus" to "Disney+", "primevideo" to "Prime Video",
        "x" to "X", "twitter" to "X (Twitter)", "telegram" to "Telegram", "pinterest" to "Pinterest",
        "vimeo" to "Vimeo", "dailymotion" to "Dailymotion", "bing" to "Bing"
    )

    /** "https://www.youtube.com/..." -> "YouTube"; "ejemplo.com" -> "Ejemplo". "" si no se puede. */
    fun brandName(url: String): String {
        val host = AdBlocker.host(url).removePrefix("www.")
        if (host.isEmpty() || !host.contains('.')) return ""
        val label = AdBlocker.registrable(host).substringBefore('.')
        if (label.isEmpty()) return ""
        return brands[label] ?: (label.replaceFirstChar { it.uppercaseChar() })
    }

    /** Del título completo saca opciones cortas: primera parte ("YouTube - Inicio" -> "YouTube") y el título recortado. */
    fun titleOptions(title: String): List<String> {
        val t = title.trim().replace(Regex("\\s+"), " ")
        if (t.isEmpty()) return emptyList()
        val first = t.split(" - ", " | ", " – ", " — ", " · ").firstOrNull { it.isNotBlank() }?.trim().orEmpty()
        val out = ArrayList<String>()
        if (first.isNotEmpty()) out.add(first.take(30))
        val full = t.take(40)
        if (!full.equals(first.take(30), ignoreCase = true)) out.add(full)
        return out
    }

    /** Descarga el <title> de la página (primeros ~96 KB). El callback corre en el hilo principal. */
    fun fetchTitle(url: String, cb: (String?) -> Unit) {
        EXEC.execute {
            var result: String? = null
            var c: HttpURLConnection? = null
            try {
                c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 6000
                c.readTimeout = 6000
                c.instanceFollowRedirects = true
                c.setRequestProperty("User-Agent", UA)
                if (c.responseCode == 200) {
                    val buf = ByteArray(96 * 1024)
                    var n = 0
                    c.inputStream.use { s ->
                        while (n < buf.size) {
                            val r = s.read(buf, n, buf.size - n)
                            if (r < 0) break
                            n += r
                        }
                    }
                    val html = String(buf, 0, n, Charsets.UTF_8)
                    val m = Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                        .find(html)
                    if (m != null) {
                        result = Html.fromHtml(m.groupValues[1], Html.FROM_HTML_MODE_LEGACY)
                            .toString().trim().replace(Regex("\\s+"), " ").ifEmpty { null }
                    }
                }
            } catch (e: Exception) {
                // sin red o sitio lento: solo no habrá sugerencia por título
            } finally {
                c?.disconnect()
            }
            main.post { cb(result) }
        }
    }
}
