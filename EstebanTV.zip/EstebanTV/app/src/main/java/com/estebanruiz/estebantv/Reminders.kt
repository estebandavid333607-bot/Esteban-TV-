package com.estebanruiz.estebantv

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject

/** Un partido marcado con la campana: avisa 10 minutos antes de que empiece. */
data class Reminder(val key: String, val title: String, val time: String, val epochMs: Long)

class ReminderStore(private val ctx: Context) {
    companion object {
        const val LEAD_MS = 10 * 60_000L
        const val CHANNEL = "agenda_reminders"
        const val EXTRA_OPEN_AGENDA = "open_agenda"

        fun keyOf(title: String): String = title.replace(AgendaFetcher.OPC2, "").replace(Regex("\\s+"), " ").trim().lowercase()
    }

    private val p = ctx.getSharedPreferences("reminders", Context.MODE_PRIVATE)
    private val am: AlarmManager get() = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun all(): List<Reminder> {
        val raw = p.getString("items", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Reminder(o.optString("k"), o.optString("t"), o.optString("h"), o.optLong("e"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("k", it.key).put("t", it.title).put("h", it.time).put("e", it.epochMs)) }
        p.edit().putString("items", arr.toString()).apply()
    }

    fun has(key: String): Boolean = all().any { it.key == key }

    /** En Android 12+ el aviso exacto necesita el permiso "Alarmas y recordatorios". */
    fun canExact(): Boolean = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()

    fun add(r: Reminder) {
        val list = all().filter { it.key != r.key } + r
        save(list)
        schedule(r)
    }

    fun remove(key: String) {
        val r = all().firstOrNull { it.key == key }
        if (r != null) cancel(r)
        save(all().filter { it.key != key })
    }

    /** Borra los avisos de partidos que ya empezaron hace rato. */
    fun prune() {
        val limit = System.currentTimeMillis() - 30 * 60_000L
        val keep = all().filter { it.epochMs > limit }
        if (keep.size != all().size) save(keep)
    }

    /** Después de reiniciar el celular las alarmas se pierden: se vuelven a programar. */
    fun rescheduleAll() {
        prune()
        all().forEach { schedule(it) }
    }

    private fun pending(r: Reminder): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .putExtra("k", r.key).putExtra("t", r.title).putExtra("h", r.time).putExtra("e", r.epochMs)
        return PendingIntent.getBroadcast(ctx, r.key.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun schedule(r: Reminder) {
        val at = maxOf(System.currentTimeMillis() + 3000L, r.epochMs - LEAD_MS)
        val pi = pending(r)
        try {
            if (canExact()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun cancel(r: Reminder) {
        am.cancel(pending(r))
    }
}

/** Se dispara 10 minutos antes del partido y muestra la notificación del sistema. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val key = intent.getStringExtra("k") ?: return
        val title = intent.getStringExtra("t").orEmpty()
        val time = intent.getStringExtra("h").orEmpty()
        val epoch = intent.getLongExtra("e", 0L)

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(ReminderStore.CHANNEL, "Avisos de partidos", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val mins = ((epoch - System.currentTimeMillis()) / 60_000L).toInt()
        val head = when {
            mins >= 9 -> "⚽ Empieza en 10 minutos"
            mins > 0 -> "⚽ Empieza en $mins min"
            else -> "⚽ Ya empezó"
        }
        val open = Intent(context, MainActivity::class.java)
            .putExtra(ReminderStore.EXTRA_OPEN_AGENDA, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(context, key.hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(context, ReminderStore.CHANNEL)
            .setSmallIcon(R.drawable.ic_agenda)
            .setContentTitle(head)
            .setContentText(if (time.isNotEmpty()) "$time  •  $title" else title)
            .setStyle(NotificationCompat.BigTextStyle().bigText(if (time.isNotEmpty()) "$time  •  $title" else title))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_EVENT)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        try {
            nm.notify(key.hashCode(), n)
        } catch (e: Exception) { }
        ReminderStore(context).remove(key)
    }
}

/** Reprograma los avisos cuando se reinicia el celular. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) ReminderStore(context).rescheduleAll()
    }
}
