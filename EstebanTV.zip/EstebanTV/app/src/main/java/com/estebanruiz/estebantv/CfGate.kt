package com.estebanruiz.estebantv

import android.annotation.SuppressLint
import android.app.Activity
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/**
 * Verificación de seguridad de Cloudflare (la pantalla "Verificando… / ¿eres un bot?" de RePelis24).
 *
 * El WebView invisible con el que se lee el catálogo no puede pasarla solo. Cuando la detecta, [solve] abre
 * una ventana COMPLETA con la página a la vista: ahí la verificación termina sola (o se marca la casilla con
 * el dedo / el control remoto). Al terminar, la ventana se cierra, las cookies quedan guardadas en la app
 * y el catálogo se vuelve a leer. Mientras la cookie sea válida no se vuelve a pedir.
 */
object CfGate {
    /** La actividad principal la registra en onCreate y la suelta en onDestroy. */
    @Volatile var activity: Activity? = null

    private val main = Handler(Looper.getMainLooper())
    private var dlg: Dialog? = null
    private val waiters = ArrayList<(Boolean) -> Unit>()
    @Volatile private var ua: String? = null

    /** Devuelve true si la página actual es la de verificación de Cloudflare. */
    const val CHECK_JS = """
(function(){try{
  var t=(document.title||'').toLowerCase();
  var b=((document.body&&document.body.innerText)||'').toLowerCase();
  if(t.indexOf('just a moment')>=0||t.indexOf('un momento')>=0||t.indexOf('attention required')>=0||t.indexOf('security check')>=0) return true;
  if(document.querySelector('#challenge-running,#challenge-stage,#challenge-form,#cf-challenge-running,.cf-browser-verification')) return true;
  if(b.length<3000&&(b.indexOf('verificación de seguridad')>=0||b.indexOf('verificacion de seguridad')>=0)) return true;
  if(b.length<3000&&b.indexOf('cloudflare')>=0&&(b.indexOf('verific')>=0||b.indexOf('checking')>=0||b.indexOf('human')>=0||b.indexOf('humano')>=0)) return true;
  return false;
}catch(e){return false;}})()
"""

    /**
     * Viste la pantalla de verificación con los colores de la app: fondo negro, sin textos de la web ni del servicio
     * y el recuadro de verificación con borde y brillo del color elegido. Se aplica solo mientras se ve la verificación.
     * (El contenido interno del recuadro lo dibuja el propio servicio y no se puede cambiar.)
     */
    private fun styleScript(hex: String): String = """
(function(){try{
  var A='$hex';
  var css='html,body{background:#000!important;color:#fff!important}'
   +'body{display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;min-height:100vh!important;margin:0!important}'
   +'h1,h2,h3,p,noscript,footer,.footer,#footer-text,.diagnostic-wrapper,.core-msg,.ray-id{display:none!important}'
   +'iframe{outline:2px solid '+A+'!important;outline-offset:2px!important;border-radius:12px!important;box-shadow:0 0 18px '+A+'!important}';
  var st=document.getElementById('__etv_css');
  if(!st){st=document.createElement('style');st.id='__etv_css';(document.head||document.documentElement).appendChild(st);}
  if(st.textContent!==css) st.textContent=css;
  var all=document.querySelectorAll('body *');
  for(var i=0;i<all.length;i++){
    var e=all[i];
    if(e.tagName==='IFRAME'||e.tagName==='STYLE'||e.tagName==='SCRIPT') continue;
    if(e.children.length===0&&/cloudflare|ray id|rendimiento y seguridad/i.test(e.textContent||'')) e.style.setProperty('display','none','important');
  }
}catch(x){}})();
"""

    /**
     * User-Agent de navegador normal (sin la marca "wv" de WebView). La cookie de Cloudflare se liga al
     * User-Agent, así que la ventana de verificación y las lecturas en segundo plano usan el mismo.
     */
    fun userAgent(ctx: Context): String {
        ua?.let { return it }
        val base = try { WebSettings.getDefaultUserAgent(ctx) } catch (e: Exception) { "" }
        val clean = base.replace("; wv", "").replace("Version/4.0 ", "").trim()
        ua = clean
        return clean
    }

    fun cachedUa(): String? = ua

    /** Abre la ventana de verificación (una sola aunque lo pidan varios a la vez). [cb] recibe true si se superó. */
    fun solve(url: String, cb: (Boolean) -> Unit) {
        main.post {
            val act = activity
            if (act == null || act.isFinishing || act.isDestroyed) {
                cb(false)
                return@post
            }
            waiters.add(cb)
            if (dlg == null) show(act, url)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun show(act: Activity, url: String) {
        val a = Prefs(act).accent
        fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()

        val root = LinearLayout(act)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)

        // ---- barra superior
        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(16), dp(10), dp(8), dp(8))
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        val title = TextView(act)
        title.text = "Necesita verificación"
        title.setTextColor(Color.WHITE)
        title.textSize = 18f
        title.setTypeface(title.typeface, Typeface.BOLD)
        val hint = TextView(act)
        hint.text = "Espera unos segundos. Se cierra sola."
        hint.setTextColor(Color.parseColor("#8FBF86"))
        hint.textSize = 12f
        col.addView(title)
        col.addView(hint)
        val close = TextView(act)
        close.text = "CERRAR"
        close.setTextColor(a)
        close.textSize = 13f
        close.setTypeface(close.typeface, Typeface.BOLD)
        close.setPadding(dp(12), dp(10), dp(12), dp(10))
        close.isClickable = true
        close.isFocusable = true
        bar.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(close)
        root.addView(bar)
        val line = android.view.View(act)
        line.setBackgroundColor(a)
        root.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)))
        val styleJs = styleScript(String.format("#%06X", a and 0xFFFFFF))

        // ---- página (invisible mientras se verifica sola) + línea de carga encima
        val web = WebView(act)
        web.setBackgroundColor(Color.BLACK)
        web.alpha = 0f
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = userAgent(act)
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(web, true)

        val stage = FrameLayout(act)
        stage.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // En vez de la rueda de la verificación: una línea que se va llenando hasta completar.
        val overlay = LinearLayout(act)
        overlay.orientation = LinearLayout.VERTICAL
        overlay.gravity = Gravity.CENTER
        overlay.setBackgroundColor(Color.BLACK)
        overlay.isClickable = true   // mientras está visible, no deja pasar toques a la página oculta
        val progress = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 1000
        progress.progress = 0
        progress.progressTintList = ColorStateList.valueOf(a)
        progress.progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#333333"))
        overlay.addView(
            progress,
            LinearLayout.LayoutParams(dp(260), dp(6))
        )
        stage.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(stage, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val d = Dialog(act, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        d.setContentView(root)
        d.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        dlg = d

        var ended = false
        var closing = false
        var loadedOnce = false
        var manual = false
        var clear = 0
        val deadline = SystemClock.uptimeMillis() + 150_000L
        lateinit var tick: Runnable

        // La línea avanza sola hasta ~90 % y espera; al terminar la verificación salta a 100 %.
        val fill = ValueAnimator.ofInt(0, 900).apply {
            duration = 7000
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { progress.progress = it.animatedValue as Int }
        }

        fun end(success: Boolean) {
            if (ended) return
            ended = true
            main.removeCallbacks(tick)
            try { fill.cancel() } catch (e: Exception) { }
            try { CookieManager.getInstance().flush() } catch (e: Exception) { }
            try {
                web.stopLoading()
                (web.parent as? ViewGroup)?.removeView(web)
                web.destroy()
            } catch (e: Exception) { }
            try { d.dismiss() } catch (e: Exception) { }
            dlg = null
            val ws = ArrayList(waiters)
            waiters.clear()
            ws.forEach { it(success) }
        }

        // Verificación superada: si la línea está a la vista se completa y luego se cierra.
        fun finishOk() {
            if (ended || closing) return
            closing = true
            if (manual || overlay.visibility != android.view.View.VISIBLE) {
                end(true)
                return
            }
            fill.cancel()
            ValueAnimator.ofInt(progress.progress, 1000).apply {
                duration = 250
                addUpdateListener { progress.progress = it.animatedValue as Int }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        main.postDelayed({ end(true) }, 150)
                    }
                })
                start()
            }
        }

        // Si no se supera sola en unos segundos, se muestra la casilla (vestida con los colores de la app) para marcarla.
        fun goManual() {
            if (manual || ended || closing) return
            manual = true
            fill.cancel()
            overlay.visibility = android.view.View.GONE
            hint.text = "Marca la casilla para continuar."
            web.animate().alpha(1f).setDuration(200).start()
        }

        tick = Runnable {
            if (!ended) {
                if (act.isFinishing || act.isDestroyed || SystemClock.uptimeMillis() > deadline) {
                    end(false)
                } else {
                    web.evaluateJavascript(CHECK_JS) { r ->
                        if (!ended) {
                            if (r == "true") web.evaluateJavascript(styleJs, null)
                            if (loadedOnce && r == "false") {
                                clear++
                                // Tres lecturas seguidas sin verificación = ya se pasó.
                                if (clear >= 3) {
                                    finishOk()
                                    return@evaluateJavascript
                                }
                            } else {
                                clear = 0
                            }
                            main.postDelayed(tick, 800)
                        }
                    }
                }
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, u: String?) {
                if (u != null && u != "about:blank") loadedOnce = true
                view?.let { v ->
                    v.evaluateJavascript(CHECK_JS) { r -> if (!ended && r == "true") v.evaluateJavascript(styleJs, null) }
                }
            }
        }
        close.setOnClickListener { end(false) }
        d.setOnDismissListener { end(false) }
        d.show()
        fill.start()
        web.loadUrl(url)
        main.postDelayed(tick, 500)
        main.postDelayed({ goManual() }, 8000)
    }
}
