package com.estebanruiz.estebantv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.webkit.WebView
import android.widget.EditText
import kotlin.math.min

/** Resalta con borde blanco y un poco de zoom el elemento que tiene el foco del control remoto. */
object TvFocus {
    fun install(root: View) {
        root.viewTreeObserver.addOnGlobalFocusChangeListener { old, new ->
            if (old != null && old !is WebView) {
                old.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                old.foreground = null
            }
            if (new != null && new !is EditText && new !is WebView) {
                val d = new.resources.displayMetrics.density
                val big = new.width > 200 * d
                val s = if (big) 1.03f else 1.08f
                new.animate().scaleX(s).scaleY(s).setDuration(120).start()
                val r = min(18 * d, new.height / 2f)
                new.foreground = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = r
                    setColor(Color.TRANSPARENT)
                    setStroke((3 * d).toInt(), Color.WHITE)
                }
            }
        }
    }
}

/**
 * Cursor virtual para navegar páginas web con el control remoto:
 * flechas = mover, OK = tocar, y en los bordes de la pantalla desplaza la página.
 */
class CursorView(
    ctx: Context,
    private val web: WebView,
    private val accent: () -> Int,
    private val isActive: () -> Boolean,
    private val onTopEdge: () -> Unit
) : View(ctx) {

    private val d = resources.displayMetrics.density
    private var cx = -1f
    private var cy = -1f
    private var pressedUntil = 0L
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f * d }
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f * d; color = Color.BLACK }

    init {
        isClickable = false
        isFocusable = false
    }

    override fun onDraw(c: Canvas) {
        if (!isActive()) return
        if (cx < 0f) { cx = width / 2f; cy = height / 2f }
        val big = SystemClock.uptimeMillis() < pressedUntil
        val r = (if (big) 15f else 10f) * d
        fill.color = accent()
        fill.alpha = 200
        ring.color = Color.WHITE
        c.drawCircle(cx, cy, r, fill)
        c.drawCircle(cx, cy, r, outline)
        c.drawCircle(cx, cy, r, ring)
    }

    /** true si la tecla se usó. */
    fun handleKey(e: KeyEvent): Boolean {
        if (cx < 0f) { cx = width / 2f; cy = height / 2f }
        val down = e.action == KeyEvent.ACTION_DOWN
        val step = (12 + min(e.repeatCount, 14) * 3) * d
        val scroll = (step * 3).toInt()
        when (e.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> if (down) {
                if (cy - step > 0f) cy -= step
                else if (web.canScrollVertically(-1)) web.scrollBy(0, -scroll)
                else { cy = 0f; if (e.repeatCount == 0) onTopEdge() }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> if (down) {
                if (cy + step < height) cy += step else web.scrollBy(0, scroll)
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> if (down) {
                if (cx - step > 0f) cx -= step else web.scrollBy(-scroll, 0)
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (down) {
                if (cx + step < width) cx += step else web.scrollBy(scroll, 0)
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (down && e.repeatCount == 0) click()
            }
            KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> if (down) web.scrollBy(0, (height * 0.8f).toInt())
            KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_CHANNEL_UP -> if (down) web.scrollBy(0, -(height * 0.8f).toInt())
            else -> return false
        }
        invalidate()
        return true
    }

    private fun click() {
        pressedUntil = SystemClock.uptimeMillis() + 250
        val t = SystemClock.uptimeMillis()
        val dn = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, cx, cy, 0).apply { source = InputDevice.SOURCE_TOUCHSCREEN }
        web.dispatchTouchEvent(dn)
        dn.recycle()
        postDelayed({
            val t2 = SystemClock.uptimeMillis()
            val up = MotionEvent.obtain(t, t2, MotionEvent.ACTION_UP, cx, cy, 0).apply { source = InputDevice.SOURCE_TOUCHSCREEN }
            web.dispatchTouchEvent(up)
            up.recycle()
        }, 60)
    }
}
