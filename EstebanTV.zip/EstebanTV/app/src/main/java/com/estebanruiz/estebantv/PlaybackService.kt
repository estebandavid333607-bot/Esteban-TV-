package com.estebanruiz.estebantv

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Mantiene ExoPlayer sonando con la pantalla apagada o fuera de la app y muestra la
 * notificación del sistema con los botones de play / pausa.
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    companion object {
        @Volatile private var instance: PlaybackService? = null
        @Volatile private var pending: ExoPlayer? = null

        fun attach(ctx: Context, p: ExoPlayer) {
            pending = p
            val svc = instance
            if (svc != null) svc.bind(p)
            else ctx.startService(Intent(ctx, PlaybackService::class.java))
        }

        fun detach(ctx: Context) {
            pending = null
            instance?.unbind()
            try {
                ctx.stopService(Intent(ctx, PlaybackService::class.java))
            } catch (e: Exception) {
                // ya estaba detenido
            }
        }
    }

    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        setMediaNotificationProvider(
            DefaultMediaNotificationProvider.Builder(this).build().apply { setSmallIcon(R.drawable.ic_notif) }
        )
        pending?.let { bind(it) }
    }

    private fun activityIntent(): PendingIntent {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun bind(p: ExoPlayer) {
        unbind()
        val s = MediaSession.Builder(this, p).setSessionActivity(activityIntent()).build()
        session = s
        addSession(s)
    }

    private fun unbind() {
        session?.let {
            removeSession(it)
            it.release()
        }
        session = null
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val r = super.onStartCommand(intent, flags, startId)
        if (session == null) stopSelf()
        return r
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        pending?.pause()
        stopSelf()
    }

    override fun onDestroy() {
        unbind()
        instance = null
        super.onDestroy()
    }
}
