package com.estebanruiz.estebantv

import android.content.Intent
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Servicio en primer plano: mantiene ExoPlayer sonando con la app en segundo plano o con la
 * pantalla apagada, y muestra la notificación del sistema con play/pausa.
 */
@UnstableApi
class PlaybackService : MediaSessionService() {

    companion object {
        @Volatile var session: MediaSession? = null
        @Volatile var instance: PlaybackService? = null
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        session?.let { addSession(it) }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady) stopSelf()
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
