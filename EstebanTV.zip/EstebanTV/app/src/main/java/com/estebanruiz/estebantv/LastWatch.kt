package com.estebanruiz.estebantv

import android.content.Context

/**
 * Lo último que el usuario vio, para ofrecer "Seguir viendo" al abrir la app.
 * kind: "movie" (página de la película), "agenda" (página del canal), "direct" (señal directa + referer), "web" (página que dio el video).
 */
class LastWatch(ctx: Context) {
    data class Item(val kind: String, val title: String, val url: String, val referer: String)

    private val p = ctx.getSharedPreferences("lastwatch", Context.MODE_PRIVATE)

    fun save(kind: String, title: String, url: String, referer: String = "") {
        if (url.isEmpty()) return
        p.edit().putString("kind", kind).putString("title", title).putString("url", url).putString("ref", referer).apply()
    }

    fun get(): Item? {
        val url = p.getString("url", "") ?: ""
        val kind = p.getString("kind", "") ?: ""
        if (url.isEmpty() || kind.isEmpty()) return null
        return Item(kind, p.getString("title", "") ?: "", url, p.getString("ref", "") ?: "")
    }

    fun clear() = p.edit().clear().apply()
}
