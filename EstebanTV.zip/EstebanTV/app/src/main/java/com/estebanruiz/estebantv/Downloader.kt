package com.estebanruiz.estebantv

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Una calidad detectada en el video: resolución/bitrate y cómo descargarla. */
data class Quality(
    val label: String,
    val width: Int,
    val height: Int,
    val bandwidth: Int,
    val kind: Kind,
    val uri: String,       // playlist de esa calidad (HLS) o representación (DASH) o el mp4 directo
    val durationSec: Double,
    val isLive: Boolean
) {
    enum class Kind { PROGRESSIVE, HLS, DASH_SIMPLE, UNSUPPORTED }
}

/** Analiza un enlace (.m3u8, .mpd o video directo) y devuelve las calidades disponibles. */
object MediaProbe {

    private fun get(url: String, referer: String, range: String? = null): Pair<Int, String> {
        val c = (URL(url).openConnection() as HttpURLConnection)
        c.connectTimeout = 12000
        c.readTimeout = 12000
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        if (referer.isNotEmpty()) c.setRequestProperty("Referer", referer)
        if (range != null) c.setRequestProperty("Range", range)
        c.instanceFollowRedirects = true
        val code = c.responseCode
        val body = try {
            BufferedInputStream(if (code in 200..399) c.inputStream else c.errorStream).readBytes()
                .toString(Charsets.UTF_8)
        } catch (e: Exception) { "" }
        c.disconnect()
        return code to body
    }

    private fun resolve(base: String, ref: String): String =
        try { Uri.parse(base).buildUpon().build(); URL(URL(base), ref).toString() } catch (e: Exception) { ref }

    fun probe(url: String, referer: String): List<Quality> = when {
        AdBlocker.isM3u8(url) -> probeHls(url, referer)
        AdBlocker.isMpd(url) -> probeDash(url, referer)
        else -> listOf(Quality("Original", 0, 0, 0, Quality.Kind.PROGRESSIVE, url, 0.0, false))
    }

    // ---------------------------------------------------------------- HLS

    private fun probeHls(url: String, referer: String): List<Quality> {
        val (code, text) = get(url, referer)
        if (code !in 200..299 || text.isBlank()) return emptyList()

        if ("#EXT-X-STREAM-INF" in text) {
            // Playlist maestra: una entrada por calidad.
            val lines = text.lines()
            val out = ArrayList<Quality>()
            var i = 0
            while (i < lines.size) {
                val l = lines[i]
                if (l.startsWith("#EXT-X-STREAM-INF")) {
                    val bw = Regex("BANDWIDTH=(\\d+)").find(l)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                    val res = Regex("RESOLUTION=(\\d+)x(\\d+)").find(l)
                    val w = res?.groupValues?.get(1)?.toIntOrNull() ?: 0
                    val h = res?.groupValues?.get(2)?.toIntOrNull() ?: 0
                    var j = i + 1
                    while (j < lines.size && lines[j].isBlank()) j++
                    val uri = lines.getOrNull(j)?.trim().orEmpty()
                    if (uri.isNotEmpty() && !uri.startsWith("#")) {
                        val full = resolve(url, uri)
                        val label = if (h > 0) "${h}p" else if (bw > 0) "${bw / 1000} kbps" else "Calidad"
                        out.add(Quality(label, w, h, bw, Quality.Kind.HLS, full, 0.0, false))
                    }
                    i = j
                }
                i++
            }
            // Duración real: se mide luego con la playlist de la primera calidad.
            return out.sortedByDescending { it.height * 10000 + it.bandwidth }
                .distinctBy { it.label }
                .map { q ->
                    val (dur, live) = mediaPlaylistInfo(q.uri, referer)
                    q.copy(durationSec = dur, isLive = live)
                }
        }
        // Ya es una playlist de una sola calidad (variante) o de video simple.
        val (dur, live) = playlistDuration(text) to ("#EXT-X-ENDLIST" !in text)
        return listOf(Quality("Original", 0, 0, 0, Quality.Kind.HLS, url, dur, live))
    }

    private fun mediaPlaylistInfo(url: String, referer: String): Pair<Double, Boolean> {
        val (code, text) = get(url, referer)
        if (code !in 200..299) return 0.0 to false
        return playlistDuration(text) to ("#EXT-X-ENDLIST" !in text)
    }

    private fun playlistDuration(text: String): Double =
        Regex("#EXTINF:([0-9.]+)").findAll(text).sumOf { it.groupValues[1].toDoubleOrNull() ?: 0.0 }

    // ---------------------------------------------------------------- DASH (best effort)

    private fun probeDash(url: String, referer: String): List<Quality> {
        val (code, text) = get(url, referer)
        if (code !in 200..299 || text.isBlank()) return emptyList()

        val isLive = Regex("type=\"dynamic\"").containsMatchIn(text)
        val durMin = Regex("mediaPresentationDuration=\"PT(?:(\\d+)H)?(?:(\\d+)M)?(?:([\\d.]+)S)?\"").find(text)
        val duration = durMin?.let {
            val h = it.groupValues[1].toDoubleOrNull() ?: 0.0
            val m = it.groupValues[2].toDoubleOrNull() ?: 0.0
            val s = it.groupValues[3].toDoubleOrNull() ?: 0.0
            h * 3600 + m * 60 + s
        } ?: 0.0

        val reps = Regex(
            "<Representation[^>]*id=\"([^\"]*)\"[^>]*(?:width=\"(\\d+)\")?[^>]*(?:height=\"(\\d+)\")?[^>]*bandwidth=\"(\\d+)\"[^>]*>",
            RegexOption.DOT_MATCHES_ALL
        ).findAll(text).toList()

        if (reps.isEmpty()) {
            return listOf(Quality("Original (DASH)", 0, 0, 0, Quality.Kind.UNSUPPORTED, url, duration, isLive))
        }

        return reps.map { m ->
            val w = m.groupValues[2].toIntOrNull() ?: 0
            val h = m.groupValues[3].toIntOrNull() ?: 0
            val bw = m.groupValues[4].toIntOrNull() ?: 0
            val label = if (h > 0) "${h}p" else "${bw / 1000} kbps"
            // La descarga completa de DASH por segmentos no está soportada aún: se ofrece solo el manifiesto/calidad para referencia.
            Quality(label, w, h, bw, Quality.Kind.UNSUPPORTED, url, duration, isLive)
        }.sortedByDescending { it.height * 10000 + it.bandwidth }.distinctBy { it.label }
    }
}

/** Descarga progresiva (mp4) o por segmentos (HLS) directo a la carpeta Descargas del teléfono. */
object VideoDownloader {

    private const val UA =
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    /** Estado de una descarga: lo escribe el hilo de descarga y lo lee la interfaz. */
    class Progress {
        @Volatile var percent = -1            // -1 = desconocido
        @Volatile var bytes = 0L              // bytes bajados hasta ahora
        @Volatile var totalBytes = -1L        // -1 = desconocido
        @Volatile var totalEstimated = false  // true en HLS (tamaño calculado por aproximación)
        @Volatile var error: String? = null
        @Volatile var outputUri: String? = null
        @Volatile var outputName: String = ""
        @Volatile var mime: String = "video/mp4"
        @Volatile var done = false

        fun add(n: Long) {
            synchronized(this) { bytes += n }
        }
    }

    fun cancelFlag() = AtomicBoolean(false)

    /** Descarga en un hilo aparte y reporta avance en [progress]. Llamar desde un hilo de fondo. */
    fun download(
        context: Context, q: Quality, referer: String, fileBaseName: String,
        cancel: AtomicBoolean, progress: Progress
    ) {
        val base = fileBaseName
            .replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim().take(80).trim()
            .ifEmpty { "video" }
        try {
            when (q.kind) {
                Quality.Kind.PROGRESSIVE -> downloadProgressive(context, q.uri, referer, base, cancel, progress)
                Quality.Kind.HLS -> downloadHls(context, q.uri, referer, base, cancel, progress)
                else -> progress.error = "Este formato todavía no se puede descargar completo"
            }
        } catch (e: Exception) {
            progress.error = if (cancel.get()) "Descarga cancelada" else (e.message ?: "Error al descargar")
        }
        progress.done = true
    }

    // ---------------------------------------------------------------- destino (carpeta Descargas)

    /** Archivo de salida en Descargas/EstebanTV (MediaStore en Android 10+, carpeta pública en Android 7-9). */
    private class Sink(
        private val context: Context,
        val baseName: String,
        val ext: String,
        val mime: String
    ) {
        private var uri: Uri? = null
        private var file: File? = null
        var displayName: String = "$baseName.$ext"
        lateinit var out: OutputStream

        fun open() {
            val resolver = context.contentResolver
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/EstebanTV")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val u = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IOException("No se pudo crear el archivo en Descargas")
                uri = u
                val raw = resolver.openOutputStream(u) ?: throw IOException("No se pudo escribir en Descargas")
                out = BufferedOutputStream(raw, 256 * 1024)
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "EstebanTV"
                )
                if (!dir.exists() && !dir.mkdirs()) throw IOException("No se pudo crear la carpeta Descargas/EstebanTV")
                var f = File(dir, displayName)
                var n = 1
                while (f.exists()) {
                    f = File(dir, "$baseName ($n).$ext")
                    n++
                }
                file = f
                displayName = f.name
                out = BufferedOutputStream(FileOutputStream(f), 256 * 1024)
            }
        }

        /** Cierra el archivo, lo publica en Descargas y devuelve su dirección (content:// o file://). */
        fun finish(): String {
            out.flush()
            out.close()
            val u = uri
            if (u != null) {
                val resolver = context.contentResolver
                val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(u, v, null, null)
                try {
                    resolver.query(u, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) displayName = c.getString(0)
                    }
                } catch (e: Exception) { /* se queda el nombre pedido */ }
                return u.toString()
            }
            val f = file ?: throw IOException("Archivo no disponible")
            val latch = CountDownLatch(1)
            var found: Uri? = null
            MediaScannerConnection.scanFile(context, arrayOf(f.absolutePath), arrayOf(mime)) { _, scanned ->
                found = scanned
                latch.countDown()
            }
            latch.await(2, TimeUnit.SECONDS)
            return (found ?: Uri.fromFile(f)).toString()
        }

        /** Cancela o falla: cierra y borra lo que se haya escrito. */
        fun abort() {
            try { out.close() } catch (e: Exception) { }
            val u = uri
            if (u != null) {
                try { context.contentResolver.delete(u, null, null) } catch (e: Exception) { }
            }
            file?.delete()
        }
    }

    private fun extOf(url: String): String {
        val path = try { Uri.parse(url).path.orEmpty() } catch (e: Exception) { "" }
        val e = path.substringAfterLast('.', "").lowercase()
        return if (e in setOf("mp4", "m4v", "webm", "mkv", "mov", "3gp")) e else "mp4"
    }

    private fun mimeOf(ext: String): String = when (ext) {
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "mov" -> "video/quicktime"
        "3gp" -> "video/3gpp"
        "ts" -> "video/mp2t"
        else -> "video/mp4"
    }

    private fun finishOk(sink: Sink, progress: Progress) {
        val u = sink.finish()
        progress.outputName = sink.displayName
        progress.mime = sink.mime
        progress.percent = 100
        progress.outputUri = u
    }

    // ---------------------------------------------------------------- descarga progresiva (mp4, webm...)

    private fun downloadProgressive(
        context: Context, url: String, referer: String, base: String,
        cancel: AtomicBoolean, progress: Progress
    ) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", UA)
        if (referer.isNotEmpty()) c.setRequestProperty("Referer", referer)
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        try {
            val code = c.responseCode
            if (code !in 200..299) throw IOException("El servidor respondió con el código $code")
            val type = (c.contentType ?: "").lowercase()
            if (type.startsWith("text/html")) {
                throw IOException("Ese enlace es una página web, no un video. Abre la página y usa el aviso de ExoPlayer")
            }
            progress.totalBytes = c.contentLengthLong
            val ext = extOf(url)
            val sink = Sink(context, base, ext, mimeOf(ext))
            sink.open()
            try {
                c.inputStream.use { input -> copyStream(input, sink.out, cancel, progress) }
            } catch (e: Exception) {
                sink.abort()
                throw e
            }
            if (cancel.get()) {
                sink.abort()
                progress.error = "Descarga cancelada"
                return
            }
            finishOk(sink, progress)
        } finally {
            c.disconnect()
        }
    }

    private fun copyStream(input: InputStream, out: OutputStream, cancel: AtomicBoolean, progress: Progress) {
        val buf = ByteArray(64 * 1024)
        while (!cancel.get()) {
            val n = input.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            progress.add(n.toLong())
            val total = progress.totalBytes
            if (total > 0) progress.percent = ((progress.bytes * 100) / total).toInt().coerceIn(0, 100)
        }
    }

    // ---------------------------------------------------------------- HLS (.m3u8)

    /**
     * Baja los fragmentos de la playlist HLS en paralelo (4 a la vez), los descifra si vienen con AES-128
     * y los une en orden en un solo archivo (.ts, o .mp4 si la lista usa fragmentos fMP4).
     */
    private fun downloadHls(
        context: Context, playlistUrl: String, referer: String, base: String,
        cancel: AtomicBoolean, progress: Progress
    ) {
        val text = fetchBytes(playlistUrl, referer, null, cancel).toString(Charsets.UTF_8)
        if ("#EXT-X-ENDLIST" !in text) {
            progress.error = "Esto es una transmisión en vivo: no tiene un final para descargar"
            return
        }

        class Seg(val url: String, val keyUri: String?, val iv: ByteArray?, val seq: Long)

        val segs = ArrayList<Seg>()
        var seq = Regex("#EXT-X-MEDIA-SEQUENCE:(\\d+)").find(text)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        var keyUri: String? = null
        var keyIv: ByteArray? = null
        var mapUrl: String? = null

        for (raw in text.lines()) {
            val l = raw.trim()
            if (l.isEmpty()) continue
            if (l.startsWith("#EXT-X-KEY")) {
                val method = attr(l, "METHOD")
                if (method == "AES-128") {
                    keyUri = attr(l, "URI")?.let { resolveUrl(playlistUrl, it) }
                    keyIv = attr(l, "IV")?.let { hexToBytes(it) }
                } else if (method == "NONE") {
                    keyUri = null
                    keyIv = null
                } else {
                    progress.error = "Este video usa protección DRM y no se puede descargar"
                    return
                }
            } else if (l.startsWith("#EXT-X-MAP")) {
                mapUrl = attr(l, "URI")?.let { resolveUrl(playlistUrl, it) }
            } else if (!l.startsWith("#")) {
                segs.add(Seg(resolveUrl(playlistUrl, l), keyUri, keyIv, seq))
                seq++
            }
        }
        if (segs.isEmpty()) {
            progress.error = "No se encontraron fragmentos de video"
            return
        }

        val map = mapUrl
        val ext = if (map != null) "mp4" else "ts"
        val sink = Sink(context, base, ext, mimeOf(ext))
        sink.open()

        val keyCache = ConcurrentHashMap<String, ByteArray>()
        val pool = Executors.newFixedThreadPool(4)
        try {
            if (map != null) sink.out.write(fetchBytes(map, referer, progress, cancel))
            val window = java.util.ArrayDeque<Future<ByteArray>>()
            var next = 0
            var written = 0
            while (written < segs.size) {
                if (cancel.get()) break
                while (next < segs.size && window.size < 8) {
                    val s = segs[next]
                    window.add(
                        pool.submit(Callable<ByteArray> {
                            fetchSegment(s.url, referer, s.keyUri, s.iv ?: seqIv(s.seq), keyCache, cancel, progress)
                        })
                    )
                    next++
                }
                val data = window.poll()!!.get()
                sink.out.write(data)
                written++
                progress.percent = (written * 100) / segs.size
                progress.totalBytes = progress.bytes * segs.size / written
                progress.totalEstimated = true
            }
        } catch (e: Exception) {
            pool.shutdownNow()
            sink.abort()
            val root = (e as? ExecutionException)?.cause ?: e
            throw IOException(root.message ?: "Error al descargar el video")
        }
        pool.shutdownNow()
        if (cancel.get()) {
            sink.abort()
            progress.error = "Descarga cancelada"
            return
        }
        finishOk(sink, progress)
    }

    private fun fetchSegment(
        url: String, referer: String, keyUri: String?, iv: ByteArray,
        keyCache: ConcurrentHashMap<String, ByteArray>, cancel: AtomicBoolean, progress: Progress
    ): ByteArray {
        var last: Exception? = null
        for (attempt in 1..3) {
            if (cancel.get()) throw IOException("Descarga cancelada")
            try {
                val raw = fetchBytes(url, referer, progress, cancel)
                if (keyUri == null) return raw
                val key = keyCache.getOrPut(keyUri) { fetchBytes(keyUri, referer, null, cancel) }
                return decrypt(raw, key, iv)
            } catch (e: Exception) {
                last = e
                try { Thread.sleep(400L * attempt) } catch (ie: InterruptedException) { break }
            }
        }
        throw IOException("No se pudo bajar un fragmento del video (${last?.message ?: "error de red"})")
    }

    private fun decrypt(data: ByteArray, key: ByteArray, iv: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/CBC/PKCS5Padding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
        return c.doFinal(data)
    }

    private fun fetchBytes(url: String, referer: String, progress: Progress?, cancel: AtomicBoolean?): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.setRequestProperty("User-Agent", UA)
            if (referer.isNotEmpty()) c.setRequestProperty("Referer", referer)
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.instanceFollowRedirects = true
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            val bos = ByteArrayOutputStream()
            val buf = ByteArray(32 * 1024)
            c.inputStream.use { ins ->
                while (true) {
                    if (cancel != null && cancel.get()) throw IOException("Descarga cancelada")
                    val n = ins.read(buf)
                    if (n < 0) break
                    bos.write(buf, 0, n)
                    progress?.add(n.toLong())
                }
            }
            return bos.toByteArray()
        } finally {
            c.disconnect()
        }
    }

    private fun resolveUrl(base: String, ref: String): String =
        try { URL(URL(base), ref).toString() } catch (e: Exception) { ref }

    /** Lee un atributo de una etiqueta HLS: METHOD=AES-128 o URI="clave.key". */
    private fun attr(line: String, key: String): String? {
        val m = Regex("(?:^|[:,])" + key + "=(\"[^\"]*\"|[^,]*)").find(line) ?: return null
        return m.groupValues[1].trim().trim('"')
    }

    private fun hexToBytes(s: String): ByteArray {
        var h = s.trim().removePrefix("0x").removePrefix("0X")
        if (h.length % 2 == 1) h = "0$h"
        val b = ByteArray(h.length / 2) { i -> h.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
        return when {
            b.size == 16 -> b
            b.size > 16 -> b.copyOfRange(b.size - 16, b.size)
            else -> ByteArray(16).also { System.arraycopy(b, 0, it, 16 - b.size, b.size) }
        }
    }

    /** Si la lista no trae IV, HLS usa el número de secuencia del fragmento. */
    private fun seqIv(seq: Long): ByteArray {
        val iv = ByteArray(16)
        for (i in 0..7) iv[15 - i] = ((seq shr (8 * i)) and 0xFF).toByte()
        return iv
    }
}
