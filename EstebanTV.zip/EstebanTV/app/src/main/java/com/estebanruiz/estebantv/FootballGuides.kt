package com.estebanruiz.estebantv

/**
 * Guías de fútbol preinstaladas en el recuadro "Fútbol ⚽" del menú principal.
 * Para agregar o quitar una, edita esta lista: FootballGuide("Nombre", "https://...")
 * El icono se toma solo de la propia página.
 */
data class FootballGuide(val name: String, val url: String)

object FootballGuides {
    val list: List<FootballGuide> = listOf(
        FootballGuide("Dzri TV", "https://dzritv.com/sport/football"),
        FootballGuide("Rústico TV", "https://rusticotv.la/home.php"),
    )
}
