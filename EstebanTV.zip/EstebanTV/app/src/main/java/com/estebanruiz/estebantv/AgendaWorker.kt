package com.estebanruiz.estebantv

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ListenableWorker.Result
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.TimeUnit

/**
 * Baja la agenda cada cierto tiempo aunque el usuario no tenga la app abierta, para que al
 * entrar ya esté actualizada. Android no deja que un trabajo en segundo plano se repita más
 * seguido que cada 15 minutos (límite del sistema, no de la app).
 */
class AgendaWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    companion object {
        private const val NAME = "agenda_refresh"

        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<AgendaWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }

    override suspend fun doWork(): Result {
        val appCtx = applicationContext
        // AgendaFetcher usa un WebView y eso solo se puede hacer en el hilo principal.
        val agenda = suspendCancellableCoroutine<Agenda?> { cont ->
            Handler(Looper.getMainLooper()).post {
                AgendaFetcher(appCtx).fetch { ag -> if (cont.isActive) cont.resumeWith(kotlin.Result.success(ag)) }
            }
        }
        if (agenda != null) AgendaStore(appCtx).save(agenda)
        return Result.success()
    }
}
