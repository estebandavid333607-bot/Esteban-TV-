package com.estebanruiz.estebantv

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * Los colores del icono de la app: los mismos de la paleta de la interfaz, menos RGB (que es animado y un icono no se mueve).
 * Cada color es un "alias" del AndroidManifest (.IconP0 … .IconP8) y solo uno está activo a la vez.
 * Este mismo color es el que usa la pantalla de carga que se ve al tocar la app.
 */
object IconColors {
    val names = arrayOf("Verde neón", "Cian", "Azul", "Violeta", "Magenta", "Rojo", "Naranja", "Amarillo", "Blanco")
    val colors = intArrayOf(
        0xFF39FF14.toInt(), 0xFF00E5FF.toInt(), 0xFF448AFF.toInt(), 0xFFB388FF.toInt(), 0xFFFF2BD6.toInt(),
        0xFFFF1744.toInt(), 0xFFFF9100.toInt(), 0xFFFFEA00.toInt(), 0xFFFFFFFF.toInt(),
    )

    fun colorOf(idx: Int): Int = colors[idx.coerceIn(0, colors.size - 1)]

    /** Activa el icono [idx] y desactiva los demás (primero el nuevo, para que nunca falte un icono). */
    fun apply(ctx: Context, idx: Int) {
        val i = idx.coerceIn(0, colors.size - 1)
        val pm = ctx.packageManager
        try {
            pm.setComponentEnabledSetting(
                ComponentName(ctx.packageName, "com.estebanruiz.estebantv.IconP$i"),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP
            )
            for (k in colors.indices) {
                if (k == i) continue
                pm.setComponentEnabledSetting(
                    ComponentName(ctx.packageName, "com.estebanruiz.estebantv.IconP$k"),
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP
                )
            }
        } catch (e: Exception) {
            // si el sistema no deja cambiarlo, se queda el icono actual
        }
        Prefs(ctx).iconIndex = i
    }
}
