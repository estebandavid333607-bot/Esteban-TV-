package com.estebanruiz.estebantv

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Un canal de la lista M3U: nombre, grupo, logo, dirección del video y (si la lista lo trae) el referer. */
data class AdultChannel(val name: String, val group: String, val logo: String, val url: String, val referer: String)

/**
 * Sección "Adultos XXX 🔞": lee una lista M3U y guarda la última copia en disco para mostrarla al instante.
 * Para cambiar la clave edita [PIN]; para cambiar la lista, [URL].
 */
class AdultStore(ctx: Context) {
    companion object {
        const val PIN = "0000"
        const val URL = "https://adultiptv.net/chs.m3u"

        private val ATTR = Regex("([A-Za-z0-9_-]+)=\"([^\"]*)\"")
        private val io = Executors.newSingleThreadExecutor()
        private val main = Handler(Looper.getMainLooper())

        /** Convierte el texto de una lista M3U en canales. Acepta #EXTINF con tvg-logo / group-title y #EXTVLCOPT de referer. */
        fun parse(text: String): List<AdultChannel> {
            val out = ArrayList<AdultChannel>()
            var name = ""
            var group = ""
            var logo = ""
            var referer = ""
            var have = false
            for (raw in text.lineSequence()) {
                val line = raw.trim().removePrefix("\uFEFF")
                if (line.isEmpty()) continue
                if (line.startsWith("#EXTINF", ignoreCase = true)) {
                    val attrs = ATTR.findAll(line).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                    val rest = ATTR.replace(line, "")
                    name = rest.substringAfterLast(',', "").trim().ifEmpty { attrs["tvg-name"].orEmpty() }
                    group = attrs["group-title"].orEmpty().trim()
                    logo = attrs["tvg-logo"].orEmpty().trim()
                    referer = ""
                    have = true
                } else if (line.startsWith("#EXTVLCOPT", ignoreCase = true)) {
                    val v = line.substringAfter(':', "")
                    if (v.startsWith("http-referrer=", ignoreCase = true) || v.startsWith("http-referer=", ignoreCase = true)) {
                        referer = v.substringAfter('=').trim()
                    }
                } else if (line.startsWith("#")) {
                    continue
                } else if (have && (line.startsWith("http://") || line.startsWith("https://"))) {
                    out.add(AdultChannel(name.ifEmpty { "Canal ${out.size + 1}" }, group, logo, line, referer))
                    have = false
                    name = ""
                    group = ""
                    logo = ""
                    referer = ""
                }
            }
            return out
        }
    }

    private val file = File(ctx.filesDir, "adult.m3u")

    fun cached(): List<AdultChannel> = try {
        if (file.exists()) parse(file.readText()) else emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    /** Baja la lista en segundo plano; [done] se llama en el hilo principal (null si falló). */
    fun fetch(done: (List<AdultChannel>?) -> Unit) {
        io.execute {
            val res: List<AdultChannel>? = try {
                val text = download(URL)
                val list = if (text.contains("#EXTINF", ignoreCase = true)) parse(text) else emptyList()
                if (list.isNotEmpty()) {
                    try { file.writeText(text) } catch (e: Exception) { }
                    list
                } else null
            } catch (e: Exception) {
                null
            }
            main.post { done(res) }
        }
    }

    /** Descarga de texto siguiendo redirecciones (incluso de http a https, que HttpURLConnection no hace solo). */
    private fun download(start: String): String {
        var u = start
        for (i in 0 until 6) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 10000
            c.readTimeout = 20000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: throw java.io.IOException("redirección sin destino")
                u = URL(URL(u), loc).toString()
                c.disconnect()
                continue
            }
            if (code != 200) {
                c.disconnect()
                throw java.io.IOException("HTTP $code")
            }
            val t = c.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8)
            c.disconnect()
            return t
        }
        throw java.io.IOException("demasiadas redirecciones")
    }
}
