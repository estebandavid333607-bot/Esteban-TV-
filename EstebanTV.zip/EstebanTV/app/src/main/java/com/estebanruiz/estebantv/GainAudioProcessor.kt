package com.estebanruiz.estebantv

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer

/**
 * Ganancia de software (igual que el volumen 0-200 % de VLC): multiplica cada muestra de audio
 * por [gain] (1.0 = 100 %, 2.0 = 200 %) y recorta lo que pase del máximo. No depende del celular.
 */
@UnstableApi
class GainAudioProcessor : BaseAudioProcessor() {

    @Volatile
    var gain: Float = 1f

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        return if (inputAudioFormat.encoding == C.ENCODING_PCM_16BIT ||
            inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT
        ) inputAudioFormat else AudioProcessor.AudioFormat.NOT_SET
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        val g = gain
        if (inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT) {
            while (inputBuffer.remaining() >= 4) {
                out.putFloat((inputBuffer.getFloat() * g).coerceIn(-1f, 1f))
            }
        } else {
            while (inputBuffer.remaining() >= 2) {
                val v = (inputBuffer.getShort() * g).toInt().coerceIn(-32768, 32767)
                out.putShort(v.toShort())
            }
        }
        out.flip()
    }
}
