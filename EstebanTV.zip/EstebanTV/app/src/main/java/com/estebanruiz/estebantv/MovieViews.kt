package com.estebanruiz.estebantv

import android.content.Context
import android.widget.ImageView

/** Carátula con proporción fija 2:3 según su ancho real (no se estira aunque la pantalla gire). */
class PosterView(ctx: Context) : ImageView(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (w * 1.5f).toInt())
    }
}
