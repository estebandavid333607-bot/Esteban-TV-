package com.estebanruiz.estebantv

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.ByteArrayInputStream

/** Resultado: la URL real del video y la página (Referer) desde la que se pidió. */
data class ResolvedStream(val url: String, val referer: String)

/**
 * Abre la página del canal en un WebView INVISIBLE (nunca se muestra), espera a que la página pida
 * el video (.m3u8 / .mpd / .mp4) y entrega esa dirección para reproducirla directo en ExoPlayer.
 * Si en [TIMEOUT_MS] no encuentra nada, entrega null y la app abre la web como antes.
 */
class StreamResolver(private val act: Activity, private val userAgent: String) {
    companion object {
        const val TIMEOUT_MS = 18_000L
        /** Si solo aparece un .mp4 (puede ser un anuncio) se espera este tiempo por un .m3u8/.mpd mejor. */
        const val MP4_GRACE_MS = 5_000L

        // Intenta arrancar el reproductor de la página (botones de play y <video>.play()).
        private const val KICK_JS = """
(function(){
  try{
    var sel=['.vjs-big-play-button','.jw-icon-display','.plyr__control--overlaid','.play-button','.btn-play',
             '#play','.play','[aria-label="Play"]','[title="Play"]','.fp-play','.ytp-large-play-button'];
    for(var i=0;i<sel.length;i++){ var e=document.querySelector(sel[i]); if(e){ try{e.click();}catch(x){} } }
    document.querySelectorAll('video').forEach(function(v){ try{ v.muted=true; var p=v.play(); if(p&&p.catch)p.catch(function(){}); }catch(x){} });
  }catch(x){}
})();
"""
    }

    private val handler = Handler(Looper.getMainLooper())
    private var web: WebView? = null
    private var finished = false
    private var mp4Candidate: ResolvedStream? = null
    private var pageUrl = ""

    /** Porcentaje 0..100 (solo sube). Se llama en el hilo principal. */
    var onProgress: ((Int) -> Unit)? = null
    private var pagePct = 0
    private var shownPct = 0
    private var startTs = 0L

    /** Llamar desde el hilo principal. [done] se llama UNA vez (hilo principal) con el resultado o null. */
    @SuppressLint("SetJavaScriptEnabled")
    fun resolve(url: String, referer: String? = null, done: (ResolvedStream?) -> Unit) {
        pageUrl = url
        val w = WebView(act)
        web = w
        with(w.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            userAgentString = userAgent
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            blockNetworkImage = true
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)

        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url.toString()
                if (AdBlocker.isAdUrl(u)) return empty()
                if (request.method == "GET" && AdBlocker.isStreamUrl(u)) {
                    val ref = request.requestHeaders?.get("Referer")?.takeIf { it.isNotEmpty() } ?: pageUrl
                    val found = ResolvedStream(u, ref)
                    if (AdBlocker.isM3u8(u) || AdBlocker.isMpd(u)) {
                        handler.post { finish(found, done) }
                    } else {
                        handler.post {
                            if (mp4Candidate == null) {
                                mp4Candidate = found
                                handler.postDelayed({ finish(mp4Candidate, done) }, MP4_GRACE_MS)
                            }
                        }
                    }
                    return empty()
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest): Boolean {
                val s = request.url.scheme?.lowercase()
                if (s != "http" && s != "https") return true
                return AdBlocker.isAdUrl(request.url.toString())
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                view?.evaluateJavascript(AdBlocker.AD_JS, null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                kick(0)
            }
        }

        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                pagePct = newProgress
            }
        }

        startTs = SystemClock.uptimeMillis()
        tick()
        handler.postDelayed({ finish(mp4Candidate, done) }, TIMEOUT_MS)
        if (referer != null) w.loadUrl(url, mapOf("Referer" to referer)) else w.loadUrl(url)
    }

    /**
     * Porcentaje aproximado: la carga de la página cuenta hasta 60% y el resto avanza con el tiempo
     * (hasta 95%) mientras se busca la señal. Al encontrarla salta a 100%.
     */
    private fun tick() {
        if (finished) return
        val elapsed = SystemClock.uptimeMillis() - startTs
        val byTime = (elapsed * 90 / TIMEOUT_MS).toInt()
        val target = maxOf(pagePct * 60 / 100, byTime).coerceAtMost(95)
        if (target > shownPct) {
            shownPct = target
            onProgress?.invoke(shownPct)
        }
        handler.postDelayed({ tick() }, 250)
    }

    /** Cada segundo, un rato, intenta darle "play" a la página para que pida el video. */
    private fun kick(n: Int) {
        if (finished || n > 12) return
        web?.evaluateJavascript(KICK_JS, null)
        handler.postDelayed({ kick(n + 1) }, 1_000)
    }

    private fun empty() = WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))

    /** Cancela sin llamar a [done]. */
    fun cancel() {
        if (finished) return
        finished = true
        cleanup()
    }

    private fun finish(r: ResolvedStream?, done: (ResolvedStream?) -> Unit) {
        if (finished) return
        finished = true
        cleanup()
        if (r != null) onProgress?.invoke(100)
        if (!act.isFinishing && !act.isDestroyed) done(r)
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        try {
            web?.stopLoading()
            web?.loadUrl("about:blank")
            web?.destroy()
        } catch (e: Exception) { }
        web = null
    }
}
