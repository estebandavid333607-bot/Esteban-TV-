package com.estebanruiz.estebantv

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.ByteArrayInputStream

/** Resultado: la URL real del video y la página (Referer) desde la que se pidió. */
data class ResolvedStream(val url: String, val referer: String, val mime: String? = null)

/**
 * Abre la página del canal en un WebView INVISIBLE (nunca se muestra), espera a que la página pida
 * el video (.m3u8 / .mpd / .mp4) y entrega esa dirección para reproducirla directo en ExoPlayer.
 * Si en [TIMEOUT_MS] no encuentra nada, entrega null y la app abre la web como antes.
 */
class StreamResolver(
    private val act: Activity,
    private val userAgent: String,
    /** true = la web se muestra al usuario (para verificaciones "eres humano"); sin tiempo corto ni clics automáticos. */
    private val manual: Boolean = false,
    /** false (solo con manual) = el video se queda en la web: no se busca su dirección para pasarlo a ExoPlayer. */
    private val handoff: Boolean = true
) {
    companion object {
        const val TIMEOUT_MS = 18_000L
        /** Si solo aparece un .mp4 (puede ser un anuncio) se espera este tiempo por un .m3u8/.mpd mejor. */
        const val MP4_GRACE_MS = 5_000L
        /** En modo manual se le da tiempo al usuario para verificar y tocar play. */
        const val MANUAL_TIMEOUT_MS = 150_000L

        // Detecta pantallas de verificación tipo "haz clic para verificar que eres humano".
        private const val VERIFY_JS = """
(function(){try{var t=((document.body&&document.body.innerText)||'').toLowerCase();
return /eres humano|no soy un robot|verifica que|verificar que|verify you are human|not a robot|captcha/.test(t);}catch(x){return false;}})();
"""

        // Modo manual: mira el <video> de la página (o jwplayer) y dice qué dirección está reproduciendo y cuánto dura.
        private const val PROBE_JS = """
(function(){
  try{
    var best=null;
    var vs=document.querySelectorAll('video');
    for(var i=0;i<vs.length;i++){
      var v=vs[i], s=v.currentSrc||v.src||'';
      if(!s){ var so=v.querySelector('source'); if(so) s=so.src||''; }
      if(/^https?:/i.test(s)){
        var d=(isFinite(v.duration)?v.duration:0);
        best={u:s,d:Math.round(d),p:(v.paused?0:1),t:Math.round(v.currentTime)};
        break;
      }
    }
    if(!best && window.jwplayer){
      try{
        var pl=jwplayer().getPlaylist();
        if(pl&&pl[0]){
          var f=pl[0].file||(pl[0].sources&&pl[0].sources[0]&&pl[0].sources[0].file);
          if(f&&/^https?:/i.test(f)) best={u:f,d:999999,p:1,t:0};
        }
      }catch(e){}
    }
    return best?JSON.stringify(best):'';
  }catch(x){return '';}
})();
"""

        /** Diagnóstico de la última señal encontrada (lo muestra el botón Info del reproductor). */
        @Volatile private var lastDebugUrl = ""
        @Volatile private var lastDebug = ""

        fun debugFor(url: String): String = if (url.isNotEmpty() && url == lastDebugUrl) lastDebug else ""

        private val STATIC_RE = Regex("""\.(js|css|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|map)(?=$|[?#])""", RegexOption.IGNORE_CASE)

        // Intenta arrancar el reproductor de la página (botones de play y <video>.play()).
        private const val KICK_JS = """
(function(){
  try{
    var sel=['.vjs-big-play-button','.jw-icon-display','.plyr__control--overlaid','.play-button','.btn-play',
             '#play','.play','[aria-label="Play"]','[title="Play"]','.fp-play','.ytp-large-play-button'];
    for(var i=0;i<sel.length;i++){ var e=document.querySelector(sel[i]); if(e){ try{e.click();}catch(x){} } }
    document.querySelectorAll('video').forEach(function(v){ try{ v.muted=true; var p=v.play(); if(p&&p.catch)p.catch(function(){}); }catch(x){} });
  }catch(x){}
})();
"""
    }

    private val handler = Handler(Looper.getMainLooper())
    private val recent = ArrayList<String>()
    private var lastProbe = ""

    private fun note(u: String) {
        if (STATIC_RE.containsMatchIn(u)) return
        synchronized(recent) {
            if (recent.lastOrNull() != u) {
                recent.add(u)
                if (recent.size > 40) recent.removeAt(0)
            }
        }
    }

    /** Texto de diagnóstico (modo manual): lo que el reproductor de la página estaba pidiendo. */
    fun debugInfo(): String {
        val list = synchronized(recent) { recent.toList() }
        return "Video de la página: " + (lastProbe.ifEmpty { "ninguno todavía" }) +
            "\n\nPeticiones recientes (" + list.size + "):\n" + list.joinToString("\n\n") { it.take(200) }
    }

    private var web: WebView? = null
    private var finished = false
    private var mp4Candidate: ResolvedStream? = null
    private var pageUrl = ""

    /** Porcentaje 0..100 (solo sube). Se llama en el hilo principal. */
    var onProgress: ((Int) -> Unit)? = null

    /** Se llama (una vez, hilo principal) si la página pide verificación humana: hay que mostrarla al usuario. */
    var onNeedsUser: (() -> Unit)? = null
    private var needsFired = false
    private var loadedOnce = false
    private var pagePct = 0
    private var shownPct = 0
    private var startTs = 0L

    /** Llamar desde el hilo principal. [done] se llama UNA vez (hilo principal) con el resultado o null. */
    @SuppressLint("SetJavaScriptEnabled")
    fun resolve(url: String, referer: String? = null, container: ViewGroup? = null, done: (ResolvedStream?) -> Unit) {
        pageUrl = url
        val w = WebView(act)
        web = w
        container?.addView(w, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        with(w.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            userAgentString = userAgent
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            blockNetworkImage = !manual
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        if (manual) w.setBackgroundColor(android.graphics.Color.BLACK)

        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url.toString()
                if (AdBlocker.isAdUrl(u)) return empty()
                note(u)
                // Modo manual (Catálogo 2): detección más amplia de la dirección del video.
                val su = if (manual) (if (handoff) AdBlocker.streamCandidate(u) else null) else u.takeIf { AdBlocker.isStreamUrl(it) }
                if (request.method == "GET" && su != null) {
                    val ref = request.requestHeaders?.get("Referer")?.takeIf { it.isNotEmpty() } ?: pageUrl
                    val found = ResolvedStream(su, ref)
                    if (AdBlocker.isM3u8(su) || AdBlocker.isMpd(su)) {
                        handler.post { finish(found, done) }
                    } else if (manual && (su.contains(".m3u8", true) || su.contains(".mpd", true))) {
                        // Dirección "rara" (la extensión no está al final): se comprueba qué tipo de video es antes de abrirla.
                        handler.post { sniffThenFinish(found, done) }
                    } else {
                        handler.post {
                            if (mp4Candidate == null) {
                                mp4Candidate = found
                                handler.postDelayed({ finish(mp4Candidate, done) }, MP4_GRACE_MS)
                            }
                        }
                    }
                    return empty()
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest): Boolean {
                val s = request.url.scheme?.lowercase()
                if (s != "http" && s != "https") return true
                val u = request.url.toString()
                if (AdBlocker.isAdUrl(u)) return true
                // Una vez cargado el reproductor, no se deja saltar a otro sitio (anuncios / redirecciones).
                if (loadedOnce && request.isForMainFrame &&
                    AdBlocker.registrable(AdBlocker.host(u)) != AdBlocker.registrable(AdBlocker.host(pageUrl))
                ) return true
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                view?.evaluateJavascript(AdBlocker.AD_JS, null)
                view?.evaluateJavascript("window.open=function(){return null};", null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                loadedOnce = true
                if (!manual) kick(0)
            }
        }

        w.webChromeClient = object : WebChromeClient() {
            // Ventanas emergentes (anuncios): siempre bloqueadas.
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean = false

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                pagePct = newProgress
            }
        }

        startTs = SystemClock.uptimeMillis()
        if (!manual) tick()
        val limit = Runnable { finish(mp4Candidate, done) }
        timeoutTask = limit
        handler.postDelayed(limit, if (manual) MANUAL_TIMEOUT_MS else TIMEOUT_MS)
        if (manual && handoff) probe(done)
        if (referer != null) w.loadUrl(url, mapOf("Referer" to referer)) else w.loadUrl(url)
    }

    /**
     * Modo manual: cada segundo mira qué video está reproduciendo la página. Si es un video directo de película
     * (más de 10 min, o un .m3u8 / .mpd) se entrega para abrirlo en ExoPlayer, como en el Catálogo 1.
     */
    private fun probe(done: (ResolvedStream?) -> Unit) {
        if (finished) return
        web?.evaluateJavascript(PROBE_JS) { raw ->
            if (!finished) {
                val txt = try { org.json.JSONTokener(raw ?: "").nextValue() as? String } catch (e: Exception) { null }
                if (!txt.isNullOrEmpty()) {
                    lastProbe = txt
                    try {
                        val o = org.json.JSONObject(txt)
                        val u = o.optString("u")
                        val d = o.optLong("d")
                        if (u.startsWith("http") && !AdBlocker.isAdUrl(u)) {
                            if (AdBlocker.isM3u8(u) || AdBlocker.isMpd(u)) handler.post { finish(ResolvedStream(u, pageUrl), done) }
                            else if (d >= 600L) handler.post { sniffThenFinish(ResolvedStream(u, pageUrl), done) }
                        }
                    } catch (e: Exception) { }
                }
            }
        }
        handler.postDelayed({ probe(done) }, 1_000)
    }

    /**
     * Porcentaje aproximado: la carga de la página cuenta hasta 60% y el resto avanza con el tiempo
     * (hasta 95%) mientras se busca la señal. Al encontrarla salta a 100%.
     */
    private fun tick() {
        if (finished) return
        val elapsed = SystemClock.uptimeMillis() - startTs
        val byTime = (elapsed * 90 / TIMEOUT_MS).toInt()
        val target = maxOf(pagePct * 60 / 100, byTime).coerceAtMost(95)
        if (target > shownPct) {
            shownPct = target
            onProgress?.invoke(shownPct)
        }
        handler.postDelayed({ tick() }, 250)
    }

    /** Cada segundo, un rato, intenta darle "play" a la página para que pida el video. */
    private fun kick(n: Int) {
        if (finished || n > 12) return
        if (!needsFired && onNeedsUser != null) {
            web?.evaluateJavascript(VERIFY_JS) { r ->
                if (r == "true" && !needsFired && !finished) {
                    needsFired = true
                    handler.post { if (!finished) onNeedsUser?.invoke() }
                }
            }
        }
        web?.evaluateJavascript(KICK_JS, null)
        handler.postDelayed({ kick(n + 1) }, 1_000)
    }

    private fun empty() = WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))

    /** Cancela sin llamar a [done]. */
    private var timeoutTask: Runnable? = null
    private var sniffing = false

    /**
     * Una dirección sin .m3u8 / .mpd al final puede ser una lista HLS/DASH disfrazada. ExoPlayer la trataría como un
     * archivo normal y fallaría (ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED). Se lee el inicio para saber qué es y se le avisa.
     */
    private fun sniffThenFinish(found: ResolvedStream, done: (ResolvedStream?) -> Unit) {
        if (sniffing || finished) return
        sniffing = true
        Thread {
            var mime: String? = null
            try {
                val c = java.net.URL(found.url).openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                c.setRequestProperty("User-Agent", userAgent)
                if (found.referer.isNotEmpty()) {
                    c.setRequestProperty("Referer", found.referer)
                    try {
                        val r = android.net.Uri.parse(found.referer)
                        if (r.scheme != null && r.host != null) c.setRequestProperty("Origin", r.scheme + "://" + r.host)
                    } catch (e: Exception) { }
                }
                CookieManager.getInstance().getCookie(found.url)?.let { c.setRequestProperty("Cookie", it) }
                c.setRequestProperty("Range", "bytes=0-1023")
                val ct = (c.contentType ?: "").lowercase()
                val buf = ByteArray(1024)
                val n = c.inputStream.use { it.read(buf) }
                c.disconnect()
                val head = if (n > 0) String(buf, 0, n, Charsets.ISO_8859_1) else ""
                mime = when {
                    head.trimStart().startsWith("#EXTM3U") || ct.contains("mpegurl") -> "application/x-mpegURL"
                    head.contains("<MPD") || ct.contains("dash+xml") -> "application/dash+xml"
                    else -> null
                }
            } catch (e: Exception) { }
            handler.post {
                sniffing = false
                finish(found.copy(mime = mime), done)
            }
        }.start()
    }

    /**
     * Modo manual: cuando el video ya está sonando en la página se quita el límite de tiempo
     * (si no, a los 2 min 30 s se destruía el reproductor y el video se cortaba).
     */
    fun holdOpen() {
        timeoutTask?.let { handler.removeCallbacks(it) }
        timeoutTask = null
    }

    fun cancel() {
        if (finished) return
        finished = true
        cleanup()
    }

    private fun finish(r: ResolvedStream?, done: (ResolvedStream?) -> Unit) {
        if (finished) return
        finished = true
        cleanup()
        if (r != null) {
            lastDebugUrl = r.url
            lastDebug = debugInfo()
        }
        if (r != null) onProgress?.invoke(100)
        if (!act.isFinishing && !act.isDestroyed) done(r)
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        try {
            (web?.parent as? ViewGroup)?.removeView(web)
            web?.stopLoading()
            web?.loadUrl("about:blank")
            web?.destroy()
        } catch (e: Exception) { }
        web = null
    }
}
