package com.estebanruiz.estebantv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.util.concurrent.Executors

/** Una película de la guía: nombre, año, género, calidad, idioma, sinopsis corta, carátula y su página. */
data class Movie(
    val id: String,
    val title: String,
    val year: String,
    val genre: String,
    val quality: String,
    val lang: String,
    val synopsis: String,
    val cover: String,
    val url: String,
    /** La misma película en la OTRA web (si está en las dos), para probar los dos reproductores al darle Ver. */
    val alt: String = "",
)

/** Un reproductor de una película (la dirección del embed y la página desde la que se pide). */
data class MovieOpt(val url: String, val referer: String)

/** Datos extra que salen al abrir la página de la película: sinopsis completa, director, reparto. */
data class MovieDetail(
    val synopsis: String,
    val director: String,
    val cast: List<String>,
    val alt: String,
    val poster: String,
)

/**
 * Una lista de la guía (Inicio, Últimas, un género…). Cada lista puede venir de dos webs a la vez:
 * [pattern] es la dirección en LocoPelis y [flix] la de Pelisflix (vacía = esa web no tiene esa lista).
 * Si [paged] es true llevan {p} donde va el número de página.
 */
data class MovieFeed(
    val key: String,
    val label: String,
    val pattern: String,
    val paged: Boolean,
    val genre: String = "",
    val flix: String = "",
) {
    fun urlFor(page: Int): String = if (paged) pattern.replace("{p}", page.toString()) else pattern

    /** Pelisflix: la página 1 va sin "/page/1" (así la web no redirige). */
    fun flixUrlFor(page: Int): String {
        if (flix.isEmpty()) return ""
        if (!paged) return flix
        return if (page <= 1) flix.replace("/page/{p}", "") else flix.replace("{p}", page.toString())
    }
}

/** Las dos webs de películas que se juntan en una sola guía. */
object MovieSources {
    const val LOCO = "https://www.locopelis.com"
    const val FLIX = "https://pelisflix200.digital"

    /** Dirección desde la que se pide el video (Referer) según la web de la película. */
    fun referer(movieUrl: String): String = if (movieUrl.contains("pelisflix")) "$FLIX/" else "$LOCO/"
}

/** Listas disponibles. Para agregar o quitar un género edita [categories]: Cat("Nombre", "slug en LocoPelis", "slug en Pelisflix"). */
object MovieFeeds {
    private const val BASE = MovieSources.LOCO
    private const val FLIX = MovieSources.FLIX

    /** null = esa web no tiene ese género. */
    private class Cat(val name: String, val loco: String?, val flix: String?)

    private val categories = listOf(
        Cat("Acción", "accion", "accion"),
        Cat("Animación", "animacion-e-infantil", "animacion"),
        Cat("Anime", "anime", null),
        Cat("Artes marciales", "artes-marciales", null),
        Cat("Aventura", "aventura", "aventura"),
        Cat("Bélico", "belico", "belica"),
        Cat("Ciencia ficción", "ciencia-ficcion", "ciencia-ficcion"),
        Cat("Comedia", "comedia", "comedia"),
        Cat("Crimen", null, "crimen"),
        Cat("Deporte", "deporte", null),
        Cat("Documentales", "documentales", "documental"),
        Cat("Drama", "drama", "drama"),
        Cat("Estrenos", null, "estrenos"),
        Cat("Familia", null, "familia"),
        Cat("Fantasía", "fantasia", "fantasia"),
        Cat("Intriga", "intriga", null),
        Cat("Musical", "musical", null),
        Cat("Religiosas", "religiosas", null),
        Cat("Romance", "romance", "romance"),
        Cat("Suspenso", "suspenso", "suspense"),
        Cat("Terror", "terror", "terror"),
        Cat("Western", "western", null),
    )

    /** Búsqueda (buscador de cada web, en segundo plano). Si una web cambia, se ajusta aquí. */
    fun searchFeed(query: String): MovieFeed {
        val q = java.net.URLEncoder.encode(query, "UTF-8")
        return MovieFeed("search", "Búsqueda", "$BASE/page/{p}/?s=$q", true, flix = "$FLIX/?s=$q")
    }

    val list: List<MovieFeed> = listOf(
        MovieFeed("resume", "⏱ Seguir viendo", "", false),
        MovieFeed("inicio", "Inicio", "$BASE/page/{p}/", true, flix = "$FLIX/peliculas-online/page/{p}"),
        MovieFeed("ultimas", "Últimas", "$BASE/pelicula/ultimas-peliculas", false, flix = "$FLIX/peliculas-online"),
        MovieFeed("vistas", "Más vistas", "$BASE/pelicula/peliculas-mas-vistas", false),
    ) + categories.map { c ->
        MovieFeed(
            "cat_" + (c.loco ?: c.flix),
            c.name,
            if (c.loco != null) "$BASE/categoria/${c.loco}/page/{p}/" else "",
            true,
            c.name,
            if (c.flix != null) "$FLIX/genero/${c.flix}/page/{p}" else "",
        )
    }
}

/** Minúsculas y sin tildes, para buscar "accion" y encontrar "Acción". */
fun movieNorm(s: String): String =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

private val STOP_WORDS = setOf("el", "la", "los", "las", "un", "una", "de", "del", "y", "en", "a", "al", "lo")

/** True si el nombre de la película (o su título alternativo) contiene todas las palabras escritas en el buscador. */
fun movieMatches(m: Movie, query: String): Boolean {
    val words = movieNorm(query).split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
    val key = words.filter { it !in STOP_WORDS }.ifEmpty { words }
    if (key.isEmpty()) return true
    val hay = movieNorm(m.title).replace(Regex("[^a-z0-9]+"), " ")
    return key.all { hay.contains(it) }
}

private fun movieSrc(m: Movie): Int = if (m.url.contains("pelisflix")) 1 else 0

private fun movieKey(m: Movie): String = movieNorm(m.title).replace(Regex("[^a-z0-9]+"), "")

/**
 * Agrega [incoming] a [base] sin repetir. Si una película ya está (mismo nombre y año) pero viene de la otra web,
 * no se agrega otra: se guarda su dirección en [Movie.alt] para poder probar los dos reproductores.
 * Devuelve cuántas películas se agregaron o completaron (0 = no hubo nada nuevo).
 */
fun mergeInto(base: MutableList<Movie>, incoming: List<Movie>): Int {
    var changes = 0
    val index = HashMap<String, MutableList<Int>>()
    base.forEachIndexed { i, m -> index.getOrPut(movieKey(m)) { ArrayList() }.add(i) }
    for (m in incoming) {
        val idxs = index[movieKey(m)].orEmpty()
        var handled = false
        for (i in idxs) {
            val b = base[i]
            val yearOk = b.year.isEmpty() || m.year.isEmpty() || b.year == m.year
            if (!yearOk) continue
            if (b.id == m.id) { handled = true; break }
            if (movieSrc(b) != movieSrc(m)) {
                if (b.alt.isEmpty()) {
                    base[i] = b.copy(
                        alt = m.url,
                        cover = b.cover.ifEmpty { m.cover },
                        synopsis = b.synopsis.ifEmpty { m.synopsis },
                        genre = b.genre.ifEmpty { m.genre },
                        year = b.year.ifEmpty { m.year },
                        quality = b.quality.ifEmpty { m.quality },
                        lang = b.lang.ifEmpty { m.lang },
                    )
                    changes++
                }
                handled = true
                break
            }
        }
        if (!handled) {
            base.add(m)
            index.getOrPut(movieKey(m)) { ArrayList() }.add(base.size - 1)
            changes++
        }
    }
    return changes
}

/** Guarda la primera página de cada lista (SharedPreferences "movies") para mostrarla al instante. */
class MovieStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("movies", Context.MODE_PRIVATE)

    fun cached(key: String): List<Movie> {
        val raw = p.getString("feed_$key", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<Movie>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Movie(
                        o.optString("id"), o.optString("title"), o.optString("year"), o.optString("genre"),
                        o.optString("quality"), o.optString("lang"), o.optString("syn"), o.optString("cover"), o.optString("url"), o.optString("alt"),
                    )
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(key: String, list: List<Movie>) {
        val arr = JSONArray()
        for (m in list.take(60)) {
            arr.put(
                JSONObject().put("id", m.id).put("title", m.title).put("year", m.year).put("genre", m.genre)
                    .put("quality", m.quality).put("lang", m.lang).put("syn", m.synopsis)
                    .put("cover", m.cover).put("url", m.url).put("alt", m.alt)
            )
        }
        p.edit().putString("feed_$key", arr.toString()).apply()
    }
}

/**
 * Lee la guía de LocoPelis con un WebView invisible (igual que la Agenda):
 *  - [fetchPage]: una página de películas (carátula, título, año, género, calidad, idioma y sinopsis corta).
 *  - [fetchDetail]: la página de una película (sinopsis completa, director, reparto).
 * Si la web cambia su diseño, se ajusta LIST_JS / DETAIL_JS.
 */
class MovieFetcher(private val ctx: Context) {
    companion object {
        // Cada película es un enlace /pelicula/NUMERO/... con la carátula dentro. Se sube por el HTML hasta el
        // bloque más grande que solo contenga esa película y de ahí se saca el texto (sinopsis, género, calidad…).
        private const val LIST_JS = """
(function(){
  try{
    var as=document.querySelectorAll('a[href*="/pelicula/"]');
    function ids(n){var s={},c=0,l=n.querySelectorAll('a[href*="/pelicula/"]');for(var k=0;k<l.length;k++){if(!s[l[k].href]){s[l[k].href]=1;c++;}}return c;}
    function ids2(n,m){var c=0,l=n.querySelectorAll('a[href]');for(var k=0;k<l.length;k++){if(m[l[k].href]&&l[k].querySelector('img'))c++;}return c;}
    var seen={},out=[];
    for(var i=0;i<as.length;i++){
      var a=as[i],im=a.querySelector('img'); if(!im) continue;
      var h=a.href||''; if(!/\/pelicula\/\d+\//.test(h)||seen[h]) continue;
      var cov=im.getAttribute('data-src')||im.getAttribute('data-lazy-src')||im.getAttribute('src')||'';
      try{cov=new URL(cov,location.href).href;}catch(e){}
      if(cov.indexOf('/files/uploads/')<0) continue;
      seen[h]=1;
      var c=a,hops=0;
      while(c.parentElement && hops<5 && c.parentElement!==document.body && ids(c.parentElement)===1){c=c.parentElement;hops++;}
      var tx=(c.textContent||'').replace(/\s+/g,' ').trim();
      out.push({u:h,i:cov,t:a.getAttribute('title')||im.getAttribute('alt')||'',x:tx.slice(0,1500)});
    }
    if(out.length===0){
      // Respaldo: si la web cambió sus direcciones, se toma cualquier enlace con carátula (imagen de póster) de la misma web.
      var all=document.querySelectorAll('a[href]'), s2={}, alt=[];
      for(var q=0;q<all.length;q++){
        var b=all[q], im2=b.querySelector('img'); if(!im2) continue;
        var h2=b.href||''; if(h2.indexOf(location.origin)!==0||s2[h2]) continue;
        if(/\/(categoria|category|tag|actor|page|login|registro|contacto|dmca|terminos)(\/|$)/i.test(h2)) continue;
        if(h2.replace(/\/+$/,'')===location.origin) continue;
        var c2=im2.getAttribute('data-src')||im2.getAttribute('data-lazy-src')||im2.getAttribute('src')||'';
        try{c2=new URL(c2,location.href).href;}catch(e){}
        if(!/\.(jpe?g|png|webp)(\?|$)/i.test(c2)||/logo|icon|avatar|banner|\/Temas\//i.test(c2)) continue;
        s2[h2]=1;
        var k=b,hp=0;
        while(k.parentElement && hp<5 && k.parentElement!==document.body && ids2(k.parentElement,s2)<=1){k=k.parentElement;hp++;}
        alt.push({u:h2,i:c2,t:b.getAttribute('title')||im2.getAttribute('alt')||'',x:(k.textContent||'').replace(/\s+/g,' ').trim().slice(0,1500)});
      }
      if(alt.length>=6) out=alt;
    }
    return JSON.stringify({e:out});
  }catch(x){ return JSON.stringify({e:[],err:String(x)}); }
})()
"""

        // Página de una película: sinopsis (primer párrafo largo después del título), director, reparto y póster grande.
        private const val DETAIL_JS = """
(function(){
  try{
    var h=document.querySelector('h1'); if(!h) return JSON.stringify({});
    function clean(s){return (s||'').replace(/\s+/g,' ').trim();}
    var d={s:'',dir:'',c:[],alt:'',img:''};
    var og=document.querySelector('meta[property="og:image"]'); if(og) d.img=og.content||'';
    var els=document.querySelectorAll('p,div');
    for(var i=0;i<els.length;i++){
      var e=els[i];
      if(!(h.compareDocumentPosition(e)&4)) continue;
      var t=clean(e.textContent);
      if(!d.dir && /^Director:?\s+\S/.test(t) && t.length<80){ d.dir=t.replace(/^Director:?\s+/,''); continue; }
      var leaf=(e.children.length===0)||e.tagName==='P';
      if(!leaf) continue;
      if(!d.alt && /^T.tulo alternativo/i.test(t)){ d.alt=t.replace(/^T.tulo alternativo:?\s*/i,''); continue; }
      if(!d.s && t.length>70 && !/^Leer m/i.test(t) && t.indexOf('LocoPelis')<0 && t.indexOf('Est\u00e1s a un clic')<0) d.s=t;
    }
    if(!d.s){ var md=document.querySelector('meta[name="description"]'); if(md) d.s=clean(md.content); }
    var as=document.querySelectorAll('a[href*="/actor/"]'),seen={};
    for(var k=0;k<as.length && d.c.length<8;k++){
      var n=clean(as[k].textContent); if(n && !seen[n]){ seen[n]=1; d.c.push(n); }
    }
    return JSON.stringify(d);
  }catch(x){ return JSON.stringify({}); }
})()
"""

        // Página de la película: pulsa las pestañas "Reproductor Opción 1/2" y el botón de play ("verifica que eres humano")
        // y devuelve las direcciones de los reproductores (iframes) que la página va armando.
        private const val EMBED_JS = """
(function(){
  try{
    function clk(e){
      try{ e.click(); }catch(x){}
      try{ ['mousedown','mouseup','click'].forEach(function(t){ e.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window})); }); }catch(x){}
    }
    window.__etv=(window.__etv||0)+1;
    var tabs=document.querySelectorAll('a[href^="#ms"],[data-target^="#ms"],[data-bs-target^="#ms"]');
    if(tabs.length){ clk(tabs[(window.__etv-1)%tabs.length]); }
    var srv=document.querySelectorAll('[data-server],[data-tplayernv],[class*="server"] li,[class*="option"] li,.options li');
    if(srv.length){ clk(srv[(window.__etv-1)%srv.length]); }
    var els=document.querySelectorAll('div,button,a,span');
    for(var i=0;i<els.length;i++){
      var e=els[i]; if(e.children.length>4) continue;
      var t=(e.textContent||'').toLowerCase();
      if(t.length<220 && t.indexOf('eres humano')>=0){ clk(e); if(e.parentElement) clk(e.parentElement); }
    }
    var sel=['.play-button','.btn-play','#play','.play','.vjs-big-play-button','[aria-label="Play"]','[title="Play"]'];
    for(var j=0;j<sel.length;j++){ var b=document.querySelector(sel[j]); if(b) clk(b); }
    var out=[],seen={};
    function add(u){
      if(!u) return;
      try{ u=new URL(u,location.href).href; }catch(x){ return; }
      if(u.indexOf('http')!==0 || seen[u]) return;
      seen[u]=1; out.push(u);
    }
    document.querySelectorAll('iframe').forEach(function(f){
      add(f.getAttribute('src')); add(f.getAttribute('data-src')); add(f.getAttribute('data-lazy-src'));
    });
    document.querySelectorAll('[data-embed],[data-url],[data-video],[data-iframe],[data-player],[data-src]').forEach(function(e){
      if(e.tagName==='IMG') return;
      ['data-embed','data-url','data-video','data-iframe','data-player','data-src'].forEach(function(a){ add(e.getAttribute(a)); });
    });
    return JSON.stringify({u:out});
  }catch(x){ return JSON.stringify({u:[]}); }
})()
"""

        // Pelisflix: cada película es un <li> con su carátula, título, año, duración, sinopsis corta y géneros.
        // Con búsqueda ([Q] no vacío) solo devuelve las que coinciden y, si la web no las trae, prueba con su formulario de búsqueda.
        private const val FLIX_LIST_JS = """
(function(){
  try{
    var Q='__Q__';
    function txt(e){return (e.textContent||'').replace(/\s+/g,' ').trim();}
    function nz(s){return (s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');}
    var out=[],seen={};
    var as=document.querySelectorAll('a[href*="/pelicula/"]');
    for(var i=0;i<as.length;i++){
      var a=as[i],h=a.href||''; if(seen[h]) continue;
      var li=a.closest('li'); if(!li) continue;
      var im=li.querySelector('img'); if(!im) continue;
      var alt=im.getAttribute('alt')||'';
      var cov=im.getAttribute('data-src')||im.getAttribute('data-lazy-src')||im.getAttribute('data-original')||im.getAttribute('src')||'';
      try{cov=new URL(cov,location.href).href;}catch(e){}
      if(/^background/i.test(alt)||cov.indexOf('/b/v2/')>=0||cov.indexOf('data:')===0) continue;
      var t=alt; if(!t) t=a.getAttribute('title')||'';
      if(!t){ var ls=li.querySelectorAll('a[href="'+h+'"]'); for(var k=0;k<ls.length;k++){ var tt=txt(ls[k]).replace(/^\d{4}\s+/,''); if(tt) t=tt; } }
      if(!t) continue;
      seen[h]=1;
      out.push({u:h,i:cov,t:t,x:txt(li).slice(0,1500)});
    }
    if(!Q) return JSON.stringify({e:out});
    var words=nz(Q).split(/\s+/).filter(Boolean);
    var hits=out.filter(function(o){var n=nz(o.t);return words.every(function(w){return n.indexOf(w)>=0;});});
    if(hits.length>0) return JSON.stringify({e:hits});
    if(window.name!=='etv_s1'){
      var fm=document.querySelector('form[role="search"],form[action*="search"],form[action*="buscar"]');
      if(!fm){ var ins=document.querySelectorAll('input[type="search"],input[name="s"],input[name="q"],input[name="query"],input[name="keyword"]'); if(ins.length) fm=ins[0].form; }
      var inp=fm&&fm.querySelector('input[type="search"],input[type="text"],input[name]');
      if(fm&&inp&&inp.name){
        window.name='etv_s1';
        var u=new URL(fm.getAttribute('action')||location.href,location.href);
        u.search=''; u.searchParams.set(inp.name,Q); location.href=u.href;
        return JSON.stringify({nav:1});
      }
    }
    window.__etvN=(window.__etvN||0)+1;
    return JSON.stringify(window.__etvN>=6?{e:[],done:1}:{wait:1});
  }catch(x){ return JSON.stringify({e:[],err:String(x)}); }
})()
"""

        private val FX_YEAR = Regex("((?:19|20)\\d{2})(?=\\d{0,2}h|\\d{1,2}min)")
        private val FX_GENRE = Regex("G.{0,2}nero\\s*:?\\s*(.*?)\\s*(?:Ver\\s+(?:Online|Ahora)|$)")
        private val FX_SYN = Regex("\\d{1,2}\\s?min\\s*(.*?)\\s*G.{0,2}nero\\s*:")

        fun parseFlixList(json: String): List<Movie>? {
            return try {
                val o = JSONObject(json)
                val arr = o.optJSONArray("e") ?: return null
                if (arr.length() == 0) return if (o.optBoolean("done")) emptyList() else null
                val out = ArrayList<Movie>()
                for (i in 0 until arr.length()) {
                    val e = arr.getJSONObject(i)
                    val url = e.optString("u")
                    val slug = url.trimEnd('/').substringAfterLast('/')
                    if (slug.isEmpty()) continue
                    val title = e.optString("t").replace(Regex("^Ver\\s+"), "").replace(Regex("^\\d{4}\\s+"), "").trim()
                    if (title.isEmpty()) continue
                    val x = e.optString("x")
                    val year = FX_YEAR.find(x)?.groupValues?.get(1) ?: Regex("^(\\d{4})\\s").find(x)?.groupValues?.get(1).orEmpty()
                    val genre = FX_GENRE.find(x)?.groupValues?.get(1)?.trim()?.trimEnd(',')?.trim().orEmpty()
                    val syn = FX_SYN.find(x)?.groupValues?.get(1)?.trim().orEmpty()
                    out.add(Movie("fx:$slug", title, year, genre, "", "", syn, e.optString("i"), url))
                }
                if (out.isEmpty()) null else out
            } catch (e: Exception) {
                null
            }
        }

        /** Junta listas de varias webs: una de cada una por turno; la misma película en las dos sale UNA sola vez. */
        fun mergeMovies(lists: List<List<Movie>>): List<Movie> {
            if (lists.size == 1) return lists[0]
            val out = ArrayList<Movie>()
            var i = 0
            while (lists.any { i < it.size }) {
                lists.forEach { l -> l.getOrNull(i)?.let { mergeInto(out, listOf(it)) } }
                i++
            }
            return out
        }

        private val ASSET_RE = Regex("\\.(jpe?g|png|webp|gif|svg|ico|css|js|woff2?)(\\?.*)?$", RegexOption.IGNORE_CASE)

        fun parseEmbeds(json: String): List<String>? {
            return try {
                val arr = JSONObject(json).getJSONArray("u")
                val out = ArrayList<String>()
                for (i in 0 until arr.length()) {
                    val u = arr.getString(i)
                    if (u.contains("about:blank") || ASSET_RE.containsMatchIn(u)) continue
                    if (u.contains("image.tmdb.org") || u.contains("/Temas/") || u.contains("/files/uploads/")) continue
                    if (u.contains("/actor/") || u.contains("/categoria/") || u.contains("/tag/")) continue
                    if (AdBlocker.isAdUrl(u)) continue
                    if (u !in out) out.add(u)
                }
                if (out.isEmpty()) null else out
            } catch (e: Exception) {
                null
            }
        }

        private val TITLE_RE = Regex("^Ver\\s+(.+?)(?:\\s*\\((\\d{4})\\))?\\s+online gratis.*$", RegexOption.IGNORE_CASE)
        private val GEN_RE = Regex("G.{0,2}nero\\s*:?\\s*([^,]*?)\\s*,\\s*(\\d{4})")
        private val GEN_START = Regex("G.{0,2}nero\\s*:")
        private val QUAL_RE = Regex("Calidad\\s*:?\\s*(.+?)\\s+Idioma")
        private val LANG_RE = Regex("Idioma\\s*:?\\s*(\\S+)")
        private val ID_RE = Regex("/pelicula/(\\d+)/")

        fun parseList(json: String): List<Movie>? {
            return try {
                val arr = JSONObject(json).getJSONArray("e")
                val all = ArrayList<Movie>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val url = o.optString("u")
                    val id = ID_RE.find(url)?.groupValues?.get(1)
                        ?: url.trimEnd('/').substringAfterLast('/').takeIf { it.isNotEmpty() && !url.contains("?") } ?: continue
                    val t = o.optString("t").trim()
                    val tm = TITLE_RE.find(t)
                    val title = (tm?.groupValues?.get(1) ?: t.removePrefix("Ver ").trim()).trim()
                    if (title.isEmpty()) continue
                    val x = o.optString("x")

                    var syn = ""
                    val si = x.indexOf("Sinopsis")
                    if (si >= 0) {
                        var s = x.substring(si + 8).trim()
                        val gi = GEN_START.find(s)?.range?.first ?: -1
                        if (gi >= 0) s = s.substring(0, gi)
                        s = s.trim()
                        // El título viene repetido al inicio de la sinopsis: se quita.
                        for (k in minOf(title.length, 40) downTo 5) {
                            if (s.startsWith(title.take(k), ignoreCase = true)) {
                                s = s.substring(k).trim()
                                break
                            }
                        }
                        syn = s
                    }

                    val gm = GEN_RE.find(x)
                    val genre = gm?.groupValues?.get(1)?.trim().orEmpty()
                    var year = tm?.groupValues?.get(2).orEmpty()
                    if (year.isEmpty()) year = gm?.groupValues?.get(2).orEmpty()
                    val quality = QUAL_RE.find(x)?.groupValues?.get(1)?.trim().orEmpty()
                    val lang = LANG_RE.find(x)?.groupValues?.get(1)?.trim().orEmpty()
                    all.add(Movie(id, title, year, genre, quality, lang, syn, o.optString("i"), url))
                }
                // Si la página trae la lista principal (con sinopsis) más carruseles de "últimas", nos quedamos con la principal.
                val main = all.filter { it.synopsis.isNotEmpty() }
                val res = if (main.size >= 6) main else all
                if (res.isEmpty()) null else res
            } catch (e: Exception) {
                null
            }
        }

        fun parseDetail(json: String): MovieDetail? {
            return try {
                val o = JSONObject(json)
                val syn = o.optString("s")
                val ca = o.optJSONArray("c") ?: JSONArray()
                if (syn.isEmpty() && ca.length() == 0) return null
                val cast = ArrayList<String>()
                for (i in 0 until ca.length()) cast.add(ca.getString(i))
                MovieDetail(syn, o.optString("dir"), cast, o.optString("alt"), o.optString("img"))
            } catch (e: Exception) {
                null
            }
        }
    }

    /**
     * Baja una página de una lista de las DOS webs a la vez y las junta (una de cada una, sin repetidas).
     * Si una web no responde se muestra solo la otra; [done] recibe null solo si fallan las dos.
     */
    fun fetchFeed(f: MovieFeed, query: String, page: Int, done: (List<Movie>?) -> Unit) {
        val handler = Handler(Looper.getMainLooper())
        val jobs = ArrayList<((List<Movie>?) -> Unit) -> Unit>()
        val locoUrl = f.urlFor(page)
        if (locoUrl.isNotEmpty()) jobs.add { cb -> fetchPage(locoUrl, cb) }
        // El buscador de Pelisflix solo se usa en la primera página.
        val flixUrl = if (f.key == "search" && page > 1) "" else f.flixUrlFor(page)
        if (flixUrl.isNotEmpty()) jobs.add { cb -> fetchFlixPage(flixUrl, if (f.key == "search") query else "", cb) }
        if (jobs.isEmpty()) {
            done(null)
            return
        }
        val results = arrayOfNulls<List<Movie>>(jobs.size)
        var responded = 0
        var finished = false
        var graceStarted = false
        fun finish() {
            if (finished) return
            finished = true
            handler.removeCallbacksAndMessages(null)
            val got = results.filterNotNull()
            done(if (got.isEmpty()) null else mergeMovies(got))
        }
        jobs.forEachIndexed { i, job ->
            job { r ->
                if (finished) return@job
                results[i] = r
                responded++
                if (responded >= jobs.size) finish()
                else if (!r.isNullOrEmpty() && !graceStarted) {
                    // Una web ya respondió: a la otra se le da un rato más y se sigue sin ella.
                    graceStarted = true
                    handler.postDelayed({ finish() }, 6_000)
                }
            }
        }
    }

    fun fetchFlixPage(url: String, query: String, done: (List<Movie>?) -> Unit) {
        val q = query.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
        PageScraper(ctx, url, FLIX_LIST_JS.replace("__Q__", q), { parseFlixList(it) }, chromeUa = true).fetch(done)
    }

    fun fetchPage(url: String, done: (List<Movie>?) -> Unit) {
        PageScraper(ctx, url, LIST_JS, { parseList(it) }, chromeUa = true).fetch(done)
    }

    /** Busca los reproductores (Opción 1, Opción 2…) de la página de una película. Null si no aparece ninguno. */
    fun fetchEmbeds(url: String, done: (List<String>?) -> Unit) {
        PageScraper(ctx, url, EMBED_JS, { parseEmbeds(it) }).fetch(done)
    }

    fun fetchDetail(url: String, done: (MovieDetail?) -> Unit) {
        PageScraper(ctx, url, DETAIL_JS, { parseDetail(it) }, chromeUa = true).fetch(done)
    }
}

/** Descarga carátulas en segundo plano y las guarda en memoria para no bajarlas dos veces. */
object MovieImages {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val io = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    /** Pone la imagen de [url] en [iv]; si el ImageView ya se usó para otra imagen, se ignora el resultado tardío. */
    fun load(url: String, iv: ImageView) {
        iv.tag = url
        if (url.isEmpty()) return
        cache.get(url)?.let { iv.setImageBitmap(it); return }
        io.execute {
            val b = download(url)
            if (b != null) {
                cache.put(url, b)
                main.post { if (iv.tag == url) iv.setImageBitmap(b) }
            }
        }
    }

    private fun download(u: String): Bitmap? = try {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")
        if (u.contains("locopelis.com")) c.setRequestProperty("Referer", "https://www.locopelis.com/")
        else if (u.contains("pelisflix")) c.setRequestProperty("Referer", "https://pelisflix200.digital/")
        val bytes = c.inputStream.use { it.readBytes() }
        c.disconnect()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 400) sample *= 2
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    } catch (e: Exception) {
        null
    }
}
