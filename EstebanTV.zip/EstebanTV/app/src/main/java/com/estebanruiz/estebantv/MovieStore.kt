package com.estebanruiz.estebantv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.util.concurrent.Executors

/** Una película de la guía: nombre, año, género, calidad, idioma, sinopsis corta, carátula y su página. */
data class Movie(
    val id: String,
    val title: String,
    val year: String,
    val genre: String,
    val quality: String,
    val lang: String,
    val synopsis: String,
    val cover: String,
    val url: String,
    /** La misma película en la OTRA web (si está en las dos), para probar los dos reproductores al darle Ver. */
    val alt: String = "",
)

/** Un reproductor de una película (la dirección del embed y la página desde la que se pide). */
data class MovieOpt(val url: String, val referer: String)

/** Datos extra que salen al abrir la página de la película: sinopsis completa, director, reparto. */
data class MovieDetail(
    val synopsis: String,
    val director: String,
    val cast: List<String>,
    val alt: String,
    val poster: String,
    /** 1 = dato estructurado (muy fiable) … 5 = descripción genérica de la página. */
    val rank: Int = 4,
    val fromPedia: Boolean = false,
)

/**
 * Una lista de la guía (Inicio, Últimas, un género…). Cada lista puede venir de dos webs a la vez:
 * [pattern] es la dirección en LocoPelis y [pedia] la de PelisPedia (vacía = esa web no tiene esa lista).
 * Si [paged] es true llevan {p} donde va el número de página.
 */
data class MovieFeed(
    val key: String,
    val label: String,
    val pattern: String,
    val paged: Boolean,
    val genre: String = "",
    val pedia: String = "",
    /** PelisPedia pagina con ?page=N (LocoPelis con /page/N/): cada web puede tener paginación distinta. */
    val pediaPaged: Boolean = paged,
) {
    fun urlFor(page: Int): String {
        val u = if (paged) pattern.replace("{p}", page.toString()) else pattern
        return if (key == "search" && page == 1) u.replace("/page/1/", "/") else u
    }

    /** PelisPedia tiene sus propias direcciones: /peliculas?page=N, /peliculas/populares, /generos/NOMBRE. */
    fun pediaUrlFor(page: Int): String = if (pedia.isEmpty()) "" else if (pediaPaged) pedia.replace("{p}", page.toString()) else pedia

    /** Hay más páginas que pedir en alguna de las dos webs. */
    val hasMore: Boolean get() = paged || pediaPaged
}

/** Las dos webs de películas que se juntan en una sola guía. */
object MovieSources {
    const val LOCO = "https://www.locopelis.com"
    const val PEDIA = "https://pelispedia.mov"

    /** Dirección desde la que se pide el video (Referer) según la web de la película. */
    fun referer(movieUrl: String): String = if (movieUrl.contains("pelispedia")) "$PEDIA/" else "$LOCO/"
}

/** Listas disponibles. Para agregar o quitar un género edita [categories]: Cat("Nombre", "slug en LocoPelis", "slug en PelisPedia"). */
object MovieFeeds {
    private const val BASE = MovieSources.LOCO
    private const val PEDIA = MovieSources.PEDIA

    /** null = esa web no tiene ese género. Cada web usa sus propios nombres de género. */
    private class Cat(val name: String, val loco: String?, val pedia: String?)

    private val categories = listOf(
        Cat("Acción", "accion", "accion"),
        Cat("Animación", "animacion-e-infantil", "animacion"),
        Cat("Anime", "anime", null),
        Cat("Artes marciales", "artes-marciales", null),
        Cat("Aventura", "aventura", "aventura"),
        Cat("Bélico", "belico", "belica"),
        Cat("Ciencia ficción", "ciencia-ficcion", "ciencia-ficcion"),
        Cat("Comedia", "comedia", "comedia"),
        Cat("Crimen", null, "crimen"),
        Cat("Deporte", "deporte", null),
        Cat("Documentales", "documentales", "documental"),
        Cat("Drama", "drama", "drama"),
        Cat("Familia", null, "familia"),
        Cat("Fantasía", "fantasia", "fantasia"),
        Cat("Guerra", null, "guerra"),
        Cat("Historia", null, "historia"),
        Cat("Intriga", "intriga", "misterio"),
        Cat("Musical", "musical", null),
        Cat("Religiosas", "religiosas", null),
        Cat("Romance", "romance", "romance"),
        Cat("Suspenso", "suspenso", "suspense"),
        Cat("Terror", "terror", "terror"),
        Cat("Western", "western", "western"),
    )

    /** Búsqueda: LocoPelis por su dirección de búsqueda; PelisPedia busca su formulario solo (ver MovieFetcher.fetchFeed). */
    fun searchFeed(query: String): MovieFeed {
        val q = java.net.URLEncoder.encode(query, "UTF-8")
        return MovieFeed("search", "Búsqueda", "$BASE/page/{p}/?s=$q", true, pedia = "search")
    }

    val list: List<MovieFeed> = listOf(
        MovieFeed("resume", "⏱ Seguir viendo", "", false),
        MovieFeed("inicio", "Inicio", "$BASE/page/{p}/", true, pedia = "$PEDIA/peliculas?page={p}", pediaPaged = true),
        MovieFeed("ultimas", "Últimas", "$BASE/pelicula/ultimas-peliculas", false, pedia = "$PEDIA/peliculas?page={p}", pediaPaged = true),
        MovieFeed("vistas", "Más vistas", "$BASE/pelicula/peliculas-mas-vistas", false, pedia = "$PEDIA/peliculas/populares?page={p}", pediaPaged = true),
    ) + categories.map { c ->
        MovieFeed(
            "cat_" + (c.loco ?: c.pedia),
            c.name,
            if (c.loco != null) "$BASE/categoria/${c.loco}/page/{p}/" else "",
            c.loco != null,
            c.name,
            if (c.pedia != null) "$PEDIA/generos/${c.pedia}?page={p}" else "",
            c.pedia != null,
        )
    }
}

/** Minúsculas y sin tildes, para buscar "accion" y encontrar "Acción". */
fun movieNorm(s: String): String =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

private val STOP_WORDS = setOf("el", "la", "los", "las", "un", "una", "de", "del", "y", "en", "a", "al", "lo")

/** True si el nombre de la película (o su título alternativo) contiene todas las palabras escritas en el buscador. */
fun movieMatches(m: Movie, query: String): Boolean {
    val words = movieNorm(query).split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
    val key = words.filter { it !in STOP_WORDS }.ifEmpty { words }
    if (key.isEmpty()) return true
    val hay = movieNorm(m.title).replace(Regex("[^a-z0-9]+"), " ")
    return key.all { hay.contains(it) }
}

private fun movieSrc(m: Movie): Int = if (m.url.contains("pelispedia")) 1 else 0

private fun movieKey(m: Movie): String = movieNorm(m.title).replace(Regex("[^a-z0-9]+"), "")

/**
 * Agrega [incoming] a [base] sin repetir. Si una película ya está (mismo nombre y año) pero viene de la otra web,
 * no se agrega otra: se guarda su dirección en [Movie.alt] para poder probar los dos reproductores.
 * Devuelve cuántas películas se agregaron o completaron (0 = no hubo nada nuevo).
 */
fun mergeInto(base: MutableList<Movie>, incoming: List<Movie>): Int {
    var changes = 0
    val index = HashMap<String, MutableList<Int>>()
    base.forEachIndexed { i, m -> index.getOrPut(movieKey(m)) { ArrayList() }.add(i) }
    for (m in incoming) {
        val idxs = index[movieKey(m)].orEmpty()
        var handled = false
        for (i in idxs) {
            val b = base[i]
            val yearOk = b.year.isEmpty() || m.year.isEmpty() || b.year == m.year
            if (!yearOk) continue
            if (b.id == m.id) { handled = true; break }
            if (movieSrc(b) != movieSrc(m)) {
                if (b.alt.isEmpty()) {
                    base[i] = b.copy(
                        alt = m.url,
                        cover = b.cover.ifEmpty { m.cover },
                        synopsis = b.synopsis.ifEmpty { m.synopsis },
                        genre = b.genre.ifEmpty { m.genre },
                        year = b.year.ifEmpty { m.year },
                        quality = b.quality.ifEmpty { m.quality },
                        lang = b.lang.ifEmpty { m.lang },
                    )
                    changes++
                }
                handled = true
                break
            }
        }
        if (!handled) {
            base.add(m)
            index.getOrPut(movieKey(m)) { ArrayList() }.add(base.size - 1)
            changes++
        }
    }
    return changes
}

/** Guarda la primera página de cada lista (SharedPreferences "movies") para mostrarla al instante. */
class MovieStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("movies", Context.MODE_PRIVATE)

    fun cached(key: String): List<Movie> {
        val raw = p.getString("feed_$key", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<Movie>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Movie(
                        o.optString("id"), o.optString("title"), o.optString("year"), o.optString("genre"),
                        o.optString("quality"), o.optString("lang"), o.optString("syn"), o.optString("cover"), o.optString("url"), o.optString("alt"),
                    )
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Busca en todas las listas guardadas (sirve sin internet y como respaldo si las webs no responden). */
    fun searchCached(query: String): List<Movie> {
        val out = ArrayList<Movie>()
        for (k in p.all.keys.filter { it.startsWith("feed_") }) {
            mergeInto(out, cached(k.removePrefix("feed_")).filter { movieMatches(it, query) })
        }
        return out
    }

    fun save(key: String, list: List<Movie>) {
        val arr = JSONArray()
        for (m in list.take(60)) {
            arr.put(
                JSONObject().put("id", m.id).put("title", m.title).put("year", m.year).put("genre", m.genre)
                    .put("quality", m.quality).put("lang", m.lang).put("syn", m.synopsis)
                    .put("cover", m.cover).put("url", m.url).put("alt", m.alt)
            )
        }
        p.edit().putString("feed_$key", arr.toString()).apply()
    }
}

/**
 * Lee la guía de LocoPelis con un WebView invisible (igual que la Agenda):
 *  - [fetchPage]: una página de películas (carátula, título, año, género, calidad, idioma y sinopsis corta).
 *  - [fetchDetail]: la página de una película (sinopsis completa, director, reparto).
 * Si la web cambia su diseño, se ajusta LIST_JS / DETAIL_JS.
 */
class MovieFetcher(private val ctx: Context) {
    companion object {
        // Cada película es un enlace /pelicula/NUMERO/... con la carátula dentro. Se sube por el HTML hasta el
        // bloque más grande que solo contenga esa película y de ahí se saca el texto (sinopsis, género, calidad…).
        private const val LIST_JS = """
(function(){
  try{
    var as=document.querySelectorAll('a[href*="/pelicula/"]');
    function ids(n){var s={},c=0,l=n.querySelectorAll('a[href*="/pelicula/"]');for(var k=0;k<l.length;k++){if(!s[l[k].href]){s[l[k].href]=1;c++;}}return c;}
    function ids2(n,m){var c=0,l=n.querySelectorAll('a[href]');for(var k=0;k<l.length;k++){if(m[l[k].href]&&l[k].querySelector('img'))c++;}return c;}
    var isSearch=/[?&](s|q|search|buscar)=/i.test(location.search);
    var seen={},out=[];
    for(var i=0;i<as.length;i++){
      var a=as[i],im=a.querySelector('img'); if(!im) continue;
      var h=a.href||''; if(!/\/pelicula\/\d+\//.test(h)||seen[h]) continue;
      var cov=im.getAttribute('data-src')||im.getAttribute('data-lazy-src')||im.getAttribute('src')||'';
      try{cov=new URL(cov,location.href).href;}catch(e){}
      if(cov.indexOf('/files/uploads/')<0 && !isSearch) continue;
      seen[h]=1;
      var c=a,hops=0;
      while(c.parentElement && hops<5 && c.parentElement!==document.body && ids(c.parentElement)===1){c=c.parentElement;hops++;}
      var tx=(c.textContent||'').replace(/\s+/g,' ').trim();
      out.push({u:h,i:cov,t:a.getAttribute('title')||im.getAttribute('alt')||'',x:tx.slice(0,1500)});
    }
    if(out.length===0){
      // Respaldo: si la web cambió sus direcciones, se toma cualquier enlace con carátula (imagen de póster) de la misma web.
      var all=document.querySelectorAll('a[href]'), s2={}, alt=[];
      for(var q=0;q<all.length;q++){
        var b=all[q], im2=b.querySelector('img'); if(!im2) continue;
        var h2=b.href||''; if(h2.indexOf(location.origin)!==0||s2[h2]) continue;
        if(/\/(categoria|category|tag|actor|page|login|registro|contacto|dmca|terminos)(\/|$)/i.test(h2)) continue;
        if(h2.replace(/\/+$/,'')===location.origin) continue;
        var c2=im2.getAttribute('data-src')||im2.getAttribute('data-lazy-src')||im2.getAttribute('src')||'';
        try{c2=new URL(c2,location.href).href;}catch(e){}
        if(!/\.(jpe?g|png|webp)(\?|$)/i.test(c2)||/logo|icon|avatar|banner|\/Temas\//i.test(c2)) continue;
        s2[h2]=1;
        var k=b,hp=0;
        while(k.parentElement && hp<5 && k.parentElement!==document.body && ids2(k.parentElement,s2)<=1){k=k.parentElement;hp++;}
        alt.push({u:h2,i:c2,t:b.getAttribute('title')||im2.getAttribute('alt')||'',x:(k.textContent||'').replace(/\s+/g,' ').trim().slice(0,1500)});
      }
      if(alt.length>=(isSearch?1:6)) out=alt;
    }
    return JSON.stringify({e:out});
  }catch(x){ return JSON.stringify({e:[],err:String(x)}); }
})()
"""

        // PelisPedia: las películas son enlaces /pelicula/nombre-CODIGO (las series y animes van por /serie/ y /anime/, se ignoran).
        private const val PEDIA_LIST_JS = """
(function(){
  try{
    function cover(a){
      var im=a.querySelector('img');
      if(!im && a.parentElement){ var ims=a.parentElement.querySelectorAll('img'); if(ims.length===1) im=ims[0]; }
      var c='';
      if(im){
        c=im.getAttribute('data-src')||im.getAttribute('data-lazy-src')||im.getAttribute('src')||'';
        if(!c||c.indexOf('data:')===0){ var ss=im.getAttribute('srcset')||im.getAttribute('data-srcset')||''; if(ss) c=ss.split(',')[0].trim().split(' ')[0]; }
      }
      if(!c){
        var els=a.querySelectorAll('*');
        for(var k=0;k<els.length&&!c;k++){ var st=els[k].getAttribute('style')||''; var m=st.match(/url\(["']?([^"')]+)/); if(m) c=m[1]; }
      }
      try{ c=new URL(c,location.href).href; }catch(e){}
      return {c:c, alt:im?(im.getAttribute('alt')||''):''};
    }
    var as=document.querySelectorAll('a[href*="/pelicula/"]'), seen={}, out=[];
    for(var i=0;i<as.length;i++){
      var a=as[i], h=(a.href||'').split('#')[0];
      if(!/\/pelicula\/[^\/?#]+\/?$/.test(h.split('?')[0])||seen[h]) continue;
      seen[h]=1;
      var cv=cover(a);
      out.push({u:h,i:cv.c,t:a.getAttribute('title')||cv.alt||'',x:(a.textContent||'').replace(/\s+/g,' ').trim().slice(0,300)});
    }
    return JSON.stringify({e:out});
  }catch(x){ return JSON.stringify({e:[],err:String(x)}); }
})()
"""

        // Busca el formulario del buscador de PelisPedia: devuelve "direccion|nombre_del_campo".
        private const val PEDIA_SEARCH_JS = """
(function(){
  try{
    var inputs=document.querySelectorAll('input[type=search],input[type=text],input:not([type])');
    for(var i=0;i<inputs.length;i++){
      var inp=inputs[i], f=inp.form;
      if(!f || !inp.name) continue;
      var hint=((inp.getAttribute('placeholder')||'')+' '+(inp.getAttribute('aria-label')||'')+' '+(f.getAttribute('role')||'')+' '+(f.className||'')+' '+(f.id||'')+' '+inp.name).toLowerCase();
      var named=/^(q|s|search|query|buscar|keyword|busqueda)$/.test(inp.name);
      if(named || /busc|search/.test(hint)){ return (f.action||location.href)+'|'+inp.name; }
    }
    return '';
  }catch(x){ return ''; }
})()
"""

        // Página de una película. La sinopsis se busca por orden de fiabilidad (r): 1 datos estructurados,
        // 2 bloque marcado como sinopsis, 3 texto bajo el título "Sinopsis", 4 primer párrafo largo tras el título
        // (nunca dentro de comentarios), 5 descripción de la página. Se devuelve también el rango para poder comparar webs.
        private const val DETAIL_JS = """
(function(){
  try{
    function clean(s){return (s||'').replace(/\s+/g,' ').trim();}
    var d={s:'',dir:'',c:[],alt:'',img:'',r:9};
    var og=document.querySelector('meta[property="og:image"]'); if(og) d.img=og.content||'';
    var BAD=/comment|coment|review|opini|reply|respuesta|disqus|foro|forum|valoraci|rating|related|relacionad|sidebar|footer|widget/i;
    function bad(e){
      for(var n=e;n&&n!==document.body;n=n.parentElement){
        var k=((n.className&&n.className.toString)?n.className.toString():'')+' '+(n.id||'');
        if(BAD.test(k)) return true;
      }
      return false;
    }
    function ok(t){
      return t && t.length>=40 && !/^Leer m/i.test(t) && !/^(Director|Reparto|G.nero|Calidad|Idioma|Duraci|A.o|Estreno)\b/i.test(t)
        && t.indexOf('LocoPelis')<0 && t.indexOf('PelisPedia')<0 && t.indexOf('Est\u00e1s a un clic')<0 && !/haz clic|verifica que|eres humano/i.test(t);
    }
    function set(t,r){
      t=clean(t);
      if(!ok(t) || r>=d.r) return;
      if(r>=4 && t.length<250 && /\.\.\.|\u2026/.test(t)) return; // los comentarios suelen venir cortados con "..."
      d.s=t; d.r=r;
    }
    document.querySelectorAll('script[type="application/ld+json"]').forEach(function(sc){
      try{
        var j=JSON.parse(sc.textContent);
        var arr=Array.isArray(j)?j:(j['@graph']?j['@graph']:[j]);
        arr.forEach(function(o){
          if(o && /Movie/i.test(String(o['@type']||''))){
            if(o.description) set(o.description,1);
            if(!d.dir && o.director){ var dd=Array.isArray(o.director)?o.director[0]:o.director; d.dir=clean(dd&&dd.name?dd.name:String(dd)); }
            if(o.actor && !d.c.length){ (Array.isArray(o.actor)?o.actor:[o.actor]).slice(0,8).forEach(function(a){ if(a&&a.name) d.c.push(clean(a.name)); }); }
          }
        });
      }catch(x){}
    });
    document.querySelectorAll('[itemprop=description],[class*=sinops],[class*=synops],[id*=sinops],[id*=synops],[class*=overview],[class*=plot],[class*=resumen],[class*=argumento]').forEach(function(e){
      if(bad(e)) return;
      var t=clean(e.textContent); if(t.length>1500) return;
      set(t,2);
    });
    if(d.r>3){
      document.querySelectorAll('h2,h3,h4,strong,b,span,div,p').forEach(function(e){
        if(d.r<=3) return;
        var t=clean(e.textContent);
        if(t.length<=14 && /^sinopsis:?$/i.test(t) && !bad(e)){
          var n=e.nextElementSibling;
          if(!n && e.parentElement) n=e.parentElement.nextElementSibling;
          if(n && !bad(n)) set(n.textContent,3);
        }
      });
    }
    var h=document.querySelector('h1');
    if(h){
      var els=document.querySelectorAll('p,div');
      for(var i=0;i<els.length;i++){
        var e=els[i];
        if(!(h.compareDocumentPosition(e)&4)) continue;
        var t=clean(e.textContent);
        if(!d.dir && /^Director:?\s+\S/.test(t) && t.length<80){ d.dir=t.replace(/^Director:?\s+/,''); continue; }
        var leaf=(e.children.length===0)||e.tagName==='P';
        if(!leaf) continue;
        if(!d.alt && /^T.tulo alternativo/i.test(t)){ d.alt=t.replace(/^T.tulo alternativo:?\s*/i,''); continue; }
        if(d.r>4 && !bad(e)) set(t,4);
      }
    }
    var md=document.querySelector('meta[property="og:description"]')||document.querySelector('meta[name="description"]');
    if(md) set(md.content,5);
    var as=document.querySelectorAll('a[href*="/actor/"]'),seen={};
    for(var k=0;k<as.length && d.c.length<8;k++){ var n2=clean(as[k].textContent); if(n2 && !seen[n2]){ seen[n2]=1; d.c.push(n2); } }
    var m2=d.s.match(/\s*Tambi.n conocid[ao]s? como:?\s*(.*)$/i);
    if(m2){ if(!d.alt) d.alt=m2[1].replace(/\.$/,''); d.s=d.s.slice(0,m2.index).trim(); }
    if(!d.s && !d.c.length) return JSON.stringify({});
    return JSON.stringify({s:d.s,dir:d.dir,c:d.c,alt:d.alt,img:d.img,r:d.r});
  }catch(x){ return JSON.stringify({}); }
})()
"""

        // Página de la película: pulsa las pestañas "Reproductor Opción 1/2" y el botón de play ("verifica que eres humano")
        // y devuelve las direcciones de los reproductores (iframes) que la página va armando.
        private const val EMBED_JS = """
(function(){
  try{
    function clk(e){
      try{ e.click(); }catch(x){}
      try{ ['mousedown','mouseup','click'].forEach(function(t){ e.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window})); }); }catch(x){}
    }
    window.__etv=(window.__etv||0)+1;
    var tabs=document.querySelectorAll('a[href^="#ms"],[data-target^="#ms"],[data-bs-target^="#ms"]');
    if(tabs.length){ clk(tabs[(window.__etv-1)%tabs.length]); }
    var opts=[];
    document.querySelectorAll('a,button,li,div,span').forEach(function(e){
      if(e.children.length>3) return;
      var t=(e.textContent||'').replace(/\s+/g,' ').trim().toLowerCase();
      if(t.length>0 && t.length<40 && /embed\s?\d*|servidor\s?\d+|opci.n\s?\d+/.test(t) && t.indexOf('eres humano')<0) opts.push(e);
    });
    opts.sort(function(x,y){ return ((y.textContent||'').toLowerCase().indexOf('embed69')>=0?1:0)-((x.textContent||'').toLowerCase().indexOf('embed69')>=0?1:0); });
    if(opts.length){ clk(opts[(window.__etv-1)%opts.length]); }
    var srv=document.querySelectorAll('[data-server],[data-tplayernv],[class*="server"] li,[class*="option"] li,.options li');
    if(srv.length){ clk(srv[(window.__etv-1)%srv.length]); }
    var els=document.querySelectorAll('div,button,a,span');
    for(var i=0;i<els.length;i++){
      var e=els[i]; if(e.children.length>4) continue;
      var t=(e.textContent||'').toLowerCase();
      if(t.length<220 && t.indexOf('eres humano')>=0){ clk(e); if(e.parentElement) clk(e.parentElement); }
    }
    var sel=['.play-button','.btn-play','#play','.play','.vjs-big-play-button','[aria-label="Play"]','[title="Play"]'];
    for(var j=0;j<sel.length;j++){ var b=document.querySelector(sel[j]); if(b) clk(b); }
    var out=[],seen={};
    function add(u){
      if(!u) return;
      try{ u=new URL(u,location.href).href; }catch(x){ return; }
      if(u.indexOf('http')!==0 || seen[u]) return;
      seen[u]=1; out.push(u);
    }
    document.querySelectorAll('iframe').forEach(function(f){
      add(f.getAttribute('src')); add(f.getAttribute('data-src')); add(f.getAttribute('data-lazy-src'));
    });
    document.querySelectorAll('[data-embed],[data-url],[data-video],[data-iframe],[data-player],[data-src]').forEach(function(e){
      if(e.tagName==='IMG') return;
      ['data-embed','data-url','data-video','data-iframe','data-player','data-src'].forEach(function(a){ add(e.getAttribute(a)); });
    });
    return JSON.stringify({u:out});
  }catch(x){ return JSON.stringify({u:[]}); }
})()
"""

        private val FX_YEAR = Regex("((?:19|20)\\d{2})(?=\\d{0,2}h|\\d{1,2}min)")
        private val FX_GENRE = Regex("G.{0,2}nero\\s*:?\\s*(.*?)\\s*(?:Ver\\s+(?:Online|Ahora)|$)")
        private val FX_SYN = Regex("\\d{1,2}\\s?min\\s*(.*?)\\s*G.{0,2}nero\\s*:")

        /** Junta listas de varias webs: una de cada una por turno; la misma película en las dos sale UNA sola vez. */
        fun mergeMovies(lists: List<List<Movie>>): List<Movie> {
            if (lists.size == 1) return lists[0]
            val out = ArrayList<Movie>()
            var i = 0
            while (lists.any { i < it.size }) {
                lists.forEach { l -> l.getOrNull(i)?.let { mergeInto(out, listOf(it)) } }
                i++
            }
            return out
        }

        private val ASSET_RE = Regex("\\.(jpe?g|png|webp|gif|svg|ico|css|js|woff2?)(\\?.*)?$", RegexOption.IGNORE_CASE)

        fun parseEmbeds(json: String): List<String>? {
            return try {
                val arr = JSONObject(json).getJSONArray("u")
                val out = ArrayList<String>()
                for (i in 0 until arr.length()) {
                    val u = arr.getString(i)
                    if (u.contains("about:blank") || ASSET_RE.containsMatchIn(u)) continue
                    if (u.contains("image.tmdb.org") || u.contains("/Temas/") || u.contains("/files/uploads/")) continue
                    if (u.contains("/actor/") || u.contains("/categoria/") || u.contains("/tag/")) continue
                    if (AdBlocker.isAdUrl(u)) continue
                    if (u !in out) out.add(u)
                }
                if (out.isEmpty()) null else out.sortedBy { if (it.contains("embed69", true)) 0 else 1 }
            } catch (e: Exception) {
                null
            }
        }

        private val TITLE_RE = Regex("^Ver\\s+(.+?)(?:\\s*\\((\\d{4})\\))?\\s+online gratis.*$", RegexOption.IGNORE_CASE)
        private val GEN_RE = Regex("G.{0,2}nero\\s*:?\\s*([^,]*?)\\s*,\\s*(\\d{4})")
        private val GEN_START = Regex("G.{0,2}nero\\s*:")
        private val QUAL_RE = Regex("Calidad\\s*:?\\s*(.+?)\\s+Idioma")
        private val LANG_RE = Regex("Idioma\\s*:?\\s*(\\S+)")
        private val ID_RE = Regex("/pelicula/(\\d+)/")

        fun parseList(json: String): List<Movie>? {
            return try {
                val arr = JSONObject(json).getJSONArray("e")
                val all = ArrayList<Movie>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val url = o.optString("u")
                    val id = ID_RE.find(url)?.groupValues?.get(1)
                        ?: url.trimEnd('/').substringAfterLast('/').takeIf { it.isNotEmpty() && !url.contains("?") } ?: continue
                    val t = o.optString("t").trim()
                    val tm = TITLE_RE.find(t)
                    val title = (tm?.groupValues?.get(1) ?: t.removePrefix("Ver ").trim()).trim()
                    if (title.isEmpty()) continue
                    val x = o.optString("x")

                    var syn = ""
                    val si = x.indexOf("Sinopsis")
                    if (si >= 0) {
                        var s = x.substring(si + 8).trim()
                        val gi = GEN_START.find(s)?.range?.first ?: -1
                        if (gi >= 0) s = s.substring(0, gi)
                        s = s.trim()
                        // El título viene repetido al inicio de la sinopsis: se quita.
                        for (k in minOf(title.length, 40) downTo 5) {
                            if (s.startsWith(title.take(k), ignoreCase = true)) {
                                s = s.substring(k).trim()
                                break
                            }
                        }
                        syn = s
                    }

                    val gm = GEN_RE.find(x)
                    val genre = gm?.groupValues?.get(1)?.trim().orEmpty()
                    var year = tm?.groupValues?.get(2).orEmpty()
                    if (year.isEmpty()) year = gm?.groupValues?.get(2).orEmpty()
                    val quality = QUAL_RE.find(x)?.groupValues?.get(1)?.trim().orEmpty()
                    val lang = LANG_RE.find(x)?.groupValues?.get(1)?.trim().orEmpty()
                    all.add(Movie(id, title, year, genre, quality, lang, syn, o.optString("i"), url))
                }
                // Si la página trae la lista principal (con sinopsis) más carruseles de "últimas", nos quedamos con la principal.
                val main = all.filter { it.synopsis.isNotEmpty() }
                val res = if (main.size >= 6) main else all
                if (res.isEmpty()) null else res
            } catch (e: Exception) {
                null
            }
        }

        private val PT_RE = Regex("^Ver\\s+(.+?)\\s+online en HD", RegexOption.IGNORE_CASE)
        private val PY_RE = Regex("\\((\\d{4})\\)")

        /** Lista de PelisPedia: título y año salen del texto "Ver NOMBRE (AÑO) online en HD - Película completa". */
        fun parsePediaList(json: String): List<Movie>? {
            return try {
                val arr = JSONObject(json).getJSONArray("e")
                val out = ArrayList<Movie>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val url = o.optString("u")
                    val id = url.substringBefore('?').trimEnd('/').substringAfterLast('/')
                    if (id.isEmpty()) continue
                    var title = ""
                    for (raw in listOf(o.optString("t"), o.optString("x"))) {
                        val t = PT_RE.find(raw.trim())?.groupValues?.get(1)
                        if (!t.isNullOrBlank()) { title = t.trim(); break }
                    }
                    if (title.isEmpty()) {
                        title = o.optString("t").trim().removePrefix("Ver ").trim()
                    }
                    if (title.isEmpty()) {
                        // Último recurso: el nombre sale de la dirección (sin el código del final).
                        title = id.substringBeforeLast('-').replace('-', ' ').trim().replaceFirstChar { it.uppercase() }
                    }
                    val ym = PY_RE.find(title)
                    val year = ym?.groupValues?.get(1).orEmpty()
                    if (ym != null) title = title.replace(ym.value, "").trim()
                    if (title.isEmpty()) continue
                    out.add(Movie(id, title, year, "", "", "", "", o.optString("i"), url))
                }
                if (out.isEmpty()) null else out
            } catch (e: Exception) {
                null
            }
        }

        private val ALSO_KNOWN = Regex("\\s*Tambi.n conocid[ao]s? como:?\\s*(.*)$", RegexOption.IGNORE_CASE)

        /** [settled] = false: si solo hay una sinopsis floja (rango 4 o 5) se sigue esperando por si la página aún se está armando. */
        fun parseDetail(json: String, settled: Boolean = true): MovieDetail? {
            return try {
                val o = JSONObject(json)
                var syn = o.optString("s").trim()
                var alt = o.optString("alt").trim()
                val rank = o.optInt("r", 9)
                val ca = o.optJSONArray("c") ?: JSONArray()
                if (syn.isEmpty() && ca.length() == 0) return null
                if (syn.isNotEmpty() && rank >= 4 && !settled) return null
                val am = ALSO_KNOWN.find(syn)
                if (am != null) {
                    if (alt.isEmpty()) alt = am.groupValues[1].trim().trimEnd('.')
                    syn = syn.substring(0, am.range.first).trim()
                }
                val cast = ArrayList<String>()
                for (i in 0 until ca.length()) cast.add(ca.getString(i))
                MovieDetail(syn, o.optString("dir"), cast, alt, o.optString("img"), rank)
            } catch (e: Exception) {
                null
            }
        }

        /** Junta los datos de las páginas de la película (una por web): gana la sinopsis más fiable; PelisPedia tiene un punto de ventaja. */
        fun bestDetail(list: List<MovieDetail>): MovieDetail? {
            if (list.isEmpty()) return null
            val syn = list.filter { it.synopsis.isNotEmpty() }
                .sortedWith(compareBy<MovieDetail>({ it.rank - (if (it.fromPedia) 1 else 0) }, { -it.synopsis.length }))
                .firstOrNull()
            return MovieDetail(
                syn?.synopsis.orEmpty(),
                list.firstOrNull { it.director.isNotEmpty() }?.director.orEmpty(),
                list.firstOrNull { it.cast.isNotEmpty() }?.cast.orEmpty(),
                list.firstOrNull { it.alt.isNotEmpty() }?.alt.orEmpty(),
                list.firstOrNull { it.poster.isNotEmpty() }?.poster.orEmpty(),
                syn?.rank ?: 9,
                syn?.fromPedia ?: false,
            )
        }
    }

    /** Direcciones de búsqueda de PelisPedia (%s = texto). Se recuerda la que funciona. */
    private object PediaSearch {
        @Volatile var template: String? = null
        val fallbacks = listOf(
            MovieSources.PEDIA + "/buscar?q=%s",
            MovieSources.PEDIA + "/search?q=%s",
            MovieSources.PEDIA + "/?s=%s",
            MovieSources.PEDIA + "/busqueda?q=%s",
            MovieSources.PEDIA + "/peliculas?search=%s",
            MovieSources.PEDIA + "/peliculas?q=%s",
        )
    }

    /** Lanza todas las tareas a la vez y entrega la primera que trae películas (null si ninguna). */
    private fun tryFirst(jobs: List<((List<Movie>?) -> Unit) -> Unit>, done: (List<Movie>?) -> Unit) {
        if (jobs.isEmpty()) { done(null); return }
        var left = jobs.size
        var finished = false
        jobs.forEach { job ->
            job { r ->
                if (finished) return@job
                left--
                if (!r.isNullOrEmpty()) { finished = true; done(r) }
                else if (left == 0) { finished = true; done(null) }
            }
        }
    }

    private fun fetchPediaSearch(query: String, done: (List<Movie>?) -> Unit) {
        val q = java.net.URLEncoder.encode(query, "UTF-8")
        fun url(t: String) = t.replace("%s", q)
        fun job(t: String): ((List<Movie>?) -> Unit) -> Unit = { cb ->
            fetchPage(url(t)) { r ->
                if (!r.isNullOrEmpty()) PediaSearch.template = t
                cb(r)
            }
        }
        // Formulario del propio sitio: se lee una vez y se convierte en dirección.
        val formJob: ((List<Movie>?) -> Unit) -> Unit = { cb ->
            PageScraper(ctx, MovieSources.PEDIA + "/", PEDIA_SEARCH_JS, { s -> if (s.contains('|')) s else null }, chromeUa = true)
                .fetch { found ->
                    if (found == null) cb(null)
                    else {
                        val action = found.substringBefore('|')
                        val name = found.substringAfter('|')
                        job(action + (if (action.contains('?')) "&" else "?") + name + "=%s")(cb)
                    }
                }
        }
        fun discover() {
            val first = listOf(formJob) + PediaSearch.fallbacks.take(3).map { job(it) }
            tryFirst(first) { r ->
                if (r != null) done(r)
                else tryFirst(PediaSearch.fallbacks.drop(3).map { job(it) }, done)
            }
        }
        val remembered = PediaSearch.template
        if (remembered == null) discover()
        else fetchPage(url(remembered)) { r ->
            if (!r.isNullOrEmpty()) done(r)
            else {
                PediaSearch.template = null
                discover()
            }
        }
    }

    /**
     * Baja una página de una lista de LocoPelis y de PelisPedia a la vez (cada una en su propio WebView invisible,
     * como dos pestañas en segundo plano). En cuanto llega la primera se entrega en [partial] para mostrarla ya,
     * y cuando llegan las dos (o pasa el tiempo de espera de la otra) se entrega todo junto y sin repetidas en [done].
     * [done] recibe null solo si fallan las dos.
     */
    fun fetchFeed(
        f: MovieFeed, query: String, page: Int,
        done: (List<Movie>?) -> Unit,
        partial: ((List<Movie>) -> Unit)? = null,
    ) {
        val handler = Handler(Looper.getMainLooper())
        val jobs = ArrayList<((List<Movie>?) -> Unit) -> Unit>()
        // Si la lista de LocoPelis no tiene páginas, solo se pide la primera vez.
        val locoUrl = f.urlFor(page)
        if (locoUrl.isNotEmpty() && (f.paged || page == 1)) jobs.add { cb -> fetchPage(locoUrl, cb) }
        if (f.key == "search") {
            // El buscador de PelisPedia solo se usa en la primera página.
            if (page == 1) jobs.add { cb -> fetchPediaSearch(query, cb) }
        } else {
            val pediaUrl = f.pediaUrlFor(page)
            if (pediaUrl.isNotEmpty()) jobs.add { cb -> fetchPage(pediaUrl, cb) }
        }
        if (jobs.isEmpty()) {
            done(null)
            return
        }
        val results = arrayOfNulls<List<Movie>>(jobs.size)
        var responded = 0
        var finished = false
        var graceStarted = false
        fun finish() {
            if (finished) return
            finished = true
            handler.removeCallbacksAndMessages(null)
            val got = results.filterNotNull()
            done(if (got.isEmpty()) null else mergeMovies(got))
        }
        jobs.forEachIndexed { i, job ->
            job { r ->
                if (finished) return@job
                results[i] = r
                responded++
                if (responded >= jobs.size) finish()
                else if (!r.isNullOrEmpty() && !graceStarted) {
                    // Una web ya respondió: se muestra al momento y a la otra se le da un rato más.
                    graceStarted = true
                    partial?.invoke(r)
                    handler.postDelayed({ finish() }, 8_000)
                }
            }
        }
    }

    fun fetchPage(url: String, done: (List<Movie>?) -> Unit) {
        if (url.contains("pelispedia")) PageScraper(ctx, url, PEDIA_LIST_JS, { parsePediaList(it) }, chromeUa = true).fetch(done)
        else PageScraper(ctx, url, LIST_JS, { parseList(it) }, chromeUa = true).fetch(done)
    }

    /** Busca los reproductores (Opción 1, Opción 2…) de la página de una película. Null si no aparece ninguno. */
    fun fetchEmbeds(url: String, done: (List<String>?) -> Unit) {
        val acc = LinkedHashSet<String>()
        var polls = 0
        // Se espera un poco para juntar los 2 reproductores (la página cambia de pestaña en cada lectura).
        PageScraper(ctx, url, EMBED_JS, { s ->
            polls++
            parseEmbeds(s)?.let { acc.addAll(it) }
            if (acc.size >= 2 || (acc.isNotEmpty() && polls >= 4)) acc.toList().sortedBy { if (it.contains("embed69", true)) 0 else 1 } else null
        }).fetch(done)
    }

    fun fetchDetail(url: String, done: (MovieDetail?) -> Unit) {
        var polls = 0
        val pedia = url.contains("pelispedia")
        PageScraper(ctx, url, DETAIL_JS, { s -> polls++; parseDetail(s, polls >= 4) }, chromeUa = true)
            .fetch { d -> done(d?.copy(fromPedia = pedia)) }
    }
}

/** Descarga carátulas en segundo plano y las guarda en memoria para no bajarlas dos veces. */
object MovieImages {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val io = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    /** Pone la imagen de [url] en [iv]; si el ImageView ya se usó para otra imagen, se ignora el resultado tardío. */
    fun load(url: String, iv: ImageView) {
        iv.tag = url
        if (url.isEmpty()) return
        cache.get(url)?.let { iv.setImageBitmap(it); return }
        io.execute {
            val b = download(url)
            if (b != null) {
                cache.put(url, b)
                main.post { if (iv.tag == url) iv.setImageBitmap(b) }
            }
        }
    }

    private fun download(u: String): Bitmap? = try {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")
        if (u.contains("locopelis.com")) c.setRequestProperty("Referer", "https://www.locopelis.com/")
        else if (u.contains("pelispedia")) c.setRequestProperty("Referer", "https://pelispedia.mov/")
        val bytes = c.inputStream.use { it.readBytes() }
        c.disconnect()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 400) sample *= 2
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    } catch (e: Exception) {
        null
    }
}
