package com.estebanruiz.estebantv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.util.concurrent.Executors

/** Una película de la guía: nombre, año, género, calidad, idioma, sinopsis corta, carátula y su página. */
data class Movie(
    val id: String,
    val title: String,
    val year: String,
    val genre: String,
    val quality: String,
    val lang: String,
    val synopsis: String,
    val cover: String,
    val url: String,
)

/** Datos extra que salen al abrir la página de la película: sinopsis completa, director, reparto. */
data class MovieDetail(
    val synopsis: String,
    val director: String,
    val cast: List<String>,
    val alt: String,
    val poster: String,
)

/**
 * Una lista de la guía (Inicio, Últimas, una categoría…).
 * [pattern] es la dirección; si [paged] es true lleva {p} donde va el número de página.
 */
data class MovieFeed(val key: String, val label: String, val pattern: String, val paged: Boolean, val genre: String = "") {
    fun urlFor(page: Int): String = if (paged) pattern.replace("{p}", page.toString()) else pattern
}

/** Listas disponibles. Para agregar o quitar una categoría edita [categories]: "Nombre" to "slug-de-la-web". */
object MovieFeeds {
    private const val BASE = "https://www.locopelis.com"

    private val categories = listOf(
        "Acción" to "accion",
        "Animación" to "animacion-e-infantil",
        "Anime" to "anime",
        "Artes marciales" to "artes-marciales",
        "Aventura" to "aventura",
        "Bélico" to "belico",
        "Ciencia ficción" to "ciencia-ficcion",
        "Comedia" to "comedia",
        "Deporte" to "deporte",
        "Documentales" to "documentales",
        "Drama" to "drama",
        "Fantasía" to "fantasia",
        "Intriga" to "intriga",
        "Musical" to "musical",
        "Religiosas" to "religiosas",
        "Romance" to "romance",
        "Suspenso" to "suspenso",
        "Terror" to "terror",
        "Western" to "western",
    )

    /** Búsqueda en LocoPelis (buscador de la web, en segundo plano). Si la web cambia, se ajusta aquí. */
    fun searchFeed(query: String): MovieFeed =
        MovieFeed("search", "Búsqueda", "$BASE/page/{p}/?s=" + java.net.URLEncoder.encode(query, "UTF-8"), true)

    val list: List<MovieFeed> = listOf(
        MovieFeed("resume", "⏱ Seguir viendo", "", false),
        MovieFeed("inicio", "Inicio", "$BASE/page/{p}/", true),
        MovieFeed("ultimas", "Últimas", "$BASE/pelicula/ultimas-peliculas", false),
        MovieFeed("vistas", "Más vistas", "$BASE/pelicula/peliculas-mas-vistas", false),
    ) + categories.map { (name, slug) ->
        MovieFeed("cat_$slug", name, "$BASE/categoria/$slug/page/{p}/", true, name)
    }
}

/** Minúsculas y sin tildes, para buscar "accion" y encontrar "Acción". */
fun movieNorm(s: String): String =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

/** Guarda la primera página de cada lista (SharedPreferences "movies") para mostrarla al instante. */
class MovieStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("movies", Context.MODE_PRIVATE)

    fun cached(key: String): List<Movie> {
        val raw = p.getString("feed_$key", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<Movie>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Movie(
                        o.optString("id"), o.optString("title"), o.optString("year"), o.optString("genre"),
                        o.optString("quality"), o.optString("lang"), o.optString("syn"), o.optString("cover"), o.optString("url"),
                    )
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(key: String, list: List<Movie>) {
        val arr = JSONArray()
        for (m in list.take(60)) {
            arr.put(
                JSONObject().put("id", m.id).put("title", m.title).put("year", m.year).put("genre", m.genre)
                    .put("quality", m.quality).put("lang", m.lang).put("syn", m.synopsis)
                    .put("cover", m.cover).put("url", m.url)
            )
        }
        p.edit().putString("feed_$key", arr.toString()).apply()
    }
}

/**
 * Lee la guía de LocoPelis con un WebView invisible (igual que la Agenda):
 *  - [fetchPage]: una página de películas (carátula, título, año, género, calidad, idioma y sinopsis corta).
 *  - [fetchDetail]: la página de una película (sinopsis completa, director, reparto).
 * Si la web cambia su diseño, se ajusta LIST_JS / DETAIL_JS.
 */
class MovieFetcher(private val ctx: Context) {
    companion object {
        // Cada película es un enlace /pelicula/NUMERO/... con la carátula dentro. Se sube por el HTML hasta el
        // bloque más grande que solo contenga esa película y de ahí se saca el texto (sinopsis, género, calidad…).
        private const val LIST_JS = """
(function(){
  try{
    var as=document.querySelectorAll('a[href*="/pelicula/"]');
    function ids(n){var s={},c=0,l=n.querySelectorAll('a[href*="/pelicula/"]');for(var k=0;k<l.length;k++){if(!s[l[k].href]){s[l[k].href]=1;c++;}}return c;}
    var seen={},out=[];
    for(var i=0;i<as.length;i++){
      var a=as[i],im=a.querySelector('img'); if(!im) continue;
      var h=a.href||''; if(!/\/pelicula\/\d+\//.test(h)||seen[h]) continue;
      var cov=im.getAttribute('data-src')||im.getAttribute('data-lazy-src')||im.getAttribute('src')||'';
      try{cov=new URL(cov,location.href).href;}catch(e){}
      if(cov.indexOf('/files/uploads/')<0) continue;
      seen[h]=1;
      var c=a,hops=0;
      while(c.parentElement && hops<5 && c.parentElement!==document.body && ids(c.parentElement)===1){c=c.parentElement;hops++;}
      var tx=(c.textContent||'').replace(/\s+/g,' ').trim();
      out.push({u:h,i:cov,t:a.getAttribute('title')||im.getAttribute('alt')||'',x:tx.slice(0,1500)});
    }
    return JSON.stringify({e:out});
  }catch(x){ return JSON.stringify({e:[],err:String(x)}); }
})()
"""

        // Página de una película: sinopsis (primer párrafo largo después del título), director, reparto y póster grande.
        private const val DETAIL_JS = """
(function(){
  try{
    var h=document.querySelector('h1'); if(!h) return JSON.stringify({});
    function clean(s){return (s||'').replace(/\s+/g,' ').trim();}
    var d={s:'',dir:'',c:[],alt:'',img:''};
    var og=document.querySelector('meta[property="og:image"]'); if(og) d.img=og.content||'';
    var els=document.querySelectorAll('p,div');
    for(var i=0;i<els.length;i++){
      var e=els[i];
      if(!(h.compareDocumentPosition(e)&4)) continue;
      var t=clean(e.textContent);
      if(!d.dir && /^Director\s+\S/.test(t) && t.length<80){ d.dir=t.replace(/^Director\s+/,''); continue; }
      var leaf=(e.children.length===0)||e.tagName==='P';
      if(!leaf) continue;
      if(!d.alt && /^T.tulo alternativo/i.test(t)){ d.alt=t.replace(/^T.tulo alternativo:?\s*/i,''); continue; }
      if(!d.s && t.length>70 && !/^Leer m/i.test(t) && t.indexOf('LocoPelis')<0 && t.indexOf('Est\u00e1s a un clic')<0) d.s=t;
    }
    if(!d.s){ var md=document.querySelector('meta[name="description"]'); if(md) d.s=clean(md.content); }
    var as=document.querySelectorAll('a[href*="/actor/"]'),seen={};
    for(var k=0;k<as.length && d.c.length<8;k++){
      var n=clean(as[k].textContent); if(n && !seen[n]){ seen[n]=1; d.c.push(n); }
    }
    return JSON.stringify(d);
  }catch(x){ return JSON.stringify({}); }
})()
"""

        // Página de la película: pulsa las pestañas "Reproductor Opción 1/2" y el botón de play ("verifica que eres humano")
        // y devuelve las direcciones de los reproductores (iframes) que la página va armando.
        private const val EMBED_JS = """
(function(){
  try{
    function clk(e){
      try{ e.click(); }catch(x){}
      try{ ['mousedown','mouseup','click'].forEach(function(t){ e.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window})); }); }catch(x){}
    }
    window.__etv=(window.__etv||0)+1;
    var tabs=document.querySelectorAll('a[href^="#ms"],[data-target^="#ms"],[data-bs-target^="#ms"]');
    if(tabs.length){ clk(tabs[(window.__etv-1)%tabs.length]); }
    var els=document.querySelectorAll('div,button,a,span');
    for(var i=0;i<els.length;i++){
      var e=els[i]; if(e.children.length>4) continue;
      var t=(e.textContent||'').toLowerCase();
      if(t.length<220 && t.indexOf('eres humano')>=0){ clk(e); if(e.parentElement) clk(e.parentElement); }
    }
    var sel=['.play-button','.btn-play','#play','.play','.vjs-big-play-button','[aria-label="Play"]','[title="Play"]'];
    for(var j=0;j<sel.length;j++){ var b=document.querySelector(sel[j]); if(b) clk(b); }
    var out=[],seen={};
    function add(u){
      if(!u) return;
      try{ u=new URL(u,location.href).href; }catch(x){ return; }
      if(u.indexOf('http')!==0 || seen[u]) return;
      seen[u]=1; out.push(u);
    }
    document.querySelectorAll('iframe').forEach(function(f){
      add(f.getAttribute('src')); add(f.getAttribute('data-src')); add(f.getAttribute('data-lazy-src'));
    });
    document.querySelectorAll('[data-embed],[data-url],[data-video],[data-iframe],[data-player],[data-src]').forEach(function(e){
      if(e.tagName==='IMG') return;
      ['data-embed','data-url','data-video','data-iframe','data-player','data-src'].forEach(function(a){ add(e.getAttribute(a)); });
    });
    return JSON.stringify({u:out});
  }catch(x){ return JSON.stringify({u:[]}); }
})()
"""

        private val ASSET_RE = Regex("\\.(jpe?g|png|webp|gif|svg|ico|css|js|woff2?)(\\?.*)?$", RegexOption.IGNORE_CASE)

        fun parseEmbeds(json: String): List<String>? {
            return try {
                val arr = JSONObject(json).getJSONArray("u")
                val out = ArrayList<String>()
                for (i in 0 until arr.length()) {
                    val u = arr.getString(i)
                    if (u.contains("about:blank") || ASSET_RE.containsMatchIn(u)) continue
                    if (u.contains("image.tmdb.org") || u.contains("/Temas/") || u.contains("/files/uploads/")) continue
                    if (u.contains("/actor/") || u.contains("/categoria/") || u.contains("/tag/")) continue
                    if (AdBlocker.isAdUrl(u)) continue
                    if (u !in out) out.add(u)
                }
                if (out.isEmpty()) null else out
            } catch (e: Exception) {
                null
            }
        }

        private val TITLE_RE = Regex("^Ver\\s+(.+?)(?:\\s*\\((\\d{4})\\))?\\s+online gratis.*$", RegexOption.IGNORE_CASE)
        private val GEN_RE = Regex("G.{0,2}nero\\s*:?\\s*([^,]*?)\\s*,\\s*(\\d{4})")
        private val GEN_START = Regex("G.{0,2}nero\\s*:")
        private val QUAL_RE = Regex("Calidad\\s*:?\\s*(.+?)\\s+Idioma")
        private val LANG_RE = Regex("Idioma\\s*:?\\s*(\\S+)")
        private val ID_RE = Regex("/pelicula/(\\d+)/")

        fun parseList(json: String): List<Movie>? {
            return try {
                val arr = JSONObject(json).getJSONArray("e")
                val all = ArrayList<Movie>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val url = o.optString("u")
                    val id = ID_RE.find(url)?.groupValues?.get(1) ?: continue
                    val t = o.optString("t").trim()
                    val tm = TITLE_RE.find(t)
                    val title = (tm?.groupValues?.get(1) ?: t.removePrefix("Ver ").trim()).trim()
                    if (title.isEmpty()) continue
                    val x = o.optString("x")

                    var syn = ""
                    val si = x.indexOf("Sinopsis")
                    if (si >= 0) {
                        var s = x.substring(si + 8).trim()
                        val gi = GEN_START.find(s)?.range?.first ?: -1
                        if (gi >= 0) s = s.substring(0, gi)
                        s = s.trim()
                        // El título viene repetido al inicio de la sinopsis: se quita.
                        for (k in minOf(title.length, 40) downTo 5) {
                            if (s.startsWith(title.take(k), ignoreCase = true)) {
                                s = s.substring(k).trim()
                                break
                            }
                        }
                        syn = s
                    }

                    val gm = GEN_RE.find(x)
                    val genre = gm?.groupValues?.get(1)?.trim().orEmpty()
                    var year = tm?.groupValues?.get(2).orEmpty()
                    if (year.isEmpty()) year = gm?.groupValues?.get(2).orEmpty()
                    val quality = QUAL_RE.find(x)?.groupValues?.get(1)?.trim().orEmpty()
                    val lang = LANG_RE.find(x)?.groupValues?.get(1)?.trim().orEmpty()
                    all.add(Movie(id, title, year, genre, quality, lang, syn, o.optString("i"), url))
                }
                // Si la página trae la lista principal (con sinopsis) más carruseles de "últimas", nos quedamos con la principal.
                val main = all.filter { it.synopsis.isNotEmpty() }
                val res = if (main.size >= 6) main else all
                if (res.isEmpty()) null else res
            } catch (e: Exception) {
                null
            }
        }

        fun parseDetail(json: String): MovieDetail? {
            return try {
                val o = JSONObject(json)
                val syn = o.optString("s")
                val ca = o.optJSONArray("c") ?: JSONArray()
                if (syn.isEmpty() && ca.length() == 0) return null
                val cast = ArrayList<String>()
                for (i in 0 until ca.length()) cast.add(ca.getString(i))
                MovieDetail(syn, o.optString("dir"), cast, o.optString("alt"), o.optString("img"))
            } catch (e: Exception) {
                null
            }
        }
    }

    fun fetchPage(url: String, done: (List<Movie>?) -> Unit) {
        PageScraper(ctx, url, LIST_JS) { parseList(it) }.fetch(done)
    }

    /** Busca los reproductores (Opción 1, Opción 2…) de la página de una película. Null si no aparece ninguno. */
    fun fetchEmbeds(url: String, done: (List<String>?) -> Unit) {
        PageScraper(ctx, url, EMBED_JS) { parseEmbeds(it) }.fetch(done)
    }

    fun fetchDetail(url: String, done: (MovieDetail?) -> Unit) {
        PageScraper(ctx, url, DETAIL_JS) { parseDetail(it) }.fetch(done)
    }
}

/** Descarga carátulas en segundo plano y las guarda en memoria para no bajarlas dos veces. */
object MovieImages {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val io = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    /** Pone la imagen de [url] en [iv]; si el ImageView ya se usó para otra imagen, se ignora el resultado tardío. */
    fun load(url: String, iv: ImageView) {
        iv.tag = url
        if (url.isEmpty()) return
        cache.get(url)?.let { iv.setImageBitmap(it); return }
        io.execute {
            val b = download(url)
            if (b != null) {
                cache.put(url, b)
                main.post { if (iv.tag == url) iv.setImageBitmap(b) }
            }
        }
    }

    private fun download(u: String): Bitmap? = try {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")
        if (u.contains("locopelis.com")) c.setRequestProperty("Referer", "https://www.locopelis.com/")
        val bytes = c.inputStream.use { it.readBytes() }
        c.disconnect()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 400) sample *= 2
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    } catch (e: Exception) {
        null
    }
}
