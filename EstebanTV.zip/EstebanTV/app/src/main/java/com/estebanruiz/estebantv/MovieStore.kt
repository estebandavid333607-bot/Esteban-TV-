package com.estebanruiz.estebantv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.webkit.CookieManager
import android.widget.ImageView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.util.concurrent.Executors

/** Una película de la guía: nombre, año, género, calidad, idioma, sinopsis corta, carátula y su página. */
data class Movie(
    val id: String,
    val title: String,
    val year: String,
    val genre: String,
    val quality: String,
    val lang: String,
    val synopsis: String,
    val cover: String,
    val url: String,
)

/** Datos extra que salen al abrir la página de la película: sinopsis completa, director, reparto. */
data class MovieDetail(
    val synopsis: String,
    val director: String,
    val cast: List<String>,
    val alt: String,
    val poster: String,
)

/**
 * Una lista de la guía (Inicio, Últimas, una categoría…).
 * [pattern] es la dirección; si [paged] es true lleva {p} donde va el número de página.
 */
data class MovieFeed(val key: String, val label: String, val pattern: String, val paged: Boolean, val genre: String = "") {
    fun urlFor(page: Int): String = when {
        !paged -> pattern
        page == 1 && pattern.contains("repelis24") -> pattern.replace("/page/{p}", "")
        else -> pattern.replace("{p}", page.toString())
    }
}

/** Listas disponibles. Para agregar o quitar una categoría edita [categories]: "Nombre" to "slug-de-la-web". */
object MovieFeeds {
    private const val BASE = "https://www.locopelis.com"

    private val categories = listOf(
        "Acción" to "accion",
        "Animación" to "animacion-e-infantil",
        "Anime" to "anime",
        "Artes marciales" to "artes-marciales",
        "Aventura" to "aventura",
        "Bélico" to "belico",
        "Ciencia ficción" to "ciencia-ficcion",
        "Comedia" to "comedia",
        "Deporte" to "deporte",
        "Documentales" to "documentales",
        "Drama" to "drama",
        "Fantasía" to "fantasia",
        "Intriga" to "intriga",
        "Musical" to "musical",
        "Religiosas" to "religiosas",
        "Romance" to "romance",
        "Suspenso" to "suspenso",
        "Terror" to "terror",
        "Western" to "western",
    )

    /** Búsqueda en LocoPelis (buscador de la web, en segundo plano). Si la web cambia, se ajusta aquí. */
    fun searchFeed(query: String): MovieFeed =
        MovieFeed("search", "Búsqueda", "$BASE/buscar/?q=" + java.net.URLEncoder.encode(query.trim(), "UTF-8"), true)

    // ---------------- Catálogo 2: RePelis24 ----------------
    private const val BASE2 = "https://repelis24.shop"

    /** Géneros de RePelis24: "Nombre" to "slug-de-la-web" (repelis24.shop/genero/slug). */
    private val categories2 = listOf(
        "Acción" to "accion",
        "Animación" to "animacion",
        "Anime" to "anime",
        "Aventura" to "aventura",
        "Bélico" to "belica",
        "Ciencia ficción" to "ciencia-ficcion",
        "Comedia" to "comedia",
        "Crimen" to "crimen",
        "DC Comics" to "dc",
        "Disney" to "disney",
        "Documental" to "documental",
        "Drama" to "drama",
        "Familia" to "familia",
        "Fantasía" to "fantasia",
        "Marvel" to "marvel",
        "Musical" to "musical",
        "Romance" to "romance",
        "Suspenso" to "suspense",
        "Terror" to "terror",
    )

    /** Búsqueda en RePelis24 (repelis24.shop/busqueda/texto). Si la web cambia, se ajusta aquí. */
    fun searchFeed2(query: String): MovieFeed =
        MovieFeed("search", "Búsqueda", "$BASE2/busqueda/" + java.net.URLEncoder.encode(query, "UTF-8").replace("+", "%20"), false)

    val list2: List<MovieFeed> = listOf(
        MovieFeed("resume", "⏱ Seguir viendo", "", false),
        MovieFeed("r24_inicio", "Inicio", "$BASE2/peliculas/page/{p}", true),
        MovieFeed("r24_estrenos", "Estrenos", "$BASE2/peliculas/estrenos/page/{p}", true),
    ) + categories2.map { (name, slug) ->
        MovieFeed("r24_cat_$slug", name, "$BASE2/genero/$slug/page/{p}", true, name)
    }

    /** Listas y buscador según el catálogo elegido (1 = LocoPelis, 2 = RePelis24). */
    fun listFor(src: Int): List<MovieFeed> = if (src == 2) list2 else list
    fun searchFor(src: Int, query: String): MovieFeed = if (src == 2) searchFeed2(query) else searchFeed(query)
    fun nameFor(src: Int): String = if (src == 2) "Catálogo 2" else "Catálogo 1"

    val list: List<MovieFeed> = listOf(
        MovieFeed("resume", "⏱ Seguir viendo", "", false),
        MovieFeed("inicio", "Inicio", "$BASE/page/{p}/", true),
        MovieFeed("ultimas", "Últimas", "$BASE/pelicula/ultimas-peliculas", false),
        MovieFeed("vistas", "Más vistas", "$BASE/pelicula/peliculas-mas-vistas", false),
    ) + categories.map { (name, slug) ->
        MovieFeed("cat_$slug", name, "$BASE/categoria/$slug/page/{p}/", true, name)
    }
}

/** Minúsculas y sin tildes, para buscar "accion" y encontrar "Acción". */
fun movieNorm(s: String): String =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

/** Guarda la primera página de cada lista (SharedPreferences "movies") para mostrarla al instante. */
class MovieStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("movies", Context.MODE_PRIVATE)

    fun cached(key: String): List<Movie> {
        val raw = p.getString("feed_$key", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<Movie>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Movie(
                        o.optString("id"), o.optString("title"), o.optString("year"), o.optString("genre"),
                        o.optString("quality"), o.optString("lang"), o.optString("syn"), o.optString("cover"), o.optString("url"),
                    )
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Busca en las listas ya guardadas del catálogo indicado (sale al instante y sirve si la web no responde). */
    fun searchCached(query: String, r24: Boolean): List<Movie> {
        val words = movieNorm(query).split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return emptyList()
        val out = ArrayList<Movie>()
        val seen = HashSet<String>()
        for (k in p.all.keys.filter { it.startsWith("feed_") }) {
            for (m in cached(k.removePrefix("feed_"))) {
                if (MovieFetcher.isR24(m.url) != r24 || !seen.add(m.url)) continue
                val hay = movieNorm(m.title).replace(Regex("[^a-z0-9]+"), " ")
                if (words.all { hay.contains(it) }) out.add(m)
            }
        }
        return out
    }

    fun save(key: String, list: List<Movie>) {
        val arr = JSONArray()
        for (m in list.take(60)) {
            arr.put(
                JSONObject().put("id", m.id).put("title", m.title).put("year", m.year).put("genre", m.genre)
                    .put("quality", m.quality).put("lang", m.lang).put("syn", m.synopsis)
                    .put("cover", m.cover).put("url", m.url)
            )
        }
        p.edit().putString("feed_$key", arr.toString()).apply()
    }
}

/**
 * Lee la guía de LocoPelis con un WebView invisible (igual que la Agenda):
 *  - [fetchPage]: una página de películas (carátula, título, año, género, calidad, idioma y sinopsis corta).
 *  - [fetchDetail]: la página de una película (sinopsis completa, director, reparto).
 * Si la web cambia su diseño, se ajusta LIST_JS / DETAIL_JS.
 */
class MovieFetcher(private val ctx: Context) {
    companion object {
        // Cada película es un enlace /pelicula/NUMERO/... con la carátula dentro. Se sube por el HTML hasta el
        // bloque más grande que solo contenga esa película y de ahí se saca el texto (sinopsis, género, calidad…).
        private const val LIST_JS = """
(function(){
  try{
    var as=document.querySelectorAll('a[href*="/pelicula/"]');
    function ids(n){var s={},c=0,l=n.querySelectorAll('a[href*="/pelicula/"]');for(var k=0;k<l.length;k++){if(!s[l[k].href]){s[l[k].href]=1;c++;}}return c;}
    var isSearch=/[?&](s|q|search|buscar)=/i.test(location.search);
    var seen={},out=[];
    for(var i=0;i<as.length;i++){
      var a=as[i],im=a.querySelector('img'); if(!im) continue;
      var h=a.href||''; if(!(/\/pelicula\/\d+\//.test(h)||(isSearch&&/\/pelicula\/[^\/?#]+/.test(h)))||seen[h]) continue;
      var cov=im.getAttribute('data-src')||im.getAttribute('data-lazy-src')||im.getAttribute('src')||'';
      try{cov=new URL(cov,location.href).href;}catch(e){}
      if(cov.indexOf('/files/uploads/')<0 && !isSearch) continue;
      seen[h]=1;
      var c=a,hops=0;
      while(c.parentElement && hops<5 && c.parentElement!==document.body && ids(c.parentElement)===1){c=c.parentElement;hops++;}
      var tx=(c.textContent||'').replace(/\s+/g,' ').trim();
      out.push({u:h,i:cov,t:a.getAttribute('title')||im.getAttribute('alt')||'',x:tx.slice(0,1500)});
    }
    if(isSearch && out.length===0){
      // Respaldo del buscador: cualquier enlace de la misma web con carátula.
      var all=document.querySelectorAll('a[href]'), s2={};
      for(var q=0;q<all.length;q++){
        var b=all[q], im2=b.querySelector('img'); if(!im2) continue;
        var h2=(b.href||'').split('#')[0]; if(h2.indexOf(location.origin)!==0||s2[h2]) continue;
        if(/\/(categoria|category|tag|actor|page|login|registro|contacto|dmca|terminos)(\/|$)/i.test(h2)||h2.replace(/\/+$/,'')===location.origin) continue;
        var c2=im2.getAttribute('data-src')||im2.getAttribute('data-lazy-src')||im2.getAttribute('src')||'';
        try{c2=new URL(c2,location.href).href;}catch(e){}
        if(!/\.(jpe?g|png|webp)(\?|$)/i.test(c2)||/logo|icon|avatar|banner/i.test(c2)) continue;
        s2[h2]=1;
        out.push({u:h2,i:c2,t:b.getAttribute('title')||im2.getAttribute('alt')||'',x:(b.parentElement?b.parentElement.textContent:'').replace(/\s+/g,' ').trim().slice(0,600)});
      }
    }
    return JSON.stringify({e:out});
  }catch(x){ return JSON.stringify({e:[],err:String(x)}); }
})()
"""

        // Página de resultados del buscador (/buscar/?q=texto). Arriba salen carruseles de películas populares y los
        // resultados de verdad están al final, debajo del título "Resultados para '…'": solo se toman las películas
        // que vienen DESPUÉS de ese título (y antes de otra sección como "Populares").
        private const val SEARCH_JS = """
(function(){
  try{
    var els=document.querySelectorAll('h1,h2,h3,h4,h5,div,span,p,strong,b'), hd=null;
    for(var i=0;i<els.length;i++){
      var t=(els[i].textContent||'').replace(/\s+/g,' ').trim();
      if(t.length<160 && /^Resultados\s+para/i.test(t)) hd=els[i];
    }
    if(!hd) return JSON.stringify({e:[]});
    function after(n){ return (hd.compareDocumentPosition(n)&4)!==0 && !hd.contains(n); }
    var stop=null, hs=document.querySelectorAll('h1,h2,h3,h4,h5');
    for(var k=0;k<hs.length;k++){
      if(!after(hs[k])) continue;
      if(/populares|recomendad|estrenos|ultimas|últimas|vistas|relacionad|tendencia|te puede|tambi.n/i.test(hs[k].textContent||'')){ stop=hs[k]; break; }
    }
    var box=hd;
    while(box.parentElement && box!==document.body){
      var ls=box.querySelectorAll('a[href]'), ok=false;
      for(var j=0;j<ls.length;j++){ if(ls[j].querySelector('img') && after(ls[j])){ ok=true; break; } }
      if(ok) break;
      box=box.parentElement;
    }
    var as=box.querySelectorAll('a[href]'), seen={}, out=[];
    for(var m=0;m<as.length;m++){
      var a=as[m], im=a.querySelector('img'); if(!im||!after(a)) continue;
      if(stop && (stop.compareDocumentPosition(a)&4)!==0) continue;
      var h=(a.href||'').split('#')[0];
      if(h.indexOf(location.origin)!==0||seen[h]) continue;
      if(h.replace(/\/+$/,'')===location.origin) continue;
      if(!/\/pelicula\//.test(h) && /\/(categoria|category|tag|actor|page|buscar|login|registro|contacto|dmca|terminos|noticias?)(\/|$)/i.test(h)) continue;
      var cov=im.getAttribute('data-src')||im.getAttribute('data-lazy-src')||im.getAttribute('src')||'';
      try{cov=new URL(cov,location.href).href;}catch(e){}
      seen[h]=1;
      out.push({u:h,i:cov,t:a.getAttribute('title')||im.getAttribute('alt')||(a.textContent||'').replace(/\s+/g,' ').trim(),
        x:((a.parentElement?a.parentElement.textContent:'')||'').replace(/\s+/g,' ').trim().slice(0,600)});
    }
    return JSON.stringify({e:out});
  }catch(x){ return JSON.stringify({e:[],err:String(x)}); }
})()
"""

        private const val LOCO = "https://www.locopelis.com"

        // Página de una película: sinopsis (primer párrafo largo después del título), director, reparto y póster grande.
        private const val DETAIL_JS = """
(function(){
  try{
    var h=document.querySelector('h1'); if(!h) return JSON.stringify({});
    function clean(s){return (s||'').replace(/\s+/g,' ').trim();}
    var d={s:'',dir:'',c:[],alt:'',img:''};
    var og=document.querySelector('meta[property="og:image"]'); if(og) d.img=og.content||'';
    var els=document.querySelectorAll('p,div');
    for(var i=0;i<els.length;i++){
      var e=els[i];
      if(!(h.compareDocumentPosition(e)&4)) continue;
      var t=clean(e.textContent);
      if(!d.dir && /^Director\s+\S/.test(t) && t.length<80){ d.dir=t.replace(/^Director\s+/,''); continue; }
      var leaf=(e.children.length===0)||e.tagName==='P';
      if(!leaf) continue;
      if(!d.alt && /^T.tulo alternativo/i.test(t)){ d.alt=t.replace(/^T.tulo alternativo:?\s*/i,''); continue; }
      if(!d.s && t.length>70 && !/^Leer m/i.test(t) && t.indexOf('LocoPelis')<0 && t.indexOf('Est\u00e1s a un clic')<0) d.s=t;
    }
    if(!d.s){ var md=document.querySelector('meta[name="description"]'); if(md) d.s=clean(md.content); }
    var as=document.querySelectorAll('a[href*="/actor/"]'),seen={};
    for(var k=0;k<as.length && d.c.length<8;k++){
      var n=clean(as[k].textContent); if(n && !seen[n]){ seen[n]=1; d.c.push(n); }
    }
    return JSON.stringify(d);
  }catch(x){ return JSON.stringify({}); }
})()
"""

        // Página de la película: pulsa las pestañas "Reproductor Opción 1/2" y el botón de play ("verifica que eres humano")
        // y devuelve las direcciones de los reproductores (iframes) que la página va armando.
        private const val EMBED_JS = """
(function(){
  try{
    function clk(e){
      try{ e.click(); }catch(x){}
      try{ ['mousedown','mouseup','click'].forEach(function(t){ e.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window})); }); }catch(x){}
    }
    window.__etv=(window.__etv||0)+1;
    var tabs=document.querySelectorAll('a[href^="#ms"],[data-target^="#ms"],[data-bs-target^="#ms"]');
    if(tabs.length){ clk(tabs[(window.__etv-1)%tabs.length]); }
    var els=document.querySelectorAll('div,button,a,span');
    for(var i=0;i<els.length;i++){
      var e=els[i]; if(e.children.length>4) continue;
      var t=(e.textContent||'').toLowerCase();
      if(t.length<220 && t.indexOf('eres humano')>=0){ clk(e); if(e.parentElement) clk(e.parentElement); }
    }
    var sel=['.play-button','.btn-play','#play','.play','.vjs-big-play-button','[aria-label="Play"]','[title="Play"]'];
    for(var j=0;j<sel.length;j++){ var b=document.querySelector(sel[j]); if(b) clk(b); }
    var out=[],seen={};
    function add(u){
      if(!u) return;
      try{ u=new URL(u,location.href).href; }catch(x){ return; }
      if(u.indexOf('http')!==0 || seen[u]) return;
      seen[u]=1; out.push(u);
    }
    document.querySelectorAll('iframe').forEach(function(f){
      add(f.getAttribute('src')); add(f.getAttribute('data-src')); add(f.getAttribute('data-lazy-src'));
    });
    document.querySelectorAll('[data-embed],[data-url],[data-video],[data-iframe],[data-player],[data-src]').forEach(function(e){
      if(e.tagName==='IMG') return;
      ['data-embed','data-url','data-video','data-iframe','data-player','data-src'].forEach(function(a){ add(e.getAttribute(a)); });
    });
    return JSON.stringify({u:out});
  }catch(x){ return JSON.stringify({u:[]}); }
})()
"""

        // ---------------- RePelis24 ----------------
        // Cada película es un enlace /pelicula/slug/ con la carátula dentro (las series /serie/ se ignoran).
        private const val LIST_JS_R24 = """
(function(){
  try{
    var as=document.querySelectorAll('a[href*="/pelicula/"]');
    var seen={},out=[];
    for(var i=0;i<as.length;i++){
      var a=as[i],im=a.querySelector('img'); if(!im) continue;
      var h=a.href||''; if(!/\/pelicula\/[^\/?#]+\/?$/.test(h)||seen[h]) continue;
      var cov=im.getAttribute('data-src')||im.getAttribute('data-lazy-src')||im.getAttribute('src')||'';
      if(cov.indexOf('data:')===0) cov='';
      try{ if(cov) cov=new URL(cov,location.href).href; }catch(e){}
      if(cov.indexOf('logo')>=0) continue;
      seen[h]=1;
      var alt=(im.getAttribute('alt')||'').replace(/^poster( de la pel.cula)?\s*/i,'').replace(/\s+en HD$/i,'');
      out.push({u:h,i:cov,t:alt,x:(a.textContent||'').replace(/\s+/g,' ').trim().slice(0,1200)});
    }
    return JSON.stringify({e:out});
  }catch(x){ return JSON.stringify({e:[],err:String(x)}); }
})()
"""

        // Ficha: la sinopsis empieza DESPUÉS del título "… es una película gratis en HD de RePelis24 Online:" (ese texto no se copia).
        private const val DETAIL_JS_R24 = """
(function(){
  try{
    function clean(s){return (s||'').replace(/\s+/g,' ').trim();}
    var d={s:'',dir:'',c:[],alt:'',img:''};
    var hs=document.querySelectorAll('h2'),head=null;
    for(var i=0;i<hs.length;i++){ if(/es una pel.cula gratis/i.test(hs[i].textContent||'')){ head=hs[i]; break; } }
    var base=head;
    for(var up=0;base && up<3 && !d.s;up++){
      var n=base.nextElementSibling,g=0;
      while(n && g<4){ var t=clean(n.textContent); if(t.length>20){ d.s=t; break; } n=n.nextElementSibling; g++; }
      base=base.parentElement;
    }
    if(!d.s){
      var ps=document.querySelectorAll('p');
      for(var k=0;k<ps.length;k++){ var tp=clean(ps[k].textContent); if(tp.length>70 && !/es una pel.cula gratis/i.test(tp)){ d.s=tp; break; } }
    }
    d.s=d.s.replace(/^.*?es una pel.cula gratis[^:]*:\s*/i,'');
    var im=document.querySelector('img[alt^="poster"]');
    if(im){ d.img=im.getAttribute('src')||''; try{ d.img=new URL(d.img,location.href).href; }catch(e){} }
    var as=document.querySelectorAll('a[href*="/buscar/"]'),seen={};
    for(var j=0;j<as.length && d.c.length<8;j++){
      var nm=clean(as[j].textContent).replace(/,$/,''); if(nm && !seen[nm]){ seen[nm]=1; d.c.push(nm); }
    }
    return JSON.stringify(d);
  }catch(x){ return JSON.stringify({}); }
})()
"""

        // Reproductor: abre el idioma (Latino; si no hay, Subtitulado), pulsa "Opción 1 … Reproducir" y el play,
        // y devuelve las direcciones de los reproductores (iframes) que la página arma.
        private const val EMBED_JS_R24 = """
(function(){
  try{
    function clk(e){
      try{ e.click(); }catch(x){}
      try{ ['mousedown','mouseup','click'].forEach(function(t){ e.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window})); }); }catch(x){}
    }
    function tx(e){ return (e.textContent||'').replace(/\s+/g,' ').trim().toLowerCase(); }
    function vis(e){ var r=e.getBoundingClientRect(); return e.offsetParent!==null && r.height>0; }
    var S=window.__r24=window.__r24||{head:0,opt:0,play:0};
    var all=Array.prototype.slice.call(document.querySelectorAll('div,li,button,a,span,p'));
    function isOpt(e,lang){ var t=tx(e); return t.length<60 && /^opci.n\s*1\b/.test(t) && t.indexOf(lang)>=0; }
    function findOpt(lang){
      var m=all.filter(function(e){ return isOpt(e,lang); });
      m=m.filter(function(e){ return !Array.prototype.some.call(e.children,function(c){ return isOpt(c,lang); }); });
      return m.length?m[0]:null;
    }
    function findHead(lang){
      var m=all.filter(function(e){ var t=tx(e); return t.length<60 && t.indexOf('calidad')>=0 && t.indexOf(lang)===0; });
      return m.length?m[0]:null;
    }
    var lang='latino', opt=findOpt('latino');
    if(!opt){ var o2=findOpt('subtitulado'); if(o2){ opt=o2; lang='subtitulado'; } }
    if(opt && !vis(opt)){
      // Lista cerrada: se abre la sección del idioma (solo si sigue cerrada, para no cerrarla).
      var hd=findHead(lang);
      if(hd && S.head<3){
        S.head++;
        if(S.head===2){ var ds=hd.querySelectorAll('*'); if(ds.length) clk(ds[ds.length-1]); } else clk(hd);
      }
    } else if(opt){
      if(S.opt<2){
        S.opt++;
        var btn=null,ds2=opt.querySelectorAll('*');
        for(var i=0;i<ds2.length;i++){ if(tx(ds2[i]).indexOf('reproducir')===0 && ds2[i].children.length===0){ btn=ds2[i]; break; } }
        clk(btn||opt);
      }
      if(S.play<3){
        S.play++;
        var pi=document.querySelector('img[src*="play"]'); if(pi) clk(pi);
        var sel=['.play-button','.btn-play','#play','.play','.vjs-big-play-button','[aria-label="Play"]','[title="Play"]'];
        for(var j=0;j<sel.length;j++){ var b=document.querySelector(sel[j]); if(b) clk(b); }
      }
    }
    var out=[],seen={};
    function add(u){
      if(!u) return;
      try{ u=new URL(u,location.href).href; }catch(x){ return; }
      if(u.indexOf('http')!==0 || seen[u]) return;
      seen[u]=1; out.push(u);
    }
    document.querySelectorAll('iframe').forEach(function(f){
      add(f.getAttribute('src')); add(f.getAttribute('data-src')); add(f.getAttribute('data-lazy-src'));
    });
    var at=['data-embed','data-url','data-video','data-iframe','data-player','data-src','data-link','data-href'];
    document.querySelectorAll('[data-embed],[data-url],[data-video],[data-iframe],[data-player],[data-src],[data-link],[data-href]').forEach(function(e){
      if(e.tagName==='IMG') return;
      at.forEach(function(a){ add(e.getAttribute(a)); });
    });
    if(opt){
      var el=opt;
      for(var h=0;el && h<3;h++,el=el.parentElement){
        for(var q=0;q<el.attributes.length;q++){ var v=el.attributes[q].value||''; if(/^(https?:)?\/\//i.test(v)) add(v); }
      }
    }
    return JSON.stringify({u:out});
  }catch(x){ return JSON.stringify({u:[]}); }
})()
"""

        private val GEN_LIST = "Acción|Animación|Anime|Aventura|Bélica|Bélico|C\\. Ficción|Ciencia Ficción|Ciencia ficción|Comedia|Crimen|Documental|Drama|Familia|Fantasía|Guerra|Misterio|Musical|Romance|Suspense|Suspenso|Terror|Western|Historia|Película de TV"
        private val GEN_BLOCK_R24 = Regex("\\b(HD|FHD|SD|CAM|TS)\\s*-\\s*((?:$GEN_LIST)(?:\\s*-\\s*(?:$GEN_LIST))*)")
        private val SLUG_R24 = Regex("/pelicula/([^/?#]+)/?$")
        private val YEAR_R24 = Regex("(?<!\\d)((?:19|20)\\d{2})(?!\\d)")
        private val NOISE_R24 = Regex("/(pelicula|serie|genero|buscar|busqueda|peliculas|series)(/|$)|/cdn/plusdes/static/")

        fun isR24(url: String): Boolean = url.contains("repelis24")

        fun parseListR24(json: String): List<Movie>? {
            return try {
                val arr = JSONObject(json).getJSONArray("e")
                val all = ArrayList<Movie>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val url = o.optString("u")
                    val slug = SLUG_R24.find(url)?.groupValues?.get(1) ?: continue
                    var title = o.optString("t").trim()
                    if (title.isEmpty()) title = slug.replace('-', ' ').replaceFirstChar { it.uppercase() }
                    // El texto de la tarjeta: "2022 2022 ☆ 2h 00min HD - Acción - Bélica  sinopsis corta…  Título".
                    var x = o.optString("x").trim()
                    x = x.removePrefix(title).removeSuffix(title).trim()
                    val gm = GEN_BLOCK_R24.find(x)
                    val quality = gm?.groupValues?.get(1) ?: "HD"
                    val genre = gm?.groupValues?.get(2)?.split(Regex("\\s*-\\s*"))?.joinToString(", ").orEmpty()
                    val head = if (gm != null) x.substring(0, gm.range.first) else x
                    val year = YEAR_R24.find(head)?.groupValues?.get(1).orEmpty()
                    val syn = if (gm != null) x.substring(gm.range.last + 1).trim() else ""
                    all.add(Movie(slug, title, year, genre, quality, "", syn, o.optString("i"), url))
                }
                if (all.isEmpty()) null else all
            } catch (e: Exception) {
                null
            }
        }

        fun parseEmbedsR24(json: String): List<String>? {
            val base = parseEmbeds(json) ?: return null
            val out = base.filter { !NOISE_R24.containsMatchIn(it) }
            return if (out.isEmpty()) null else out
        }

        private val ASSET_RE = Regex("\\.(jpe?g|png|webp|gif|svg|ico|css|js|woff2?)(\\?.*)?$", RegexOption.IGNORE_CASE)

        fun parseEmbeds(json: String): List<String>? {
            return try {
                val arr = JSONObject(json).getJSONArray("u")
                val out = ArrayList<String>()
                for (i in 0 until arr.length()) {
                    val u = arr.getString(i)
                    if (u.contains("about:blank") || ASSET_RE.containsMatchIn(u)) continue
                    if (u.contains("image.tmdb.org") || u.contains("/Temas/") || u.contains("/files/uploads/")) continue
                    if (u.contains("/actor/") || u.contains("/categoria/") || u.contains("/tag/")) continue
                    if (AdBlocker.isAdUrl(u)) continue
                    if (u !in out) out.add(u)
                }
                if (out.isEmpty()) null else out
            } catch (e: Exception) {
                null
            }
        }

        private val TITLE_RE = Regex("^Ver\\s+(.+?)(?:\\s*\\((\\d{4})\\))?\\s+online gratis.*$", RegexOption.IGNORE_CASE)
        private val GEN_RE = Regex("G.{0,2}nero\\s*:?\\s*([^,]*?)\\s*,\\s*(\\d{4})")
        private val GEN_START = Regex("G.{0,2}nero\\s*:")
        private val QUAL_RE = Regex("Calidad\\s*:?\\s*(.+?)\\s+Idioma")
        private val LANG_RE = Regex("Idioma\\s*:?\\s*(\\S+)")
        private val ID_RE = Regex("/pelicula/(\\d+)/")

        fun parseList(json: String): List<Movie>? {
            return try {
                val arr = JSONObject(json).getJSONArray("e")
                val all = ArrayList<Movie>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val url = o.optString("u")
                    val id = ID_RE.find(url)?.groupValues?.get(1)
                        ?: url.substringBefore('?').trimEnd('/').substringAfterLast('/').takeIf { it.isNotEmpty() } ?: continue
                    val t = o.optString("t").trim()
                    val tm = TITLE_RE.find(t)
                    val title = (tm?.groupValues?.get(1) ?: t.removePrefix("Ver ").trim()).trim()
                    if (title.isEmpty()) continue
                    val x = o.optString("x")

                    var syn = ""
                    val si = x.indexOf("Sinopsis")
                    if (si >= 0) {
                        var s = x.substring(si + 8).trim()
                        val gi = GEN_START.find(s)?.range?.first ?: -1
                        if (gi >= 0) s = s.substring(0, gi)
                        s = s.trim()
                        // El título viene repetido al inicio de la sinopsis: se quita.
                        for (k in minOf(title.length, 40) downTo 5) {
                            if (s.startsWith(title.take(k), ignoreCase = true)) {
                                s = s.substring(k).trim()
                                break
                            }
                        }
                        syn = s
                    }

                    val gm = GEN_RE.find(x)
                    val genre = gm?.groupValues?.get(1)?.trim().orEmpty()
                    var year = tm?.groupValues?.get(2).orEmpty()
                    if (year.isEmpty()) year = gm?.groupValues?.get(2).orEmpty()
                    val quality = QUAL_RE.find(x)?.groupValues?.get(1)?.trim().orEmpty()
                    val lang = LANG_RE.find(x)?.groupValues?.get(1)?.trim().orEmpty()
                    all.add(Movie(id, title, year, genre, quality, lang, syn, o.optString("i"), url))
                }
                // Si la página trae la lista principal (con sinopsis) más carruseles de "últimas", nos quedamos con la principal.
                val main = all.filter { it.synopsis.isNotEmpty() }
                val res = if (main.size >= 6) main else all
                if (res.isEmpty()) null else res
            } catch (e: Exception) {
                null
            }
        }

        fun parseDetail(json: String): MovieDetail? {
            return try {
                val o = JSONObject(json)
                val syn = o.optString("s")
                val ca = o.optJSONArray("c") ?: JSONArray()
                if (syn.isEmpty() && ca.length() == 0) return null
                val cast = ArrayList<String>()
                for (i in 0 until ca.length()) cast.add(ca.getString(i))
                MovieDetail(syn, o.optString("dir"), cast, o.optString("alt"), o.optString("img"))
            } catch (e: Exception) {
                null
            }
        }
    }

    /** Lanza todas las tareas a la vez y entrega la primera que trae películas (null si ninguna). */
    private fun tryFirst(jobs: List<((List<Movie>?) -> Unit) -> Unit>, done: (List<Movie>?) -> Unit) {
        if (jobs.isEmpty()) { done(null); return }
        var left = jobs.size
        var finished = false
        jobs.forEach { job ->
            job { r ->
                if (finished) return@job
                left--
                if (!r.isNullOrEmpty()) { finished = true; done(r) }
                else if (left == 0) { finished = true; done(null) }
            }
        }
    }

    /**
     * Buscador del Catálogo 1: la web busca en /buscar/?q=texto (con + en vez de espacios). Los resultados están
     * al final de la página, por eso se lee con [SEARCH_JS] y no con la lista normal.
     */
    fun fetchSearch(query: String, page: Int, done: (List<Movie>?) -> Unit) {
        val q = java.net.URLEncoder.encode(query.trim(), "UTF-8")
        fun job(url: String): ((List<Movie>?) -> Unit) -> Unit =
            { cb -> PageScraper(ctx, url, SEARCH_JS, { parseList(it) }).fetch(cb) }
        if (page <= 1) job("$LOCO/buscar/?q=$q")(done)
        // Páginas siguientes: la web puede paginar de dos maneras, se prueban las dos a la vez.
        else tryFirst(listOf(job("$LOCO/buscar/?q=$q&page=$page"), job("$LOCO/buscar/page/$page/?q=$q")), done)
    }

    fun fetchPage(url: String, done: (List<Movie>?) -> Unit) {
        if (isR24(url)) PageScraper(ctx, url, LIST_JS_R24, { parseListR24(it) }, guard = true, cf = true).fetch(done)
        else PageScraper(ctx, url, LIST_JS, { parseList(it) }).fetch(done)
    }

    /** Busca los reproductores (Opción 1, Opción 2…) de la página de una película. Null si no aparece ninguno. */
    fun fetchEmbeds(url: String, done: (List<String>?) -> Unit) {
        if (isR24(url)) PageScraper(ctx, url, EMBED_JS_R24, { parseEmbedsR24(it) }, guard = true, cf = true).fetch(done)
        else PageScraper(ctx, url, EMBED_JS, { parseEmbeds(it) }).fetch(done)
    }

    fun fetchDetail(url: String, done: (MovieDetail?) -> Unit) {
        if (isR24(url)) PageScraper(ctx, url, DETAIL_JS_R24, { parseDetail(it) }, guard = true, cf = true).fetch(done)
        else PageScraper(ctx, url, DETAIL_JS, { parseDetail(it) }).fetch(done)
    }
}

/** Descarga carátulas en segundo plano y las guarda en memoria para no bajarlas dos veces. */
object MovieImages {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val io = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    /** Pone la imagen de [url] en [iv]; si el ImageView ya se usó para otra imagen, se ignora el resultado tardío. */
    fun load(url: String, iv: ImageView) {
        iv.tag = url
        if (url.isEmpty()) return
        cache.get(url)?.let { iv.setImageBitmap(it); return }
        io.execute {
            val b = download(url)
            if (b != null) {
                cache.put(url, b)
                main.post { if (iv.tag == url) iv.setImageBitmap(b) }
            }
        }
    }

    private fun download(u: String): Bitmap? = try {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")
        if (u.contains("locopelis.com")) c.setRequestProperty("Referer", "https://www.locopelis.com/")
        if (u.contains("repelis24")) {
            c.setRequestProperty("Referer", "https://repelis24.shop/")
            // Si la web pidió verificación, las carátulas van con la misma cookie y User-Agent.
            CfGate.cachedUa()?.let { c.setRequestProperty("User-Agent", it) }
            try { CookieManager.getInstance().getCookie(u)?.let { c.setRequestProperty("Cookie", it) } } catch (e: Exception) { }
        }
        val bytes = c.inputStream.use { it.readBytes() }
        c.disconnect()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 400) sample *= 2
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    } catch (e: Exception) {
        null
    }
}
