package com.estebanruiz.estebantv

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Un canal donde se ve un evento (por ejemplo "ESPN" en calidad 720p) y su enlace. */
data class AgendaChannel(val name: String, val quality: String, val url: String)

/** Un evento de la agenda: hora, nombre del partido y sus canales. */
data class AgendaEvent(val time: String, val title: String, val channels: List<AgendaChannel>)

/** La agenda completa: el título del día, los eventos y cuándo se descargó. */
data class Agenda(val day: String, val events: List<AgendaEvent>, val fetchedAt: Long)

/** Guarda la última agenda descargada (SharedPreferences "agenda") para mostrarla al instante. */
class AgendaStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("agenda", Context.MODE_PRIVATE)

    fun cached(): Agenda? {
        val raw = p.getString("data", null) ?: return null
        return try {
            val o = JSONObject(raw)
            val arr = o.getJSONArray("events")
            val evs = ArrayList<AgendaEvent>()
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val cs = ArrayList<AgendaChannel>()
                val ca = e.optJSONArray("channels") ?: JSONArray()
                for (j in 0 until ca.length()) {
                    val c = ca.getJSONObject(j)
                    cs.add(AgendaChannel(c.optString("name"), c.optString("quality"), c.optString("url")))
                }
                evs.add(AgendaEvent(e.optString("time"), e.optString("title"), cs))
            }
            Agenda(o.optString("day"), evs, o.optLong("fetchedAt"))
        } catch (e: Exception) {
            null
        }
    }

    fun save(a: Agenda) {
        val evs = JSONArray()
        for (e in a.events) {
            val cs = JSONArray()
            for (c in e.channels) {
                cs.put(JSONObject().put("name", c.name).put("quality", c.quality).put("url", c.url))
            }
            evs.put(JSONObject().put("time", e.time).put("title", e.title).put("channels", cs))
        }
        val o = JSONObject().put("day", a.day).put("events", evs).put("fetchedAt", a.fetchedAt)
        p.edit().putString("data", o.toString()).apply()
    }
}

/** Un partido leído de Dzri TV: cuándo empieza (ms UTC, -1 si no se supo), nombre y enlace. */
data class DzriMatch(val epochMs: Long, val title: String, val url: String)

/**
 * Descarga la agenda de DOS páginas al mismo tiempo, cada una en un WebView invisible:
 *  - Rústico TV (varios canales por evento)
 *  - Dzri TV (un solo canal por partido, se llama "Stream 1")
 * y las junta en una sola lista ordenada por hora. Si un partido está en las dos, el de Dzri TV
 * se agrega justo debajo con "(opc2)" en el nombre para reconocerlo.
 * Cambia [URL] / [DZRI_URL] si algún día cambia la dirección.
 */
class AgendaFetcher(private val ctx: Context) {
    private val act: Activity? = ctx as? Activity
    companion object {
        const val URL = "https://rusticotv.la/agenda.php"
        const val DZRI_URL = "https://dzritv.com/sport/football"
        const val DZRI_CHANNEL = "Stream 1"
        const val OPC2 = "(opc2)"

        // Recorre la lista de la página: cada <li> de primer nivel es un evento y sus enlaces internos son los canales.
        private const val JS = """
(function(){
  try{
    var lis=document.querySelectorAll('li');
    var evs=[];
    for(var i=0;i<lis.length;i++){
      var li=lis[i];
      var p=li.parentElement;
      if(p && p.closest && p.closest('li')) continue;
      var c=li.cloneNode(true);
      var subs=c.querySelectorAll('ul,ol');
      for(var j=0;j<subs.length;j++){ subs[j].parentNode.removeChild(subs[j]); }
      var t=(c.textContent||'').replace(/\s+/g,' ').trim();
      if(!t) continue;
      var chs=[];
      var as=li.querySelectorAll('ul a, ol a');
      if(as.length==0){ as=li.querySelectorAll('a[href*="embed"]'); }
      for(var k=0;k<as.length;k++){
        var h=as[k].href||'';
        if(h.indexOf('http')!==0) continue;
        chs.push({n:(as[k].textContent||'').replace(/\s+/g,' ').trim(), u:h});
      }
      evs.push({t:t,c:chs});
    }
    var body=(document.body?document.body.innerText:'')||'';
    var m=body.match(/Agenda\s*-\s*[^\n\r]+/);
    return JSON.stringify({d:m?m[0].trim():'',e:evs});
  }catch(x){ return JSON.stringify({d:'',e:[],err:String(x)}); }
})()
"""

        // Dzri TV: cada partido es un enlace a /match/... con el texto "2026-09-29 23:15 Local - Visitante VIEW ONLINE".
        // La liga es el título que está justo antes del grupo de partidos. También se lee el reloj de la página
        // ("11:47:04 GMT+4") para saber en qué zona horaria vienen las horas y pasarlas a la de tu celular.
        private const val DZRI_JS = """
(function(){
  try{
    var sel='a[href*="/match/"]';
    var as=document.querySelectorAll(sel);
    var out=[]; var seen={};
    for(var i=0;i<as.length;i++){
      var a=as[i]; var h=a.href||'';
      if(!h||seen[h]) continue; seen[h]=1;
      var t=(a.textContent||'').replace(/\s+/g,' ').trim();
      var lg=''; var n=a;
      for(var up=0; up<4 && !lg && n; up++){
        var s=n.previousElementSibling; var hops=0;
        while(s && hops<80){
          var hasMatch=(s.matches&&s.matches(sel))||(s.querySelector&&s.querySelector(sel));
          if(!hasMatch){
            var st=(s.textContent||'').replace(/\s+/g,' ').trim();
            if(st && st.length<120 && !/^\d{4}-\d{2}-\d{2}/.test(st)){ lg=st; break; }
          }
          s=s.previousElementSibling; hops++;
        }
        n=n.parentElement;
      }
      out.push({t:t,u:h,l:lg});
    }
    var body=(document.body?document.body.innerText:'')||'';
    var m=body.match(/GMT\s*[+-]\d{1,2}(?::?\d{2})?/);
    return JSON.stringify({g:m?m[0]:'',e:out});
  }catch(x){ return JSON.stringify({g:'',e:[],err:String(x)}); }
})()
"""

        private val TIME_END = Regex("^(.*?)(\\d{1,2}:\\d{2}\\s?(?:[AaPp]\\.?[Mm]\\.?)?)$")
        private val DZ_RE = Regex("^(\\d{4})-(\\d{2})-(\\d{2})\\s+(\\d{1,2}):(\\d{2})\\s+(.*)$")

        fun parse(json: String): Agenda? {
            return try {
                val o = JSONObject(json)
                val arr = o.getJSONArray("e")
                val evs = ArrayList<AgendaEvent>()
                for (i in 0 until arr.length()) {
                    val e = arr.getJSONObject(i)
                    val raw = e.optString("t").trim()
                    var title = raw
                    var time = ""
                    val m = TIME_END.find(raw)
                    if (m != null) {
                        title = m.groupValues[1].trim()
                        time = m.groupValues[2].trim()
                    }
                    if (title.isEmpty()) continue
                    val cs = ArrayList<AgendaChannel>()
                    val ca = e.optJSONArray("c") ?: JSONArray()
                    for (j in 0 until ca.length()) {
                        val c = ca.getJSONObject(j)
                        val label = c.optString("n")
                        val name = label.substringBefore("Calidad").trim()
                        val quality = if ("Calidad" in label) label.substringAfter("Calidad").trim() else ""
                        val url = c.optString("u")
                        if (url.isNotEmpty()) cs.add(AgendaChannel(name.ifEmpty { "Canal ${j + 1}" }, quality, url))
                    }
                    evs.add(AgendaEvent(time, title, cs))
                }
                if (evs.isEmpty()) null else Agenda(o.optString("d"), evs, System.currentTimeMillis())
            } catch (e: Exception) {
                null
            }
        }

        /** "GMT+4" -> 240 minutos. Si la página no lo trae se asume GMT+4 (la zona que usa Dzri TV). */
        private fun gmtOffsetMin(s: String): Int {
            val m = Regex("GMT\\s*([+-])(\\d{1,2})(?::?(\\d{2}))?").find(s) ?: return 240
            val sign = if (m.groupValues[1] == "-") -1 else 1
            val mins = m.groupValues[3].ifEmpty { "0" }.toInt()
            return sign * (m.groupValues[2].toInt() * 60 + mins)
        }

        fun parseDzri(json: String): List<DzriMatch>? {
            return try {
                val o = JSONObject(json)
                val off = gmtOffsetMin(o.optString("g"))
                val arr = o.getJSONArray("e")
                val out = ArrayList<DzriMatch>()
                for (i in 0 until arr.length()) {
                    val e = arr.getJSONObject(i)
                    val url = e.optString("u")
                    if (url.isEmpty()) continue
                    val raw = e.optString("t").replace(Regex("\\s*VIEW ONLINE\\s*$", RegexOption.IGNORE_CASE), "").trim()
                    var epoch = -1L
                    var rest = raw
                    val m = DZ_RE.find(raw)
                    if (m != null) {
                        val cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"))
                        cal.clear()
                        cal.set(m.groupValues[1].toInt(), m.groupValues[2].toInt() - 1, m.groupValues[3].toInt(),
                            m.groupValues[4].toInt(), m.groupValues[5].toInt(), 0)
                        epoch = cal.timeInMillis - off * 60_000L
                        rest = m.groupValues[6].trim()
                    }
                    val teams = rest.split(Regex("\\s+-\\s+"), 2)
                    val name = if (teams.size == 2) teams[0].trim() + " vs " + teams[1].trim() else rest
                    if (name.isBlank()) continue
                    val league = e.optString("l").trim().trimEnd('.').trim()
                    out.add(DzriMatch(epoch, if (league.isNotEmpty()) "$league: $name" else name, url))
                }
                if (out.isEmpty()) null else out
            } catch (e: Exception) {
                null
            }
        }

        // ---- Unir las dos agendas ----

        private fun norm(s: String): String =
            Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
                .replace(Regex("\\p{Mn}+"), "")
                .replace(Regex("[^a-z0-9 ]"), " ")
                .replace(Regex("\\s+"), " ").trim()

        // Nombres de selecciones en español -> inglés (Dzri TV está en inglés). Ya sin tildes.
        private val ALIAS: Map<String, String> = mapOf(
            "espana" to "spain", "croacia" to "croatia", "alemania" to "germany", "inglaterra" to "england",
            "francia" to "france", "italia" to "italy", "paises bajos" to "netherlands", "holanda" to "netherlands",
            "belgica" to "belgium", "suiza" to "switzerland", "escocia" to "scotland", "gales" to "wales",
            "irlanda" to "republic of ireland", "eire" to "republic of ireland", "irlanda del norte" to "northern ireland",
            "dinamarca" to "denmark", "suecia" to "sweden", "noruega" to "norway", "finlandia" to "finland",
            "islandia" to "iceland", "polonia" to "poland", "republica checa" to "czech republic",
            "chequia" to "czech republic", "rep checa" to "czech republic", "eslovaquia" to "slovakia",
            "eslovenia" to "slovenia", "hungria" to "hungary", "rumania" to "romania", "grecia" to "greece",
            "turquia" to "turkey", "ucrania" to "ukraine", "bosnia y herzegovina" to "bosnia herzegovina",
            "bosnia herzegovina" to "bosnia herzegovina", "macedonia del norte" to "north macedonia",
            "azerbaiyan" to "azerbaijan", "kazajistan" to "kazakhstan", "kazajstan" to "kazakhstan",
            "chipre" to "cyprus", "luxemburgo" to "luxembourg", "islas feroe" to "faroe islands",
            "letonia" to "latvia", "lituania" to "lithuania", "moldavia" to "moldova", "bielorrusia" to "belarus",
            "brasil" to "brazil", "peru" to "peru", "mexico" to "mexico", "estados unidos" to "usa",
            "united states" to "usa", "eeuu" to "usa", "ee uu" to "usa", "canada" to "canada",
            "islas virgenes britanicas" to "british virgin islands", "islas turcas y caicos" to "turks and caicos islands",
            "islas turcas y caicos" to "turks and caicos islands", "cabo verde" to "cape verde",
            "costa de marfil" to "ivory coast", "camerun" to "cameroon", "egipto" to "egypt",
            "marruecos" to "morocco", "tunez" to "tunisia", "argelia" to "algeria", "sudafrica" to "south africa",
            "japon" to "japan", "corea del sur" to "south korea", "arabia saudita" to "saudi arabia",
            "arabia saudi" to "saudi arabia", "catar" to "qatar", "irak" to "iraq", "trinidad y tobago" to "trinidad and tobago",
            "curazao" to "curacao", "haiti" to "haiti", "republica dominicana" to "dominican republic",
            "nueva zelanda" to "new zealand", "gibraltar" to "gibraltar", "malta" to "malta",
        )

        private fun canon(name: String): String {
            val n = norm(name)
            return ALIAS[n] ?: n
        }

        /** "Liga: A vs B" -> (A, B) ya normalizados; null si no se puede separar. */
        private fun teamsOf(title: String): Pair<String, String>? {
            val t = title.substringAfterLast(":")
            val parts = t.trim().split(Regex("\\s+(?:vs\\.?|v|contra|-|–)\\s+", RegexOption.IGNORE_CASE))
            if (parts.size != 2) return null
            val a = canon(parts[0])
            val b = canon(parts[1])
            return if (a.isEmpty() || b.isEmpty()) null else a to b
        }

        private fun sameTeam(a: String, b: String): Boolean {
            if (a == b) return true
            val ta = a.split(' ').toSet()
            val tb = b.split(' ').toSet()
            val (s, l) = if (ta.size <= tb.size) ta to tb else tb to ta
            return s.joinToString(" ").length >= 4 && l.containsAll(s)
        }

        /** true si el primer equipo del título (el de la izquierda) es [team]. */
        fun firstTeamIs(title: String, team: String): Boolean {
            val t = teamsOf(title) ?: return true
            return sameTeam(t.first, canon(team))
        }

        /** Mismo partido = mismos dos equipos (en cualquier orden). La hora no se compara: dos partidos iguales el mismo día no existen. */
        fun sameMatch(t1: String, t2: String): Boolean {
            val a = teamsOf(t1)
            val b = teamsOf(t2)
            if (a == null || b == null) return norm(t1) == norm(t2)
            return (sameTeam(a.first, b.first) && sameTeam(a.second, b.second)) ||
                (sameTeam(a.first, b.second) && sameTeam(a.second, b.first))
        }

        /** Minutos desde 00:00 de "20:45" o "8:45 PM"; -1 si no hay hora. */
        private fun minutesOf(t: String): Int {
            val m = Regex("(\\d{1,2}):(\\d{2})\\s*([AaPp])?").find(t) ?: return -1
            var h = m.groupValues[1].toInt()
            if (m.groupValues[3].isNotEmpty()) {
                h %= 12
                if (m.groupValues[3].lowercase() == "p") h += 12
            }
            return h * 60 + m.groupValues[2].toInt()
        }

        /** El "día de fútbol" empieza a las 05:00: así los partidos de después de medianoche quedan al final. */
        private fun sortKey(min: Int): Double = if (min < 0) 100_000.0 else ((min - 300 + 1440) % 1440).toDouble()

        fun combine(rus: Agenda?, dz: List<DzriMatch>?): Agenda? {
            if (rus == null && dz == null) return null
            val now = System.currentTimeMillis()

            // Ventana: desde las 05:00 de hoy hasta las 05:00 de mañana (hora de tu celular).
            val c = Calendar.getInstance()
            c.timeInMillis = now
            c.add(Calendar.HOUR_OF_DAY, -5)
            c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
            c.add(Calendar.HOUR_OF_DAY, 5)
            val dayStart = c.timeInMillis
            val dayEnd = dayStart + 24L * 3_600_000L

            val base = rus?.events ?: emptyList()
            val ampm = base.any { Regex("[AaPp]\\.?[Mm]").containsMatchIn(it.time) }
            val fmt = SimpleDateFormat(if (ampm) "h:mm a" else "HH:mm", Locale.US)

            val keyed = ArrayList<Pair<Double, AgendaEvent>>()
            val baseKeys = ArrayList<Double>()
            for (e in base) {
                val k = sortKey(minutesOf(e.time))
                baseKeys.add(k)
                keyed.add(k to e)
            }
            for (d in dz ?: emptyList()) {
                if (d.epochMs >= 0 && (d.epochMs < dayStart || d.epochMs >= dayEnd)) continue
                val time = if (d.epochMs >= 0) fmt.format(Date(d.epochMs)) else ""
                val ch = listOf(AgendaChannel(DZRI_CHANNEL, "", d.url))
                val idx = base.indexOfFirst { sameMatch(it.title, d.title) }
                if (idx >= 0) {
                    // Repetido: se queda el de Rústico y este (1 solo stream) va debajo marcado como opc2.
                    keyed.add((baseKeys[idx] + 0.5) to AgendaEvent(base[idx].time.ifEmpty { time }, base[idx].title + "  " + OPC2, ch))
                } else {
                    keyed.add(sortKey(minutesOf(time)) to AgendaEvent(time, d.title, ch))
                }
            }
            val events = keyed.sortedBy { it.first }.map { it.second }
            if (events.isEmpty()) return null
            return Agenda(rus?.day?.ifEmpty { "Agenda" } ?: "Agenda", events, now)
        }
    }

    /** Baja las dos agendas a la vez. Llamar desde el hilo principal; [done] recibe la agenda o null si fallaron las dos. */
    fun fetch(done: (Agenda?) -> Unit) {
        var rus: Agenda? = null
        var dz: List<DzriMatch>? = null
        var pending = 2
        fun check() {
            pending--
            if (pending == 0) done(combine(rus, dz))
        }
        PageScraper(ctx, URL, JS, { parse(it) }).fetch { rus = it; check() }
        PageScraper(ctx, DZRI_URL, DZRI_JS, { parseDzri(it) }).fetch { dz = it; check() }
    }
}

/**
 * Carga una página en un WebView invisible, le pregunta el JS cada rato hasta que [parse] devuelva algo
 * (así funciona aunque la página arme todo con JavaScript) y entrega el resultado o null si se acabó el tiempo.
 */
internal class PageScraper<T : Any>(
    private val ctx: Context,
    private val url: String,
    private val js: String,
    private val parse: (String) -> T?,
    private val chromeUa: Boolean = false,
) {
    private val act: Activity? = ctx as? Activity
    private val handler = Handler(Looper.getMainLooper())
    private var web: WebView? = null
    private var finished = false
    private var attempts = 0

    @SuppressLint("SetJavaScriptEnabled")
    fun fetch(done: (T?) -> Unit) {
        val w = WebView(ctx)
        web = w
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.blockNetworkImage = true
        // Algunas webs bloquean al WebView "de app" (lleva "; wv"): se presenta como un Chrome normal de celular.
        if (chromeUa) w.settings.userAgentString = w.settings.userAgentString.replace("; wv", "").replace(Regex("Version/\\d+\\.\\d+ "), "")
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (!finished) handler.postDelayed({ poll(done) }, 600)
            }
        }
        // Tiempo máximo: 20 segundos.
        handler.postDelayed({ finish(null, done) }, 20_000)
        w.loadUrl(url)
    }

    private fun poll(done: (T?) -> Unit) {
        val w = web
        if (finished || w == null) return
        attempts++
        w.evaluateJavascript(js) { raw ->
            if (finished) return@evaluateJavascript
            val result = try {
                val s = JSONTokener(raw).nextValue() as? String
                if (s != null) parse(s) else null
            } catch (e: Exception) {
                null
            }
            if (result != null) finish(result, done)
            else if (attempts >= 12) finish(null, done)
            else handler.postDelayed({ poll(done) }, 800)
        }
    }

    private fun finish(r: T?, done: (T?) -> Unit) {
        if (finished) return
        finished = true
        handler.removeCallbacksAndMessages(null)
        try {
            web?.stopLoading()
            web?.destroy()
        } catch (e: Exception) { }
        web = null
        if (act == null || (!act.isFinishing && !act.isDestroyed)) done(r)
    }
}
