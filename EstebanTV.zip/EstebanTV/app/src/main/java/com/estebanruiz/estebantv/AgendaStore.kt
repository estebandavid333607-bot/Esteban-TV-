package com.estebanruiz.estebantv

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

/** Un canal donde se ve un evento (por ejemplo "ESPN" en calidad 720p) y su enlace. */
data class AgendaChannel(val name: String, val quality: String, val url: String)

/** Un evento de la agenda: hora, nombre del partido y sus canales. */
data class AgendaEvent(val time: String, val title: String, val channels: List<AgendaChannel>)

/** La agenda completa: el título del día, los eventos y cuándo se descargó. */
data class Agenda(val day: String, val events: List<AgendaEvent>, val fetchedAt: Long)

/** Guarda la última agenda descargada (SharedPreferences "agenda") para mostrarla al instante. */
class AgendaStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("agenda", Context.MODE_PRIVATE)

    fun cached(): Agenda? {
        val raw = p.getString("data", null) ?: return null
        return try {
            val o = JSONObject(raw)
            val arr = o.getJSONArray("events")
            val evs = ArrayList<AgendaEvent>()
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val cs = ArrayList<AgendaChannel>()
                val ca = e.optJSONArray("channels") ?: JSONArray()
                for (j in 0 until ca.length()) {
                    val c = ca.getJSONObject(j)
                    cs.add(AgendaChannel(c.optString("name"), c.optString("quality"), c.optString("url")))
                }
                evs.add(AgendaEvent(e.optString("time"), e.optString("title"), cs))
            }
            Agenda(o.optString("day"), evs, o.optLong("fetchedAt"))
        } catch (e: Exception) {
            null
        }
    }

    fun save(a: Agenda) {
        val evs = JSONArray()
        for (e in a.events) {
            val cs = JSONArray()
            for (c in e.channels) {
                cs.put(JSONObject().put("name", c.name).put("quality", c.quality).put("url", c.url))
            }
            evs.put(JSONObject().put("time", e.time).put("title", e.title).put("channels", cs))
        }
        val o = JSONObject().put("day", a.day).put("events", evs).put("fetchedAt", a.fetchedAt)
        p.edit().putString("data", o.toString()).apply()
    }
}

/**
 * Descarga la agenda cargando la página de Rústico TV en un WebView invisible y leyendo los eventos
 * ya armados (así funciona aunque la página los arme con JavaScript y respeta la hora local).
 * Cambia [URL] si algún día cambia la dirección de la agenda.
 */
class AgendaFetcher(private val act: Activity) {
    companion object {
        const val URL = "https://rusticotv.la/agenda.php"

        // Recorre la lista de la página: cada <li> de primer nivel es un evento y sus enlaces internos son los canales.
        private const val JS = """
(function(){
  try{
    var lis=document.querySelectorAll('li');
    var evs=[];
    for(var i=0;i<lis.length;i++){
      var li=lis[i];
      var p=li.parentElement;
      if(p && p.closest && p.closest('li')) continue;
      var c=li.cloneNode(true);
      var subs=c.querySelectorAll('ul,ol');
      for(var j=0;j<subs.length;j++){ subs[j].parentNode.removeChild(subs[j]); }
      var t=(c.textContent||'').replace(/\s+/g,' ').trim();
      if(!t) continue;
      var chs=[];
      var as=li.querySelectorAll('ul a, ol a');
      if(as.length==0){ as=li.querySelectorAll('a[href*="embed"]'); }
      for(var k=0;k<as.length;k++){
        var h=as[k].href||'';
        if(h.indexOf('http')!==0) continue;
        chs.push({n:(as[k].textContent||'').replace(/\s+/g,' ').trim(), u:h});
      }
      evs.push({t:t,c:chs});
    }
    var body=(document.body?document.body.innerText:'')||'';
    var m=body.match(/Agenda\s*-\s*[^\n\r]+/);
    return JSON.stringify({d:m?m[0].trim():'',e:evs});
  }catch(x){ return JSON.stringify({d:'',e:[],err:String(x)}); }
})()
"""

        private val TIME_END = Regex("^(.*?)(\\d{1,2}:\\d{2}\\s?(?:[AaPp]\\.?[Mm]\\.?)?)$")

        fun parse(json: String): Agenda? {
            return try {
                val o = JSONObject(json)
                val arr = o.getJSONArray("e")
                val evs = ArrayList<AgendaEvent>()
                for (i in 0 until arr.length()) {
                    val e = arr.getJSONObject(i)
                    val raw = e.optString("t").trim()
                    var title = raw
                    var time = ""
                    val m = TIME_END.find(raw)
                    if (m != null) {
                        title = m.groupValues[1].trim()
                        time = m.groupValues[2].trim()
                    }
                    if (title.isEmpty()) continue
                    val cs = ArrayList<AgendaChannel>()
                    val ca = e.optJSONArray("c") ?: JSONArray()
                    for (j in 0 until ca.length()) {
                        val c = ca.getJSONObject(j)
                        val label = c.optString("n")
                        val name = label.substringBefore("Calidad").trim()
                        val quality = if ("Calidad" in label) label.substringAfter("Calidad").trim() else ""
                        val url = c.optString("u")
                        if (url.isNotEmpty()) cs.add(AgendaChannel(name.ifEmpty { "Canal ${j + 1}" }, quality, url))
                    }
                    evs.add(AgendaEvent(time, title, cs))
                }
                if (evs.isEmpty()) null else Agenda(o.optString("d"), evs, System.currentTimeMillis())
            } catch (e: Exception) {
                null
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var web: WebView? = null
    private var finished = false
    private var attempts = 0

    /** Baja la agenda. Llamar desde el hilo principal; [done] recibe la agenda o null si falló. */
    @SuppressLint("SetJavaScriptEnabled")
    fun fetch(done: (Agenda?) -> Unit) {
        val w = WebView(act)
        web = w
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.blockNetworkImage = true
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (!finished) handler.postDelayed({ poll(done) }, 600)
            }
        }
        // Tiempo máximo: 20 segundos.
        handler.postDelayed({ finish(null, done) }, 20_000)
        w.loadUrl(URL)
    }

    private fun poll(done: (Agenda?) -> Unit) {
        val w = web
        if (finished || w == null) return
        attempts++
        w.evaluateJavascript(JS) { raw ->
            if (finished) return@evaluateJavascript
            val agenda = try {
                val s = JSONTokener(raw).nextValue() as? String
                if (s != null) parse(s) else null
            } catch (e: Exception) {
                null
            }
            if (agenda != null) finish(agenda, done)
            else if (attempts >= 12) finish(null, done)
            else handler.postDelayed({ poll(done) }, 800)
        }
    }

    private fun finish(a: Agenda?, done: (Agenda?) -> Unit) {
        if (finished) return
        finished = true
        handler.removeCallbacksAndMessages(null)
        try {
            web?.stopLoading()
            web?.destroy()
        } catch (e: Exception) { }
        web = null
        if (!act.isFinishing && !act.isDestroyed) done(a)
    }
}
