package com.estebanruiz.estebantv

/**
 * Canales que vienen YA INSTALADOS en la app (todos los usuarios los ven).
 * Se actualizan al instalar una versión nueva de la app.
 *
 * Channel(id, nombre, logo, urlDelVideo)
 *  - id:    texto único y fijo para cada canal (no lo cambies después, ej. "canal1").
 *  - logo:  una URL de imagen (https://...) o "res:nombre" para usar una imagen que pongas en
 *           app/src/main/res/drawable-nodpi/nombre.png  (solo minúsculas, números y _ ). Puede ir vacío "".
 *  - url:   enlace del video (.m3u8, .mpd, .mp4).
 */
object DefaultChannels {
    val list: List<Channel> = listOf(
        // Channel("canal1", "Mi Canal", "https://ejemplo.com/logo.png", "https://ejemplo.com/canal1/index.m3u8"),
    )
}
