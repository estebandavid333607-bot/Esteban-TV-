package com.estebanruiz.estebantv

import android.content.Context
import android.graphics.Color
import android.os.SystemClock

/**
 * Color "RGB" (como los teclados gamer): en vez de un color fijo recorre TODO el espectro sin parar.
 * Se guarda en los ajustes con el valor especial [MARKER] y [color] da el tono de este instante
 * ([offsetDeg] lo adelanta, para que cada elemento lleve un tono distinto y se vea una onda de colores).
 */
object Rgb {
    const val MARKER = 1
    private const val PERIOD_MS = 5000L // una vuelta completa al arcoíris

    fun color(offsetDeg: Float = 0f): Int {
        val h = ((SystemClock.uptimeMillis() % PERIOD_MS) * 360f / PERIOD_MS + offsetDeg) % 360f
        return Color.HSVToColor(floatArrayOf(h, 1f, 1f))
    }

    /** Arcoíris completo (para dibujar la muestra de la paleta). */
    val spectrum: IntArray = IntArray(7) { Color.HSVToColor(floatArrayOf((it % 6) * 60f, 1f, 1f)) }
}

/** Ajustes de la app (SharedPreferences "settings"). Mantiene las claves antiguas. */
class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private fun b(k: String, d: Boolean) = p.getBoolean(k, d)
    private fun i(k: String, d: Int) = p.getInt(k, d)
    private fun s(k: String, d: String) = p.getString(k, d) ?: d
    private fun put(k: String, v: Boolean) = p.edit().putBoolean(k, v).apply()
    private fun put(k: String, v: Int) = p.edit().putInt(k, v).apply()
    private fun put(k: String, v: String) = p.edit().putString(k, v).apply()

    var blockAds: Boolean get() = b("blockAds", true); set(v) = put("blockAds", v)
    var autoPlayer: Boolean get() = b("autoPlayer", true); set(v) = put("autoPlayer", v)
    var desktopMode: Boolean get() = b("desktopMode", false); set(v) = put("desktopMode", v)

    /** Preguntar Sí/No antes de abrir ExoPlayer. */
    var confirmExo: Boolean get() = b("confirmExo", true); set(v) = put("confirmExo", v)

    /** 0 = desactivada, 1 = solo tras 2 toques, 2 = nunca redirigir. */
    var redirMode: Int get() = i("redirMode", 2); set(v) = put("redirMode", v)

    /** 0 = sistema, 1 = automática (sensor), 2 = vertical, 3 = horizontal. */
    var rotation: Int get() = i("rotation", 0); set(v) = put("rotation", v)

    var restoreLast: Boolean get() = b("restoreLast", true); set(v) = put("restoreLast", v)
    var lastPage: String get() = s("lastPage", ""); set(v) = put("lastPage", v)
    var welcome: Boolean get() = b("welcome", false); set(v) = put("welcome", v)
    var accent: Int get() = i("accent", 0xFF39FF14.toInt()); set(v) = put("accent", v)

    /** true si el color elegido es RGB (animado). */
    val isRgb: Boolean get() = accent == Rgb.MARKER

    /** El color a pintar AHORA: el elegido, o el tono del arcoíris de este instante si es RGB. */
    val accentColor: Int get() = if (accent == Rgb.MARKER) Rgb.color() else accent

    /** true cuando el usuario ya eligió su color favorito (la pregunta de la primera vez no vuelve a salir). */
    var colorChosen: Boolean get() = b("colorChosen", false); set(v) = put("colorChosen", v)
    var searchEngine: Int get() = i("searchEngine", 0); set(v) = put("searchEngine", v)
    var textZoom: Int get() = i("textZoom", 100); set(v) = put("textZoom", v)
    var loadImages: Boolean get() = b("loadImages", true); set(v) = put("loadImages", v)
    var thirdPartyCookies: Boolean get() = b("thirdPartyCookies", true); set(v) = put("thirdPartyCookies", v)
    var fullscreen: Boolean get() = b("fullscreen", false); set(v) = put("fullscreen", v)

    /** Seguir reproduciendo con la app en segundo plano / pantalla apagada. */
    var bgPlay: Boolean get() = b("bgPlay", true); set(v) = put("bgPlay", v)

    /** Altura máxima de video en ExoPlayer (0 = sin límite). */
    var maxQuality: Int get() = i("maxQuality", 0); set(v) = put("maxQuality", v)

    fun reset() {
        val keep = lastPage
        p.edit().clear().apply()
        lastPage = keep
    }
}
