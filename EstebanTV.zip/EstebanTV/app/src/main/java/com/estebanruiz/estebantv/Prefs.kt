package com.estebanruiz.estebantv

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.util.TypedValue

data class Palette(val name: String, val styleRes: Int, val swatch: Int)

/** Paletas de color: cada una es un tema (Theme.EstebanTV.P0..P7) que redefine los ?attr/etvXxx. */
object Palettes {
    val all = listOf(
        Palette("Neón verde", R.style.Theme_EstebanTV_P0, 0xFF39FF14.toInt()),
        Palette("Cian eléctrico", R.style.Theme_EstebanTV_P1, 0xFF00E5FF.toInt()),
        Palette("Magenta", R.style.Theme_EstebanTV_P2, 0xFFFF2BD6.toInt()),
        Palette("Ámbar", R.style.Theme_EstebanTV_P3, 0xFFFFB300.toInt()),
        Palette("Rojo carmesí", R.style.Theme_EstebanTV_P4, 0xFFFF3B4E.toInt()),
        Palette("Violeta", R.style.Theme_EstebanTV_P5, 0xFFA66BFF.toInt()),
        Palette("Azul hielo", R.style.Theme_EstebanTV_P6, 0xFF4DA3FF.toInt()),
        Palette("Blanco mono", R.style.Theme_EstebanTV_P7, 0xFFFFFFFF.toInt())
    )

    fun themeFor(index: Int): Int = all[index.coerceIn(0, all.size - 1)].styleRes
}

data class SearchEngine(val name: String, val url: String) // url lleva %s donde va la búsqueda

object Prefs {
    const val FILE = "settings"

    const val BLOCK_ADS = "blockAds"
    const val AUTO_PLAYER = "autoPlayer"
    const val ASK_PLAYER = "askPlayer"
    const val DESKTOP = "desktopMode"
    const val RESTORE_LAST = "restoreLast"
    const val LAST_URL = "lastUrl"
    const val PALETTE = "palette"
    const val ORIENT = "orientation"
    const val ENGINE = "engine"
    const val TEXT_ZOOM = "textZoom"
    const val KEEP_ON = "keepOn"
    const val NO_IMAGES = "noImages"
    const val JS = "js"
    const val THIRD_COOKIES = "thirdCookies"
    const val IMMERSIVE = "immersive"
    const val MAX_QUALITY = "maxQuality"

    val engines = listOf(
        SearchEngine("Google", "https://www.google.com/search?q=%s"),
        SearchEngine("DuckDuckGo", "https://duckduckgo.com/?q=%s"),
        SearchEngine("Bing", "https://www.bing.com/search?q=%s"),
        SearchEngine("Brave", "https://search.brave.com/search?q=%s"),
        SearchEngine("Ecosia", "https://www.ecosia.org/search?q=%s")
    )

    val orientLabels = listOf(
        "Automática (siempre gira)",
        "Seguir el ajuste del sistema",
        "Solo vertical",
        "Solo horizontal",
        "Bloquear orientación actual"
    )

    fun of(c: Context): SharedPreferences = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** 0 = automática (ignora el bloqueo del sistema), 1 = sistema, 2 = vertical, 3 = horizontal, 4 = bloqueada */
    fun orientationFlag(mode: Int): Int = when (mode) {
        1 -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        3 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        4 -> ActivityInfo.SCREEN_ORIENTATION_LOCKED
        else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
    }
}

/** Color del tema activo (p. ej. R.attr.etvAccent). */
fun Context.attrColor(attr: Int): Int {
    val tv = TypedValue()
    theme.resolveAttribute(attr, tv, true)
    return tv.data
}
