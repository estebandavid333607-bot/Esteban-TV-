package com.estebanruiz.estebantv

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import java.io.ByteArrayInputStream

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var etUrl: EditText
    private lateinit var progress: ProgressBar
    private lateinit var home: View
    private lateinit var btnFav: ImageButton
    private lateinit var favContainer: LinearLayout
    private lateinit var playerLayer: View
    private lateinit var playerView: PlayerView
    private lateinit var playerTopBar: View
    private lateinit var btnQuality: TextView
    private lateinit var customContainer: FrameLayout
    private lateinit var favs: FavoritesStore
    private lateinit var favicons: FaviconStore
    private lateinit var prefs: SharedPreferences

    private var player: ExoPlayer? = null
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var defaultUa = ""
    private var pageTitle = ""
    private var clearHistoryOnBlank = false
    private var paletteAtCreate = 0
    private var appliedKey = ""

    @Volatile private var currentPageUrl = ""
    @Volatile private var playerOpen = false
    @Volatile private var promptShowing = false
    @Volatile private var sniffCooldownUntil = 0L
    @Volatile private var suppressedDomain = ""
    @Volatile private var blockAds = true
    @Volatile private var autoPlayer = true
    @Volatile private var askPlayer = true
    private var desktopMode = false
    private var restoreLast = true
    private var immersive = false

    private val desktopUa =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = Prefs.of(this)
        paletteAtCreate = prefs.getInt(Prefs.PALETTE, 0)
        setTheme(Palettes.themeFor(paletteAtCreate)) // la paleta se aplica antes de crear la interfaz
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        favs = FavoritesStore(this)
        favicons = FaviconStore(this)
        loadPrefs()

        webView = findViewById(R.id.webView)
        etUrl = findViewById(R.id.etUrl)
        progress = findViewById(R.id.progress)
        home = findViewById(R.id.home)
        btnFav = findViewById(R.id.btnFav)
        favContainer = findViewById(R.id.favContainer)
        playerLayer = findViewById(R.id.playerLayer)
        playerView = findViewById(R.id.playerView)
        playerTopBar = findViewById(R.id.playerTopBar)
        btnQuality = findViewById(R.id.btnQuality)
        customContainer = findViewById(R.id.customContainer)

        setupWebView()
        setupUi()
        refreshFavs()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> hideCustomView()
                    playerOpen -> closePlayer()
                    webView.visibility == View.VISIBLE && webView.canGoBack() -> webView.goBack()
                    webView.visibility == View.VISIBLE -> goHome()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        // Reabrir donde se quedó: primero lo guardado al recrear la actividad, luego la última página
        val restore: String? = savedInstanceState?.getString("url")
            ?: if (restoreLast) prefs.getString(Prefs.LAST_URL, "") else ""
        if (!restore.isNullOrEmpty()) openUrl(restore)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("url", visiblePageUrl())
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        refreshFavs() // 3 columnas en vertical, 5 en horizontal
    }

    override fun onPause() {
        super.onPause()
        saveLastUrl()
        player?.pause()
        webView.onPause()
    }

    override fun onResume() {
        super.onResume()
        // Cambió la paleta en Ajustes: se recrea la pantalla (la página se restaura sola)
        if (prefs.getInt(Prefs.PALETTE, 0) != paletteAtCreate) {
            recreate()
            return
        }
        loadPrefs()
        applyWebSettings()
        if (!playerOpen) webView.onResume()
        applyOrientation()
        applyKeepOn()
        updateBars()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        webView.destroy()
        super.onDestroy()
    }

    private fun loadPrefs() {
        blockAds = prefs.getBoolean(Prefs.BLOCK_ADS, true)
        autoPlayer = prefs.getBoolean(Prefs.AUTO_PLAYER, true)
        askPlayer = prefs.getBoolean(Prefs.ASK_PLAYER, true)
        desktopMode = prefs.getBoolean(Prefs.DESKTOP, false)
        restoreLast = prefs.getBoolean(Prefs.RESTORE_LAST, true)
        immersive = prefs.getBoolean(Prefs.IMMERSIVE, false)
    }

    private fun setPref(key: String, value: Boolean) = prefs.edit().putBoolean(key, value).apply()

    private fun visiblePageUrl(): String = if (webView.visibility == View.VISIBLE) currentPageUrl else ""

    private fun saveLastUrl() {
        prefs.edit().putString(Prefs.LAST_URL, visiblePageUrl()).apply()
    }

    // ------------------------------------------------------------------ rotación / pantalla

    /** Aplica la orientación elegida en Ajustes (salvo que el reproductor o un video a pantalla completa la controlen). */
    private fun applyOrientation() {
        if (playerOpen || customView != null) return
        requestedOrientation = Prefs.orientationFlag(prefs.getInt(Prefs.ORIENT, 0))
    }

    /** Gira la pantalla a mano: de vertical a horizontal y viceversa. */
    private fun toggleRotation() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    private fun applyKeepOn() {
        if (playerOpen || prefs.getBoolean(Prefs.KEEP_ON, false)) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun updateBars() = hideSystemBars(playerOpen || customView != null || immersive)

    private fun hideSystemBars(hide: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (hide) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ------------------------------------------------------------------ interfaz

    private fun setupUi() {
        findViewById<View>(R.id.btnHome).setOnClickListener { goHome() }
        findViewById<View>(R.id.googleCard).setOnClickListener { openUrl("https://www.google.com") }
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu(it) }
        findViewById<View>(R.id.btnClosePlayer).setOnClickListener { closePlayer() }
        findViewById<View>(R.id.btnRotatePlayer).setOnClickListener { toggleRotation() }
        btnQuality.setOnClickListener { showQualityDialog() }

        // Los botones del reproductor aparecen y se ocultan junto con los controles
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
            playerTopBar.visibility = if (v == View.VISIBLE) View.VISIBLE else View.GONE
        })

        btnFav.setOnClickListener { toggleFavorite() }

        etUrl.setOnEditorActionListener { _, actionId, event ->
            val enter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                loadInput(etUrl.text.toString())
                hideKeyboard()
                true
            } else false
        }
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(etUrl.windowToken, 0)
        etUrl.clearFocus()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        val pageOpen = webView.visibility == View.VISIBLE && currentPageUrl.isNotEmpty()
        pm.menu.add(0, 1, 0, "Recargar").isEnabled = pageOpen
        pm.menu.add(0, 2, 1, "Adelante").isEnabled = pageOpen && webView.canGoForward()
        pm.menu.add(0, 3, 2, "Girar pantalla")
        pm.menu.add(0, 4, 3, "Compartir enlace").isEnabled = pageOpen
        pm.menu.add(0, 5, 4, "Copiar enlace").isEnabled = pageOpen
        pm.menu.add(0, 6, 5, "Abrir en otro navegador").isEnabled = pageOpen
        pm.menu.add(0, 7, 6, "Modo escritorio").apply { isCheckable = true; isChecked = desktopMode }
        pm.menu.add(0, 8, 7, "Bloquear popups y anuncios").apply { isCheckable = true; isChecked = blockAds }
        pm.menu.add(0, 9, 8, "Abrir videos en ExoPlayer").apply { isCheckable = true; isChecked = autoPlayer }
        pm.menu.add(0, 10, 9, "Ajustes")
        pm.menu.add(0, 11, 10, "Acerca de")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> webView.reload()
                2 -> if (webView.canGoForward()) webView.goForward()
                3 -> toggleRotation()
                4 -> startActivity(
                    Intent.createChooser(
                        Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, currentPageUrl)
                        },
                        "Compartir enlace"
                    )
                )
                5 -> {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("url", currentPageUrl))
                    toast("Enlace copiado")
                }
                6 -> try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(currentPageUrl)))
                } catch (e: Exception) {
                    toast("No hay otro navegador instalado")
                }
                7 -> {
                    desktopMode = !desktopMode
                    setPref(Prefs.DESKTOP, desktopMode)
                    applyWebSettings() // recarga sola si hay una página abierta
                }
                8 -> {
                    blockAds = !blockAds
                    setPref(Prefs.BLOCK_ADS, blockAds)
                }
                9 -> {
                    autoPlayer = !autoPlayer
                    setPref(Prefs.AUTO_PLAYER, autoPlayer)
                }
                10 -> startActivity(Intent(this, SettingsActivity::class.java))
                11 -> AlertDialog.Builder(this)
                    .setTitle("Esteban TV")
                    .setMessage("Hecho por: Esteban Ruiz\nVersión ${appVersion()}")
                    .setPositiveButton("OK", null)
                    .show()
            }
            true
        }
        pm.show()
    }

    private fun appVersion(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"
    } catch (e: Exception) {
        "1.0"
    }

    // ------------------------------------------------------------------ navegación

    private fun loadInput(raw: String) {
        val t = raw.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://", true) || t.startsWith("https://", true) -> t
            t.contains(' ') || !t.contains('.') -> {
                val engine = Prefs.engines[prefs.getInt(Prefs.ENGINE, 0).coerceIn(0, Prefs.engines.size - 1)]
                engine.url.replace("%s", Uri.encode(t))
            }
            else -> "https://$t"
        }
        openUrl(url)
    }

    private fun openUrl(url: String) {
        home.visibility = View.GONE
        webView.visibility = View.VISIBLE
        webView.loadUrl(url)
    }

    private fun goHome() {
        if (webView.visibility == View.VISIBLE) {
            clearHistoryOnBlank = true
            webView.loadUrl("about:blank")
        }
        webView.visibility = View.GONE
        home.visibility = View.VISIBLE
        progress.visibility = View.GONE
        currentPageUrl = ""
        pageTitle = ""
        suppressedDomain = ""
        etUrl.setText("")
        hideKeyboard()
        refreshFavs()
        updateFavIcon()
        saveLastUrl() // quedó en el inicio: al reabrir se muestra el inicio
    }

    // ------------------------------------------------------------------ favoritos

    private fun updateFavIcon() {
        val fav = currentPageUrl.isNotEmpty() && favs.contains(currentPageUrl)
        btnFav.setImageResource(if (fav) R.drawable.ic_star else R.drawable.ic_star_border)
    }

    private fun toggleFavorite() {
        val url = currentPageUrl
        if (url.isEmpty()) {
            toast("Abre una página primero")
            return
        }
        if (favs.contains(url)) {
            favs.remove(url)
            toast("Quitado de favoritos")
            updateFavIcon()
        } else {
            showFavDialog(url, pageTitle, null) // antes de guardar se ofrecen nombres
        }
    }

    private fun refreshFavs() {
        favContainer.removeAllViews()
        val cells = ArrayList<View>()
        favs.all().forEach { f ->
            cells.add(makeTile(f.title, f.url, false, { openUrl(f.url) }, { showFavOptions(f) }))
        }
        cells.add(makeTile("Agregar", null, true, { showFavDialog("", "", null) }, null))

        val cols = if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) 5 else 3
        cells.chunked(cols).forEach { rowCells ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            rowCells.forEach { row.addView(it) }
            repeat(cols - rowCells.size) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            favContainer.addView(row)
        }
    }

    /** Mosaico del inicio: círculo con la imagen (favicon) de la web; mientras llega se ve la inicial. */
    private fun makeTile(label: String, url: String?, isAdd: Boolean, onClick: () -> Unit, onLong: (() -> Unit)?): View {
        val accent = attrColor(R.attr.etvAccent)
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(10), dp(4), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
            if (onLong != null) setOnLongClickListener { onLong(); true }
        }
        val box = FrameLayout(this).apply {
            setBackgroundResource(R.drawable.bg_circle_outline)
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
        }
        val letter = TextView(this).apply {
            text = if (isAdd) "+" else label.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
            gravity = Gravity.CENTER
            setTextColor(accent)
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        box.addView(letter)

        if (url != null) {
            val img = ImageView(this).apply {
                layoutParams = FrameLayout.LayoutParams(dp(56), dp(56))
                setPadding(dp(13), dp(13), dp(13), dp(13))
                scaleType = ImageView.ScaleType.FIT_CENTER
                visibility = View.GONE
            }
            box.addView(img)
            val show = { b: Bitmap ->
                img.setImageBitmap(b)
                img.visibility = View.VISIBLE
                letter.visibility = View.GONE
                box.setBackgroundResource(R.drawable.bg_circle_light)
            }
            val hit = favicons.cached(url)
            if (hit != null) show(hit) else favicons.load(url) { b -> if (b != null) show(b) }
        }

        val name = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 12f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        }
        tile.addView(box)
        tile.addView(name)
        return tile
    }

    private fun showFavOptions(f: Fav) {
        AlertDialog.Builder(this)
            .setTitle(f.title)
            .setItems(arrayOf("Editar nombre o dirección", "Eliminar")) { _, which ->
                if (which == 0) showFavDialog(f.url, f.title, f) else confirmDelete(f)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun confirmDelete(f: Fav) {
        AlertDialog.Builder(this)
            .setTitle("Eliminar favorito")
            .setMessage(f.title)
            .setPositiveButton("Eliminar") { _, _ ->
                favs.remove(f.url)
                refreshFavs()
                updateFavIcon()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun normalizeUrl(raw: String): String {
        val t = raw.trim()
        if (t.isEmpty()) return ""
        return if (t.startsWith("http://", true) || t.startsWith("https://", true)) t else "https://$t"
    }

    /**
     * Agregar o editar un favorito. Mientras se escribe la dirección se sugieren nombres
     * (por el dominio y por el título real de la página); tocar uno lo pone en el campo Nombre.
     */
    private fun showFavDialog(startUrl: String, titleHint: String, editing: Fav?) {
        val accent = attrColor(R.attr.etvAccent)
        val dim = attrColor(R.attr.etvTextDim)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        fun field(hintText: String) = EditText(this).apply {
            hint = hintText
            setTextColor(Color.WHITE)
            setHintTextColor(dim)
            isSingleLine = true
            backgroundTintList = ColorStateList.valueOf(accent)
        }

        val url = field("https://ejemplo.com").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(startUrl)
        }
        val name = field("Nombre").apply { if (editing != null) setText(editing.title) }
        val sugLabel = TextView(this).apply {
            text = "Sugerencias de nombre"
            setTextColor(dim)
            textSize = 12f
            setPadding(0, dp(14), 0, dp(6))
        }
        val chipsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chipsScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chipsRow)
        }
        box.addView(url)
        box.addView(name)
        box.addView(sugLabel)
        box.addView(chipsScroll)

        val startNorm = normalizeUrl(startUrl)
        val hintTitles = WebMeta.titleOptions(titleHint)
        var brand = ""
        var titles: List<String> = emptyList()
        var token = 0
        var firstSuggestion = ""

        fun refreshChips() {
            val all = ArrayList<String>()
            (listOf(brand) + titles).forEach { s ->
                if (s.isNotBlank() && all.none { it.equals(s, ignoreCase = true) }) all.add(s)
            }
            firstSuggestion = all.firstOrNull() ?: ""
            name.hint = if (firstSuggestion.isNotEmpty()) firstSuggestion else "Nombre"
            sugLabel.visibility = if (all.isEmpty()) View.GONE else View.VISIBLE
            chipsRow.removeAllViews()
            all.forEach { s ->
                chipsRow.addView(TextView(this).apply {
                    text = s
                    setTextColor(accent)
                    textSize = 13f
                    setBackgroundResource(R.drawable.bg_chip)
                    setPadding(dp(14), dp(7), dp(14), dp(7))
                    isClickable = true
                    setOnClickListener {
                        name.setText(s)
                        name.setSelection(s.length)
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { marginEnd = dp(8) }
                })
            }
        }

        val handler = Handler(Looper.getMainLooper())
        val update = Runnable {
            val u = normalizeUrl(url.text.toString())
            val my = ++token
            brand = if (u.isEmpty()) "" else WebMeta.brandName(u)
            titles = if (u == startNorm) hintTitles else emptyList()
            refreshChips()
            if (u.isNotEmpty() && brand.isNotEmpty() && titles.isEmpty()) {
                WebMeta.fetchTitle(u) { t ->
                    if (my == token && t != null) {
                        titles = WebMeta.titleOptions(t)
                        refreshChips()
                    }
                }
            }
        }
        url.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(update)
                handler.postDelayed(update, 600)
            }
        })
        update.run()

        AlertDialog.Builder(this)
            .setTitle(if (editing != null) "Editar favorito" else "Nuevo favorito")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val u = normalizeUrl(url.text.toString())
                if (u.isEmpty()) {
                    toast("Escribe una dirección")
                    return@setPositiveButton
                }
                val typed = name.text.toString().trim()
                val n = typed.ifEmpty { firstSuggestion.ifEmpty { AdBlocker.host(u).removePrefix("www.") } }
                if (editing != null) {
                    favs.replace(editing.url, Fav(n, u))
                } else if (favs.contains(u)) {
                    toast("Ya está en favoritos")
                } else {
                    favs.add(Fav(n, u))
                }
                refreshFavs()
                updateFavIcon()
            }
            .setNegativeButton("Cancelar", null)
            .setOnDismissListener { handler.removeCallbacks(update); token++ }
            .show()
    }

    // ------------------------------------------------------------------ WebView

    private fun emptyResponse() =
        WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))

    private fun injectScripts(view: WebView?) {
        if (blockAds) view?.evaluateJavascript(AdBlocker.AD_JS, null)
        if (autoPlayer) view?.evaluateJavascript(AdBlocker.VIDEO_HOOK_JS, null)
    }

    private fun isSuppressed(): Boolean {
        val d = suppressedDomain
        if (d.isEmpty()) return false
        return AdBlocker.registrable(AdBlocker.host(currentPageUrl)) == d
    }

    /** En este sitio se deja de ofrecer ExoPlayer (el usuario dijo "No" o el video falló). */
    private fun suppressCurrentSite(reload: Boolean) {
        val h = AdBlocker.host(currentPageUrl)
        if (h.isNotEmpty()) suppressedDomain = AdBlocker.registrable(h)
        sniffCooldownUntil = System.currentTimeMillis() + 3000
        if (reload && webView.visibility == View.VISIBLE) webView.reload()
    }

    /** Ajustes del WebView que dependen de Ajustes de la app. Recarga la página si cambió algo que lo exige. */
    private fun applyWebSettings() {
        val js = prefs.getBoolean(Prefs.JS, true)
        val noImg = prefs.getBoolean(Prefs.NO_IMAGES, false)
        with(webView.settings) {
            javaScriptEnabled = js
            blockNetworkImages = noImg
            textZoom = prefs.getInt(Prefs.TEXT_ZOOM, 100)
            userAgentString = if (desktopMode) desktopUa else defaultUa
        }
        CookieManager.getInstance()
            .setAcceptThirdPartyCookies(webView, prefs.getBoolean(Prefs.THIRD_COOKIES, true))
        val key = "$desktopMode|$js|$noImg"
        if (appliedKey.isNotEmpty() && key != appliedKey && webView.visibility == View.VISIBLE) webView.reload()
        appliedKey = key
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    private fun setupWebView() {
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            allowFileAccess = false
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            // Popups: no se permiten ventanas nuevas
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
        }
        defaultUa = webView.settings.userAgentString
        applyWebSettings()

        webView.addJavascriptInterface(Bridge(), "EstebanBridge")

        webView.webViewClient = object : WebViewClient() {

            // Detección de video: mira cada petición de la página
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url.toString()
                if (blockAds && AdBlocker.isAdUrl(url)) return emptyResponse()

                if (autoPlayer && !isSuppressed() && request.method == "GET" && AdBlocker.isStreamUrl(url)) {
                    val now = System.currentTimeMillis()
                    if (!playerOpen && !promptShowing && now >= sniffCooldownUntil) {
                        val ref = currentPageUrl
                        runOnUiThread { requestPlayer(url, ref) }
                    }
                    // Evita que la página también descargue el stream
                    return emptyResponse()
                }
                return null
            }

            // Bloqueo de redirecciones, popunders y esquemas raros
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest): Boolean {
                val uri = request.url
                val url = uri.toString()
                val scheme = uri.scheme?.lowercase()

                if (scheme != "http" && scheme != "https") {
                    if (request.hasGesture() && (scheme == "tel" || scheme == "mailto")) {
                        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (e: Exception) { }
                    }
                    return true
                }
                if (blockAds) {
                    if (AdBlocker.isAdUrl(url)) return true
                    val sameSite = AdBlocker.registrable(AdBlocker.host(url)) ==
                        AdBlocker.registrable(AdBlocker.host(currentPageUrl))
                    if (request.isForMainFrame && !request.hasGesture() && !request.isRedirect &&
                        currentPageUrl.isNotEmpty() && !sameSite
                    ) return true // popunder: salto a otro dominio sin que el usuario toque nada
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url == null || url == "about:blank") return
                currentPageUrl = url
                if (!etUrl.hasFocus()) etUrl.setText(url)
                updateFavIcon()
                if (blockAds) view?.evaluateJavascript(AdBlocker.AD_JS, null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (url == "about:blank") {
                    if (clearHistoryOnBlank) {
                        view?.clearHistory()
                        clearHistoryOnBlank = false
                    }
                    return
                }
                progress.visibility = View.GONE
                if (url != null) {
                    currentPageUrl = url
                    if (!etUrl.hasFocus()) etUrl.setText(url)
                    saveLastUrl()
                }
                updateFavIcon()
                injectScripts(view)
            }

            // Certificados inválidos: se permite, pero preguntando primero
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler, error: SslError?) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Certificado no válido")
                    .setMessage("Este sitio tiene un problema de seguridad. ¿Continuar de todas formas?")
                    .setPositiveButton("Continuar") { _, _ -> handler.proceed() }
                    .setNegativeButton("Cancelar") { _, _ -> handler.cancel() }
                    .setCancelable(false)
                    .show()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                pageTitle = title.orEmpty()
            }

            // El icono real de la web: se guarda para mostrarlo en el inicio
            override fun onReceivedIcon(view: WebView?, icon: Bitmap?) {
                val u = view?.url ?: return
                if (icon == null || u == "about:blank") return
                favicons.put(u, icon.copy(Bitmap.Config.ARGB_8888, false) ?: icon)
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customCallback = callback
                customContainer.addView(
                    view,
                    FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                )
                customContainer.visibility = View.VISIBLE
                hideSystemBars(true)
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }

            override fun onHideCustomView() = hideCustomView()
        }
    }

    private fun hideCustomView() {
        if (customView == null) return
        customContainer.removeAllViews()
        customContainer.visibility = View.GONE
        customCallback?.onCustomViewHidden()
        customView = null
        customCallback = null
        updateBars()
        applyOrientation()
    }

    /** Puente JS -> Kotlin: recibe fuentes de video detectadas dentro de la página. */
    inner class Bridge {
        @JavascriptInterface
        fun onSource(url: String) {
            if (!autoPlayer || !url.startsWith("http", true)) return
            if (!AdBlocker.isStreamUrl(url) || AdBlocker.isAdUrl(url)) return
            val ref = currentPageUrl
            runOnUiThread {
                if (!isSuppressed() && !playerOpen && !promptShowing &&
                    System.currentTimeMillis() >= sniffCooldownUntil
                ) requestPlayer(url, ref)
            }
        }
    }

    // ------------------------------------------------------------------ reproductor (ExoPlayer)

    /** Antes de abrir ExoPlayer pregunta Sí / No y muestra, en un renglón pequeño, el video que se va a reproducir. */
    private fun requestPlayer(url: String, referer: String) {
        if (playerOpen || promptShowing || isFinishing) return
        if (!askPlayer) {
            openPlayer(url, referer)
            return
        }
        promptShowing = true

        val kind = when {
            AdBlocker.isM3u8(url) -> "HLS"
            AdBlocker.isMpd(url) -> "DASH"
            else -> "MP4"
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), dp(4))
        }
        box.addView(TextView(this).apply {
            text = "Se detectó un video. ¿Reproducirlo con ExoPlayer?"
            setTextColor(Color.WHITE)
            textSize = 15f
        })
        box.addView(TextView(this).apply {
            text = "$kind · $url"
            setTextColor(attrColor(R.attr.etvTextDim))
            textSize = 11f
            maxLines = 1
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.MIDDLE
            setPadding(0, dp(10), 0, 0)
        })

        AlertDialog.Builder(this)
            .setTitle("ExoPlayer se va a ejecutar")
            .setView(box)
            .setCancelable(false)
            .setPositiveButton("Sí") { _, _ -> openPlayer(url, referer) }
            .setNegativeButton("No") { _, _ ->
                toast("Se usará el reproductor de la página")
                suppressCurrentSite(true) // se recarga para que la página reproduzca su propio video
            }
            .setOnDismissListener { promptShowing = false }
            .show()
    }

    private fun openPlayer(url: String, referer: String) {
        if (playerOpen || isFinishing) return
        playerOpen = true

        webView.evaluateJavascript(
            "document.querySelectorAll('video,audio').forEach(function(v){try{v.pause()}catch(e){}})", null
        )
        webView.onPause()

        val headers = HashMap<String, String>()
        if (referer.isNotEmpty()) {
            headers["Referer"] = referer
            val u = Uri.parse(referer)
            if (u.scheme != null && u.host != null) headers["Origin"] = "${u.scheme}://${u.host}"
        }
        CookieManager.getInstance().getCookie(url)?.let { headers["Cookie"] = it }

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(webView.settings.userAgentString)
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(headers)

        val item = MediaItem.Builder().setUri(url).apply {
            when {
                AdBlocker.isM3u8(url) -> setMimeType(MimeTypes.APPLICATION_M3U8)
                AdBlocker.isMpd(url) -> setMimeType(MimeTypes.APPLICATION_MPD)
            }
        }.build()

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build()

        // Resolución máxima elegida en Ajustes (0 = sin límite)
        val maxQ = prefs.getInt(Prefs.MAX_QUALITY, 0)
        if (maxQ > 0) {
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                .setMaxVideoSize(Int.MAX_VALUE, maxQ)
                .build()
        }

        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                toast("No se pudo reproducir este video")
                playerView.post {
                    closePlayer()
                    suppressCurrentSite(true) // que la página intente con su propio reproductor
                }
            }

            override fun onTracksChanged(tracks: Tracks) = updateQualityLabel()
            override fun onVideoSizeChanged(videoSize: VideoSize) = updateQualityLabel()
        })
        playerView.player = p
        p.setMediaItem(item)
        p.prepare()
        p.playWhenReady = true
        player = p

        btnQuality.text = "Auto"
        playerTopBar.visibility = View.VISIBLE
        playerLayer.visibility = View.VISIBLE
        updateBars()
        applyKeepOn()

        // El video arranca en horizontal; con el botón de girar se pasa a vertical y viceversa.
        // Si en Ajustes se eligió "solo vertical" o "bloquear", se respeta esa elección.
        requestedOrientation = when (prefs.getInt(Prefs.ORIENT, 0)) {
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            4 -> ActivityInfo.SCREEN_ORIENTATION_LOCKED
            else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    private fun closePlayer() {
        if (!playerOpen) return
        playerView.player = null
        player?.release()
        player = null
        playerLayer.visibility = View.GONE
        playerOpen = false
        updateBars()
        applyKeepOn()
        applyOrientation()
        webView.onResume()
        sniffCooldownUntil = System.currentTimeMillis() + 3000
    }

    // ---- botón de resolución

    private class QualityOption(val group: TrackGroup, val index: Int, val width: Int, val height: Int, val bitrate: Int)

    private fun hasVideoOverride(p: ExoPlayer) =
        p.trackSelectionParameters.overrides.values.any { it.type == C.TRACK_TYPE_VIDEO }

    /** Texto del botón: "Auto · 720p" mientras elige solo, o "1080p" si el usuario fijó una resolución. */
    private fun updateQualityLabel() {
        val p = player ?: return
        val h = p.videoSize.height
        btnQuality.text = when {
            hasVideoOverride(p) && h > 0 -> "${h}p"
            h > 0 -> "Auto · ${h}p"
            else -> "Auto"
        }
    }

    private fun showQualityDialog() {
        val p = player ?: return
        val all = ArrayList<QualityOption>()
        for (g in p.currentTracks.groups) {
            if (g.type != C.TRACK_TYPE_VIDEO) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                val f = g.getTrackFormat(i)
                if (f.height <= 0) continue
                all.add(QualityOption(g.mediaTrackGroup, i, f.width, f.height, f.bitrate))
            }
        }
        // Una entrada por altura (la de mayor bitrate), de mayor a menor resolución
        val options = all.groupBy { it.height }
            .map { (_, list) -> list.maxByOrNull { it.bitrate }!! }
            .sortedByDescending { it.height }
        if (options.isEmpty()) {
            toast("Aún no se conocen las resoluciones de este video")
            return
        }

        val labels = ArrayList<String>()
        labels.add("Automática")
        options.forEach { o ->
            val tag = when {
                o.height >= 2160 -> " · 4K"
                o.height >= 1440 -> " · 2K"
                o.height >= 1080 -> " · Full HD"
                o.height >= 720 -> " · HD"
                else -> ""
            }
            val rate = if (o.bitrate > 0) " · %.1f Mbps".format(o.bitrate / 1_000_000f) else ""
            labels.add("${o.height}p$tag$rate")
        }

        var checked = 0
        if (hasVideoOverride(p)) {
            val ov = p.trackSelectionParameters.overrides.values.first { it.type == C.TRACK_TYPE_VIDEO }
            val idx = options.indexOfFirst { it.group == ov.mediaTrackGroup && ov.trackIndices.contains(it.index) }
            if (idx >= 0) checked = idx + 1
        }

        AlertDialog.Builder(this)
            .setTitle(if (options.size == 1) "Resolución disponible" else "Resolución")
            .setSingleChoiceItems(labels.toTypedArray(), checked) { d, which ->
                val b = p.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                if (which > 0) {
                    val o = options[which - 1]
                    b.setOverrideForType(TrackSelectionOverride(o.group, o.index))
                }
                p.trackSelectionParameters = b.build()
                updateQualityLabel()
                d.dismiss()
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }
}
