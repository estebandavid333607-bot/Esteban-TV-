package com.estebanruiz.estebantv

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.widget.doAfterTextChanged
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import java.io.ByteArrayInputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var etUrl: EditText
    private lateinit var progress: ProgressBar
    private lateinit var home: View
    private lateinit var btnHome: ImageButton
    private lateinit var btnFav: ImageButton
    private lateinit var btnGoogle: ImageButton
    private lateinit var btnMenu: ImageButton
    private lateinit var favContainer: LinearLayout
    private lateinit var googleCard: View
    private lateinit var dlCard: View
    private lateinit var dlListCard: View
    private lateinit var dls: DownloadsStore
    private lateinit var homeTitle: TextView
    private lateinit var homeFavLabel: TextView
    private lateinit var homeMadeBy: TextView
    private lateinit var playerLayer: View
    private lateinit var customContainer: FrameLayout
    private lateinit var favs: FavoritesStore
    private lateinit var prefs: Prefs
    private lateinit var icons: IconStore
    private lateinit var pc: PlayerController

    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var defaultUa = ""
    private var pageTitle = ""
    private var clearHistoryOnBlank = false
    private var askDialog: AlertDialog? = null
    private val iconRequested = HashSet<String>()
    // Videos a los que el usuario dijo "No" (carpeta/archivo -> hora). Solo esos se reproducen en la página;
    // cualquier otro video nuevo vuelve a preguntar de inmediato.
    private val declinedStreams: MutableMap<String, Long> = ConcurrentHashMap<String, Long>()
    @Volatile private var lastDeclineHost = ""
    @Volatile private var lastDeclineTime = 0L
    private var pill: TextView? = null

    @Volatile private var currentPageUrl = ""
    @Volatile private var sniffCooldownUntil = 0L

    // Protección anti-redirección
    @Volatile private var tapCount = 0
    @Volatile private var lastLinkHref = ""
    @Volatile private var lastLinkTrusted = false
    @Volatile private var lastLinkTime = 0L
    private var lastBlocked = ""
    private var lastBlockedToast = 0L
    private var downX = 0f
    private var downY = 0f
    private var downT = 0L

    private val accent: Int get() = prefs.accent

    private val desktopUa =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private val engines = arrayOf(
        "Google" to "https://www.google.com/search?q=",
        "Bing" to "https://www.bing.com/search?q=",
        "DuckDuckGo" to "https://duckduckgo.com/?q=",
        "Brave" to "https://search.brave.com/search?q="
    )

    private val palette = arrayOf(
        "Verde neón" to 0xFF39FF14.toInt(),
        "Cian" to 0xFF00E5FF.toInt(),
        "Azul" to 0xFF448AFF.toInt(),
        "Violeta" to 0xFFB388FF.toInt(),
        "Magenta" to 0xFFFF2BD6.toInt(),
        "Rojo" to 0xFFFF1744.toInt(),
        "Naranja" to 0xFFFF9100.toInt(),
        "Amarillo" to 0xFFFFEA00.toInt(),
        "Blanco" to 0xFFFFFFFF.toInt()
    )

    private val playerHost = object : PlayerController.Host {
        override fun accent(): Int = prefs.accent
        override fun setOrientation(o: Int) {
            requestedOrientation = o
        }

        override fun onPlayerClosed() {
            hideSystemBars(prefs.fullscreen)
            applyRotation()
            webView.onResume()
            sniffCooldownUntil = System.currentTimeMillis() + 3000
        }

        override fun showDialog(b: AlertDialog.Builder): AlertDialog = showDlg(b)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        favs = FavoritesStore(this)
        prefs = Prefs(this)
        icons = IconStore(this)
        dls = DownloadsStore(this)

        webView = findViewById(R.id.webView)
        etUrl = findViewById(R.id.etUrl)
        progress = findViewById(R.id.progress)
        home = findViewById(R.id.home)
        btnHome = findViewById(R.id.btnHome)
        btnFav = findViewById(R.id.btnFav)
        btnGoogle = findViewById(R.id.btnGoogle)
        btnMenu = findViewById(R.id.btnMenu)
        favContainer = findViewById(R.id.favContainer)
        googleCard = findViewById(R.id.googleCard)
        dlCard = findViewById(R.id.dlCard)
        dlListCard = findViewById(R.id.dlListCard)
        homeTitle = findViewById(R.id.homeTitle)
        homeFavLabel = findViewById(R.id.homeFavLabel)
        homeMadeBy = findViewById(R.id.homeMadeBy)
        playerLayer = findViewById(R.id.playerLayer)
        customContainer = findViewById(R.id.customContainer)

        pc = PlayerController(this, playerLayer, prefs, playerHost)

        setupWebView()
        setupUi()
        showUrlSlogan()
        applyRotation()
        hideSystemBars(prefs.fullscreen)
        applyAccent()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> hideCustomView()
                    pc.isOpen -> if (pc.isLocked) toast("Desbloquea los controles (🔒) para salir") else pc.close()
                    webView.visibility == View.VISIBLE && webView.canGoBack() -> webView.goBack()
                    webView.visibility == View.VISIBLE -> goHome()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        if (savedInstanceState == null) {
            if (prefs.welcome) showWelcome()
            if (prefs.restoreLast && prefs.lastPage.isNotEmpty()) openUrl(prefs.lastPage)
        }
    }

    override fun onPause() {
        super.onPause()
        // Con el reproductor abierto y "segundo plano" activo NO se pausa: sigue sonando (y con pantalla apagada).
        if (!(pc.isOpen && prefs.bgPlay)) pc.pause()
        webView.onPause()
    }

    override fun onStart() {
        super.onStart()
        pc.onAppForeground()
    }

    override fun onStop() {
        pc.onAppBackground()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (!pc.isOpen) webView.onResume()
    }

    override fun onDestroy() {
        pc.release()
        webView.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ interfaz

    private fun setupUi() {
        btnHome.setOnClickListener { goHome() }
        btnGoogle.setOnClickListener { openUrl("https://www.google.com") }
        googleCard.setOnClickListener { openUrl("https://www.google.com") }
        btnMenu.setOnClickListener { showMenu(it) }
        btnFav.setOnClickListener { toggleFavorite() }

        dlCard.setOnClickListener { showDownloader() }
        dlListCard.setOnClickListener { showDownloads() }

        // La barra de arriba solo muestra el eslogan: no se puede tocar, editar ni ver la URL.
        etUrl.isFocusable = false
        etUrl.isFocusableInTouchMode = false
        etUrl.isCursorVisible = false
        etUrl.isLongClickable = false
        etUrl.setOnClickListener { }
    }

    /** Muestra el nombre/eslogan de la app en la barra en vez de la URL real. */
    private fun showUrlSlogan() {
        etUrl.setText(if (currentPageUrl.isEmpty()) getString(R.string.app_name_caps) else getString(R.string.url_slogan))
    }

    /** Aplica el color (paleta) elegido a toda la interfaz. */
    private fun applyAccent() {
        val a = accent
        progress.progressTintList = ColorStateList.valueOf(a)
        listOf(btnHome, btnFav, btnMenu).forEach { it.setColorFilter(a) }
        etUrl.background = Ui.outline(Color.parseColor("#0F0F0F"), a, dp(1), dp(22).toFloat())
        googleCard.background = Ui.outline(Color.parseColor("#0A0A0A"), a, dp(2), dp(18).toFloat())
        dlCard.background = Ui.outline(Color.parseColor("#0A0A0A"), a, dp(2), dp(18).toFloat())
        dlListCard.background = Ui.outline(Color.parseColor("#0A0A0A"), a, dp(2), dp(18).toFloat())
        listOf(R.id.dlIcon, R.id.dlListIcon).forEach { id ->
            val iv = findViewById<ImageView>(id)
            iv.background = Ui.outline(Color.parseColor("#0A0A0A"), a, dp(2), 0f, oval = true)
            iv.setColorFilter(a)
        }
        homeTitle.setTextColor(a)
        homeTitle.setShadowLayer(20f, 0f, 0f, a)
        homeFavLabel.setTextColor(a)
        homeMadeBy.setTextColor(ColorUtils.blendARGB(a, Color.BLACK, 0.45f))
        pc.applyAccent()
        refreshFavs()
    }

    private fun applyRotation() {
        requestedOrientation = when (prefs.rotation) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            3 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    private fun applyWebSettings() {
        with(webView.settings) {
            textZoom = prefs.textZoom
            blockNetworkImage = !prefs.loadImages
            userAgentString = if (prefs.desktopMode) desktopUa else defaultUa
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, prefs.thirdPartyCookies)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(etUrl.windowToken, 0)
        etUrl.clearFocus()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun showDlg(b: AlertDialog.Builder): AlertDialog {
        val d = b.create()
        d.show()
        val a = accent
        d.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(a)
        d.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(a)
        d.getButton(AlertDialog.BUTTON_NEUTRAL)?.setTextColor(a)
        return d
    }

    private fun showWelcome() {
        val card = TextView(this).apply {
            text = "👋 ¡Bienvenido a Esteban TV!\nApp hecha por Esteban Ruiz"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(24), dp(16), dp(24), dp(16))
            background = Ui.outline(Color.parseColor("#F2000000"), accent, dp(2), dp(18).toFloat())
            elevation = dp(8).toFloat()
            alpha = 0f
        }
        val content = findViewById<ViewGroup>(android.R.id.content)
        content.addView(
            card,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
        )
        // 300 ms entrada + 1400 ms visible + 300 ms salida ≈ 2 s
        card.animate().alpha(1f).setDuration(300).withEndAction {
            card.animate().alpha(0f).setStartDelay(1400).setDuration(300).withEndAction {
                (card.parent as? ViewGroup)?.removeView(card)
            }.start()
        }.start()
    }

    // ------------------------------------------------------------------ menú ⋮

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        val m = pm.menu
        val onPage = webView.visibility == View.VISIBLE && currentPageUrl.isNotEmpty()
        m.add(0, 1, 0, "Recargar")
        m.add(0, 2, 1, "Modo escritorio").apply { isCheckable = true; isChecked = prefs.desktopMode }
        m.add(0, 11, 2, "Buscar / ir a una dirección")
        if (onPage) {
            m.add(0, 3, 2, "Copiar enlace")
            m.add(0, 4, 3, "Compartir enlace")
            m.add(0, 5, 4, "Abrir en otro navegador")
        }
        if (lastBlocked.isNotEmpty()) m.add(0, 6, 5, "Permitir última redirección bloqueada")
        m.add(0, 10, 7, "Descargar video")
        m.add(0, 12, 8, "Mis descargas")
        m.add(0, 8, 9, "Ajustes")
        m.add(0, 9, 10, "Acerca de")

        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> if (webView.visibility == View.VISIBLE) webView.reload()
                2 -> setDesktop(!prefs.desktopMode)
                3 -> {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("enlace", currentPageUrl))
                    toast("Enlace copiado")
                }
                4 -> startActivity(
                    Intent.createChooser(
                        Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, currentPageUrl),
                        "Compartir enlace"
                    )
                )
                5 -> try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(currentPageUrl)))
                } catch (e: Exception) {
                    toast("No hay otro navegador")
                }
                6 -> {
                    val u = lastBlocked
                    lastBlocked = ""
                    if (u.isNotEmpty()) openUrl(u)
                }
                8 -> showSettings()
                9 -> showAbout()
                10 -> showDownloader()
                11 -> showGoTo()
                12 -> showDownloads()
            }
            true
        }
        pm.show()
    }

    private fun setDesktop(v: Boolean) {
        prefs.desktopMode = v
        webView.settings.userAgentString = if (v) desktopUa else defaultUa
        if (webView.visibility == View.VISIBLE) webView.reload()
    }

    private fun showAbout() {
        val ver = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Esteban TV")
                .setMessage("App hecha por Esteban Ruiz\nVersión $ver")
                .setPositiveButton("OK", null)
        )
    }

    // ------------------------------------------------------------------ ajustes

    private fun showSettings() {
        val a = accent
        val dim = Color.parseColor("#8FBF86")
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(8))
        }
        val scroll = ScrollView(this)
        scroll.addView(col)

        fun section(t: String) {
            val tv = TextView(this)
            tv.text = t
            tv.setTextColor(a)
            tv.textSize = 12f
            tv.letterSpacing = 0.12f
            tv.setTypeface(tv.typeface, Typeface.BOLD)
            tv.setPadding(0, dp(18), 0, dp(4))
            col.addView(tv)
        }

        fun switchRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(8), 0, dp(8))
            val texts = LinearLayout(this)
            texts.orientation = LinearLayout.VERTICAL
            texts.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            val t = TextView(this)
            t.text = title
            t.setTextColor(Color.WHITE)
            t.textSize = 15f
            texts.addView(t)
            if (sub != null) {
                val s = TextView(this)
                s.text = sub
                s.setTextColor(dim)
                s.textSize = 12f
                texts.addView(s)
            }
            val sw = SwitchCompat(this)
            sw.isChecked = checked
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            sw.thumbTintList = ColorStateList(states, intArrayOf(a, Color.GRAY))
            sw.trackTintList = ColorStateList(
                states, intArrayOf(ColorUtils.setAlphaComponent(a, 110), Color.parseColor("#33FFFFFF"))
            )
            sw.setOnCheckedChangeListener { _, v -> onChange(v) }
            row.setOnClickListener { sw.toggle() }
            row.addView(texts)
            row.addView(sw)
            col.addView(row)
        }

        fun choiceRow(title: String, options: Array<String>, current: () -> Int, onPick: (Int) -> Unit) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(0, dp(10), 0, dp(10))
            row.isClickable = true
            val t = TextView(this)
            t.text = title
            t.setTextColor(Color.WHITE)
            t.textSize = 15f
            val v = TextView(this)
            v.text = options[current().coerceIn(0, options.size - 1)]
            v.setTextColor(a)
            v.textSize = 13f
            row.addView(t)
            row.addView(v)
            row.setOnClickListener {
                showDlg(
                    AlertDialog.Builder(this)
                        .setTitle(title)
                        .setSingleChoiceItems(options, current()) { d, w ->
                            onPick(w)
                            v.text = options[w]
                            d.dismiss()
                        }
                        .setNegativeButton("Cancelar", null)
                )
            }
            col.addView(row)
        }

        fun actionRow(title: String, sub: String?, onClick: () -> Unit) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(0, dp(10), 0, dp(10))
            row.isClickable = true
            val t = TextView(this)
            t.text = title
            t.setTextColor(Color.WHITE)
            t.textSize = 15f
            row.addView(t)
            if (sub != null) {
                val s = TextView(this)
                s.text = sub
                s.setTextColor(dim)
                s.textSize = 12f
                row.addView(s)
            }
            row.setOnClickListener { onClick() }
            col.addView(row)
        }

        // ---- Navegación
        section("NAVEGACIÓN")
        choiceRow("Motor de búsqueda", engines.map { it.first }.toTypedArray(),
            { prefs.searchEngine }, { prefs.searchEngine = it })
        choiceRow("Protección anti-redirección",
            arrayOf("Desactivada", "Solo tras 2 toques (recomendado)", "Nunca redirigir a otras webs"),
            { prefs.redirMode }, { prefs.redirMode = it })
        switchRow("Bloquear popups y anuncios", "Filtra dominios de publicidad y ventanas emergentes",
            prefs.blockAds) { prefs.blockAds = it }
        switchRow("Modo escritorio", "Pide la versión de PC de las webs", prefs.desktopMode) { setDesktop(it) }
        val zoomVals = intArrayOf(85, 100, 125, 150)
        choiceRow("Tamaño del texto", arrayOf("Pequeño (85%)", "Normal (100%)", "Grande (125%)", "Muy grande (150%)"),
            { zoomVals.indexOf(prefs.textZoom).coerceAtLeast(1) }) {
            prefs.textZoom = zoomVals[it]
            webView.settings.textZoom = zoomVals[it]
        }
        switchRow("Cargar imágenes", "Apágalo para ahorrar datos", prefs.loadImages) {
            prefs.loadImages = it
            webView.settings.blockNetworkImage = !it
        }
        switchRow("Cookies de terceros", "Algunas webs las necesitan para iniciar sesión",
            prefs.thirdPartyCookies) {
            prefs.thirdPartyCookies = it
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, it)
        }
        switchRow("Recordar la última página", "Al abrir la app vuelve a donde estabas", prefs.restoreLast) {
            prefs.restoreLast = it
            if (!it) prefs.lastPage = ""
        }
        switchRow("Pantalla completa", "Oculta las barras del sistema", prefs.fullscreen) {
            prefs.fullscreen = it
            hideSystemBars(it)
        }

        // ---- Reproductor
        section("REPRODUCTOR (EXOPLAYER)")
        switchRow("Abrir videos en ExoPlayer", "Detecta streams .m3u8, .mpd y .mp4", prefs.autoPlayer) {
            prefs.autoPlayer = it
        }
        switchRow("Preguntar antes de abrir", "Muestra Sí / No con el nombre del video", prefs.confirmExo) {
            prefs.confirmExo = it
        }
        val qVals = intArrayOf(0, 1080, 720, 480, 360)
        choiceRow("Resolución máxima", arrayOf("Sin límite (Auto)", "1080p", "720p", "480p", "360p"),
            { qVals.indexOf(prefs.maxQuality).coerceAtLeast(0) }) { prefs.maxQuality = qVals[it] }

        // ---- Apariencia
        section("APARIENCIA")
        choiceRow("Paleta de colores", palette.map { it.first }.toTypedArray(),
            { palette.indexOfFirst { it.second == prefs.accent }.coerceAtLeast(0) }) {
            prefs.accent = palette[it].second
            applyAccent()
        }
        choiceRow("Rotación de pantalla",
            arrayOf("Según el sistema", "Automática (siempre gira)", "Solo vertical", "Solo horizontal"),
            { prefs.rotation }) {
            prefs.rotation = it
            applyRotation()
        }
        switchRow("Mensaje de bienvenida", "Aparece 2 segundos al abrir la app", prefs.welcome) { prefs.welcome = it }

        // ---- Datos
        section("DATOS")
        actionRow("Borrar caché", "Libera espacio de las páginas guardadas") {
            webView.clearCache(true)
            toast("Caché borrada")
        }
        actionRow("Borrar cookies y datos de sitios", "Cierra tus sesiones en las webs") {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            WebStorage.getInstance().deleteAllData()
            toast("Cookies y datos borrados")
        }
        actionRow("Restablecer ajustes", "Vuelve a los valores originales (no borra favoritos)") {
            showDlg(
                AlertDialog.Builder(this)
                    .setTitle("Restablecer ajustes")
                    .setMessage("¿Volver a los ajustes originales?")
                    .setPositiveButton("Restablecer") { _, _ ->
                        prefs.reset()
                        clearDeclined()
                        applyWebSettings()
                        applyRotation()
                        hideSystemBars(prefs.fullscreen)
                        applyAccent()
                        toast("Ajustes restablecidos")
                    }
                    .setNegativeButton("Cancelar", null)
            )
        }

        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Ajustes")
                .setView(scroll)
                .setPositiveButton("Listo", null)
        )
    }

    // ------------------------------------------------------------------ navegación

    private fun loadInput(raw: String) {
        val t = raw.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://", true) || t.startsWith("https://", true) -> t
            t.contains(' ') || !t.contains('.') ->
                engines[prefs.searchEngine.coerceIn(0, engines.size - 1)].second + Uri.encode(t)
            else -> "https://$t"
        }
        openUrl(url)
    }

    private fun openUrl(url: String) {
        tapCount = 0
        home.visibility = View.GONE
        webView.visibility = View.VISIBLE
        webView.loadUrl(url)
    }

    private fun goHome() {
        if (webView.visibility == View.VISIBLE) {
            clearHistoryOnBlank = true
            webView.loadUrl("about:blank")
        }
        webView.visibility = View.GONE
        home.visibility = View.VISIBLE
        progress.visibility = View.GONE
        currentPageUrl = ""
        pageTitle = ""
        clearDeclined()
        prefs.lastPage = ""
        etUrl.setText("")
        showUrlSlogan()
        hideKeyboard()
        refreshFavs()
        updateFavIcon()
    }

    // ------------------------------------------------------------------ favoritos

    private fun updateFavIcon() {
        val fav = currentPageUrl.isNotEmpty() && favs.contains(currentPageUrl)
        btnFav.setImageResource(if (fav) R.drawable.ic_star else R.drawable.ic_star_border)
    }

    private fun toggleFavorite() {
        val url = currentPageUrl
        if (url.isEmpty()) {
            toast("Abre una página primero")
            return
        }
        if (favs.contains(url)) {
            favs.remove(url)
            toast("Quitado de favoritos")
            updateFavIcon()
        } else {
            askNameAndSave(cleanTitle(pageTitle).ifEmpty { suggestName(url) }, url)
        }
    }

    /** Antes de guardar, deja elegir el nombre (con una sugerencia). */
    private fun askNameAndSave(suggested: String, url: String) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val name = styledEdit("Nombre", suggested)
        name.selectAll()
        box.addView(name)
        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Guardar en favoritos")
                .setMessage(AdBlocker.host(url).removePrefix("www."))
                .setView(box)
                .setPositiveButton("Guardar") { _, _ ->
                    val n = name.text.toString().trim().ifEmpty { suggestName(url) }
                    favs.add(Fav(n, url))
                    icons.ensure(url) { refreshFavs() }
                    toast("Agregado a favoritos")
                    updateFavIcon()
                    refreshFavs()
                }
                .setNegativeButton("Cancelar", null)
        )
    }

    private fun styledEdit(hint: String, text: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(text)
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Color.parseColor("#8FBF86"))
        e.isSingleLine = true
        return e
    }

    /** "Mi página - Sitio | Otra cosa" -> "Mi página". */
    private fun cleanTitle(t: String): String {
        val first = t.split(" - ", " | ", " – ", " · ").map { it.trim() }.firstOrNull { it.length >= 2 } ?: return ""
        return if (first.length > 30) first.take(30).trim() else first
    }

    /** youtube.com -> "Youtube". */
    private fun suggestName(u: String): String {
        val t = u.trim()
        if (t.isEmpty()) return ""
        val h = AdBlocker.host(if (t.startsWith("http", true)) t else "https://$t").removePrefix("www.")
        if (h.isEmpty()) return ""
        return AdBlocker.registrable(h).substringBefore('.').replaceFirstChar { it.uppercaseChar() }
    }

    private fun refreshFavs() {
        if (!::favContainer.isInitialized) return
        favContainer.removeAllViews()
        val cells = ArrayList<View>()
        favs.all().forEach { f ->
            val icon = icons.get(f.url)
            if (icon == null && iconRequested.add(f.url)) {
                icons.ensure(f.url) { if (home.visibility == View.VISIBLE) refreshFavs() }
            }
            val letter = f.title.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
            cells.add(makeTile(f.title, icon, letter, { openUrl(f.url) }, { favMenu(f) }))
        }
        cells.add(makeTile("Agregar", null, "+", { showAddDialog() }, null))

        cells.chunked(3).forEach { rowCells ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            rowCells.forEach { row.addView(it) }
            repeat(3 - rowCells.size) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            favContainer.addView(row)
        }
    }

    private fun makeTile(
        label: String, icon: Bitmap?, letter: String, onClick: () -> Unit, onLong: (() -> Unit)?
    ): View {
        val a = accent
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(10), dp(4), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
            if (onLong != null) setOnLongClickListener { onLong(); true }
        }
        val circle = FrameLayout(this)
        circle.background = Ui.outline(
            if (icon != null) Color.WHITE else Color.parseColor("#0A0A0A"), a, dp(2), 0f, oval = true
        )
        circle.outlineProvider = ViewOutlineProvider.BACKGROUND
        circle.clipToOutline = true
        circle.layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
        if (icon != null) {
            val img = ImageView(this)
            img.setImageBitmap(icon)
            img.scaleType = ImageView.ScaleType.FIT_CENTER
            circle.addView(img, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER))
        } else {
            val tv = TextView(this)
            tv.text = letter
            tv.gravity = Gravity.CENTER
            tv.setTextColor(a)
            tv.textSize = 22f
            tv.setTypeface(tv.typeface, Typeface.BOLD)
            circle.addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        val name = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 12f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        }
        tile.addView(circle)
        tile.addView(name)
        return tile
    }

    private fun favMenu(f: Fav) {
        showDlg(
            AlertDialog.Builder(this)
                .setTitle(f.title)
                .setItems(arrayOf("Renombrar", "Eliminar")) { _, which ->
                    if (which == 0) renameFav(f) else confirmDelete(f)
                }
                .setNegativeButton("Cancelar", null)
        )
    }

    private fun renameFav(f: Fav) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val name = styledEdit("Nombre", f.title)
        name.selectAll()
        box.addView(name)
        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Renombrar")
                .setView(box)
                .setPositiveButton("Guardar") { _, _ ->
                    val n = name.text.toString().trim()
                    if (n.isNotEmpty()) {
                        favs.rename(f.url, n)
                        refreshFavs()
                    }
                }
                .setNegativeButton("Cancelar", null)
        )
    }

    private fun confirmDelete(f: Fav) {
        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Eliminar favorito")
                .setMessage(f.title)
                .setPositiveButton("Eliminar") { _, _ ->
                    favs.remove(f.url)
                    refreshFavs()
                    updateFavIcon()
                }
                .setNegativeButton("Cancelar", null)
        )
    }

    private fun showAddDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val url = styledEdit("https://ejemplo.com", "")
        url.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        val name = styledEdit("Nombre (te sugerimos uno, puedes cambiarlo)", "")
        box.addView(url)
        box.addView(name)

        var programmatic = false
        var edited = false
        name.doAfterTextChanged { if (!programmatic) edited = true }
        url.doAfterTextChanged {
            if (!edited) {
                programmatic = true
                name.setText(suggestName(it?.toString().orEmpty()))
                programmatic = false
            }
        }

        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Nueva página")
                .setView(box)
                .setPositiveButton("Guardar") { _, _ ->
                    var u = url.text.toString().trim()
                    if (u.isEmpty()) return@setPositiveButton
                    if (!u.startsWith("http", true)) u = "https://$u"
                    val n = name.text.toString().trim().ifEmpty { suggestName(u) }
                    favs.add(Fav(n, u))
                    icons.ensure(u) { refreshFavs() }
                    refreshFavs()
                }
                .setNegativeButton("Cancelar", null)
        )
    }

    // ------------------------------------------------------------------ WebView

    private fun emptyResponse() =
        WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))

    private fun injectScripts(view: WebView?) {
        if (prefs.blockAds) view?.evaluateJavascript(AdBlocker.AD_JS, null)
        if (prefs.redirMode > 0) view?.evaluateJavascript(AdBlocker.LINK_GUARD_JS, null)
        if (prefs.autoPlayer) view?.evaluateJavascript(AdBlocker.VIDEO_HOOK_JS, null)
    }

    private fun clearDeclined() {
        declinedStreams.clear()
        lastDeclineHost = ""
    }

    /** ¿El usuario ya dijo "No" a este video? Solo ese (o sus listas internas) se deja pasar a la página. */
    private fun isDeclined(url: String): Boolean {
        if (declinedStreams.isEmpty()) return false
        val plain = url.substringBefore('?').substringBefore('#')
        if (declinedStreams.keys.any { plain.startsWith(it) }) return true
        val host = AdBlocker.registrable(AdBlocker.host(url))
        return host.isNotEmpty() && host == lastDeclineHost && System.currentTimeMillis() - lastDeclineTime < 15000
    }

    /** Mensaje flotante propio (sin el ícono de Android del Toast). */
    private fun showPill(msg: String) {
        pill?.let { (it.parent as? ViewGroup)?.removeView(it) }
        val tv = TextView(this).apply {
            text = msg
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(20), dp(10), dp(20), dp(10))
            background = Ui.outline(Color.parseColor("#F2000000"), accent, dp(1), dp(22).toFloat())
            elevation = dp(8).toFloat()
            alpha = 0f
        }
        pill = tv
        val content = findViewById<ViewGroup>(android.R.id.content)
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        lp.bottomMargin = dp(56)
        content.addView(tv, lp)
        tv.animate().alpha(1f).setDuration(180).withEndAction {
            tv.animate().alpha(0f).setStartDelay(1400).setDuration(300).withEndAction {
                (tv.parent as? ViewGroup)?.removeView(tv)
                if (pill === tv) pill = null
            }.start()
        }.start()
    }

    /**
     * ¿Se permite que la página actual navegue a OTRA web?
     *  - Desde buscadores siempre.
     *  - Si el usuario tocó un enlace visible y real hacia ese destino.
     *  - Modo "2 toques": solo tras 2 toques o más en la página.
     *  - Modo "nunca": no (salvo los casos anteriores).
     */
    private fun crossSiteAllowed(url: String, request: WebResourceRequest): Boolean {
        val mode = prefs.redirMode
        if (mode == 0) return true
        if (AdBlocker.isSearchHub(AdBlocker.host(currentPageUrl))) return true
        val fresh = System.currentTimeMillis() - lastLinkTime < 2500
        val sameTarget = AdBlocker.registrable(AdBlocker.host(lastLinkHref)) ==
            AdBlocker.registrable(AdBlocker.host(url))
        if (fresh && lastLinkTrusted && sameTarget && request.hasGesture()) return true
        if (mode == 1 && request.hasGesture() && tapCount >= 2) return true
        return false
    }

    private fun blockedRedirect(url: String) {
        lastBlocked = url
        val now = System.currentTimeMillis()
        if (now - lastBlockedToast > 1500) {
            lastBlockedToast = now
            runOnUiThread { showPill("Redirección bloqueada  ✔") }
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface", "ClickableViewAccessibility")
    private fun setupWebView() {
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            allowFileAccess = false
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            // Popups: no se permiten ventanas nuevas
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
        }
        defaultUa = webView.settings.userAgentString
        applyWebSettings()

        webView.addJavascriptInterface(Bridge(), "EstebanBridge")

        // Cuenta los toques reales del usuario en la página (para la protección anti-redirección)
        webView.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x
                    downY = ev.y
                    downT = ev.eventTime
                }
                MotionEvent.ACTION_UP -> {
                    if (abs(ev.x - downX) < dp(12) && abs(ev.y - downY) < dp(12) && ev.eventTime - downT < 500) {
                        tapCount++
                    }
                }
            }
            false
        }

        webView.webViewClient = object : WebViewClient() {

            // Detección de video: mira cada petición de la página
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url.toString()
                if (prefs.blockAds && AdBlocker.isAdUrl(url)) return emptyResponse()

                if (prefs.autoPlayer && request.method == "GET" && AdBlocker.isStreamUrl(url) && !isDeclined(url)) {
                    if (!pc.isOpen && askDialog == null && System.currentTimeMillis() >= sniffCooldownUntil) {
                        val ref = currentPageUrl
                        runOnUiThread { offerPlayer(url, ref) }
                    }
                    // Evita que la página también descargue el stream
                    return emptyResponse()
                }
                return null
            }

            // Bloqueo de redirecciones, popunders y esquemas raros
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest): Boolean {
                val uri = request.url
                val url = uri.toString()
                val scheme = uri.scheme?.lowercase()

                if (scheme != "http" && scheme != "https") {
                    if (request.hasGesture() && (scheme == "tel" || scheme == "mailto")) {
                        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (e: Exception) { }
                    }
                    return true
                }
                if (prefs.blockAds && AdBlocker.isAdUrl(url)) return true

                if (request.isForMainFrame && !request.isRedirect && currentPageUrl.isNotEmpty()) {
                    val cross = AdBlocker.registrable(AdBlocker.host(url)) !=
                        AdBlocker.registrable(AdBlocker.host(currentPageUrl))
                    if (cross) {
                        if (!crossSiteAllowed(url, request)) {
                            blockedRedirect(url)
                            return true
                        }
                        tapCount = 0
                    }
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url == null || url == "about:blank") return
                if (url != currentPageUrl) clearDeclined()
                currentPageUrl = url
                pageTitle = ""
                if (!etUrl.hasFocus()) showUrlSlogan()
                updateFavIcon()
                if (prefs.blockAds) view?.evaluateJavascript(AdBlocker.AD_JS, null)
                if (prefs.redirMode > 0) view?.evaluateJavascript(AdBlocker.LINK_GUARD_JS, null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (url == "about:blank") {
                    if (clearHistoryOnBlank) {
                        view?.clearHistory()
                        clearHistoryOnBlank = false
                    }
                    return
                }
                progress.visibility = View.GONE
                if (url != null) {
                    currentPageUrl = url
                    if (!etUrl.hasFocus()) showUrlSlogan()
                    if (prefs.restoreLast && url.startsWith("http")) prefs.lastPage = url
                }
                updateFavIcon()
                injectScripts(view)
            }

            // Certificados inválidos: se permite, pero preguntando primero
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler, error: SslError?) {
                showDlg(
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Certificado no válido")
                        .setMessage("Este sitio tiene un problema de seguridad. ¿Continuar de todas formas?")
                        .setPositiveButton("Continuar") { _, _ -> handler.proceed() }
                        .setNegativeButton("Cancelar") { _, _ -> handler.cancel() }
                        .setCancelable(false)
                )
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                pageTitle = title.orEmpty()
            }

            // Logotipo de la web: se guarda para mostrarlo en favoritos
            override fun onReceivedIcon(view: WebView?, icon: Bitmap?) {
                if (icon != null && currentPageUrl.isNotEmpty()) icons.save(currentPageUrl, icon)
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customCallback = callback
                customContainer.addView(
                    view,
                    FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                )
                customContainer.visibility = View.VISIBLE
                hideSystemBars(true)
                if (prefs.rotation != 2) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }

            override fun onHideCustomView() = hideCustomView()
        }
    }

    private fun hideCustomView() {
        if (customView == null) return
        customContainer.removeAllViews()
        customContainer.visibility = View.GONE
        customCallback?.onCustomViewHidden()
        customView = null
        customCallback = null
        hideSystemBars(prefs.fullscreen)
        applyRotation()
    }

    /** Puente JS -> Kotlin: fuentes de video y clics en enlaces detectados dentro de la página. */
    inner class Bridge {
        @JavascriptInterface
        fun onSource(url: String) {
            if (!prefs.autoPlayer || !url.startsWith("http", true)) return
            if (!AdBlocker.isStreamUrl(url) || AdBlocker.isAdUrl(url) || isDeclined(url)) return
            val ref = currentPageUrl
            runOnUiThread {
                if (!pc.isOpen && askDialog == null && System.currentTimeMillis() >= sniffCooldownUntil) {
                    offerPlayer(url, ref)
                }
            }
        }

        @JavascriptInterface
        fun onLinkClick(href: String, trusted: Boolean) {
            lastLinkHref = href
            lastLinkTrusted = trusted
            lastLinkTime = System.currentTimeMillis()
        }
    }

    // ------------------------------------------------------------------ reproductor (ExoPlayer)

    /** Nombre corto del video: título de la página, o el nombre del archivo, o el sitio. */
    private fun videoName(url: String): String {
        val t = cleanTitle(pageTitle)
        if (t.isNotEmpty()) return t
        val seg = try { Uri.parse(url).lastPathSegment.orEmpty() } catch (e: Exception) { "" }
        val base = Uri.decode(seg).substringBeforeLast('.').replace('_', ' ').replace('-', ' ').trim()
        val generic = setOf("index", "master", "playlist", "manifest", "stream", "video", "chunklist", "main", "live", "hls")
        if (base.length > 3 && base.lowercase() !in generic) return base.take(40)
        return AdBlocker.host(url).removePrefix("www.")
    }

    // ------------------------------------------------------------------ descargas

    /** Una descarga en marcha (para la barra, el porcentaje y la velocidad). */
    private class ActiveDl(val name: String, val progress: VideoDownloader.Progress, val cancel: AtomicBoolean) {
        var lastBytes = 0L
        var lastTime = System.currentTimeMillis()
        var speed = 0.0   // bytes por segundo, suavizado
    }

    private val active = ArrayList<ActiveDl>()
    private val ui = Handler(Looper.getMainLooper())
    private var tickRunning = false
    private var progressRefresh: (() -> Unit)? = null
    private var listRefresh: (() -> Unit)? = null
    private var pendingDownload: Triple<Quality, String, String>? = null

    /** Cada medio segundo calcula la velocidad, avisa cuando una descarga termina y refresca las ventanas. */
    private val ticker = object : Runnable {
        override fun run() {
            val iter = active.iterator()
            while (iter.hasNext()) {
                val d = iter.next()
                val now = System.currentTimeMillis()
                val dt = now - d.lastTime
                if (dt >= 400) {
                    val inst = (d.progress.bytes - d.lastBytes) * 1000.0 / dt
                    d.speed = if (d.speed <= 0.0) inst else d.speed * 0.6 + inst * 0.4
                    d.lastBytes = d.progress.bytes
                    d.lastTime = now
                }
                if (d.progress.done) {
                    iter.remove()
                    finishDownload(d)
                }
            }
            progressRefresh?.invoke()
            listRefresh?.invoke()
            if (active.isNotEmpty()) ui.postDelayed(this, 500) else tickRunning = false
        }
    }

    private fun startTick() {
        if (!tickRunning) {
            tickRunning = true
            ui.post(ticker)
        }
    }

    private fun finishDownload(d: ActiveDl) {
        val p = d.progress
        val err = p.error
        val u = p.outputUri
        if (err != null || u == null) {
            toast("✖ " + (err ?: "No se pudo guardar el video"))
            return
        }
        dls.add(DlItem(p.outputName.ifEmpty { d.name }, u, p.mime, p.bytes, System.currentTimeMillis()))
        toast("Descarga completa ✔  Guardado en Descargas/EstebanTV")
    }

    private fun fmtSize(b: Long): String {
        val kb = b / 1024.0
        val mb = kb / 1024.0
        return when {
            b < 1024 -> "$b B"
            kb < 1024 -> String.format("%.0f KB", kb)
            mb < 1024 -> String.format("%.1f MB", mb)
            else -> String.format("%.2f GB", mb / 1024.0)
        }
    }

    private fun fmtSpeed(bps: Double): String = fmtSize(bps.toLong()) + "/s"

    private fun fmtDuration(sec: Double): String {
        if (sec <= 0) return ""
        val s = sec.toInt()
        val h = s / 3600; val m = (s % 3600) / 60; val ss = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, ss) else String.format("%d:%02d", m, ss)
    }

    private fun copyText(label: String, text: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
    }

    /** Enlace http(s) que haya en el portapapeles (o vacío). */
    private fun clipUrl(): String {
        return try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            val t = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this)?.toString().orEmpty().trim() else ""
            if (t.startsWith("http", true)) t else ""
        } catch (e: Exception) {
            ""
        }
    }

    /** Descarga rápida desde la ventana de ExoPlayer: usa MediaProbe para saber si hay varias calidades. */
    private fun downloadVideo(url: String) {
        val askedRef = currentPageUrl
        toast("Analizando video…")
        Thread {
            val qualities = try { MediaProbe.probe(url, askedRef) } catch (e: Exception) { emptyList() }
            runOnUiThread {
                if (qualities.size <= 1) {
                    val q = qualities.firstOrNull() ?: Quality("Original", 0, 0, 0, Quality.Kind.PROGRESSIVE, url, 0.0, false)
                    startDownload(q, askedRef, videoName(url))
                } else {
                    showQualityPicker(qualities, askedRef, videoName(url))
                }
            }
        }.start()
    }

    /** Pantalla "Descargar video": pega un enlace, se analizan las calidades y se elige una. */
    private fun showDownloader() {
        val a = accent
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(8), dp(24), dp(4))

        val info = TextView(this)
        info.text = "Pega el enlace del video (.mp4, .m3u8 o .mpd). Se guarda en Descargas/EstebanTV de tu celular."
        info.setTextColor(Color.parseColor("#8FBF86"))
        info.textSize = 12f
        box.addView(info)

        val input = EditText(this)
        input.hint = "https://ejemplo.com/video.m3u8"
        input.setTextColor(Color.WHITE)
        input.setHintTextColor(Color.parseColor("#8FBF86"))
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        input.isSingleLine = true
        input.setPadding(0, dp(10), 0, dp(6))
        val fromClip = clipUrl()
        if (fromClip.isNotEmpty()) {
            input.setText(fromClip)
            input.setSelection(fromClip.length)
        }
        box.addView(input)

        val paste = TextView(this)
        paste.text = "📋  Pegar enlace copiado"
        paste.setTextColor(a)
        paste.textSize = 13f
        paste.setTypeface(paste.typeface, Typeface.BOLD)
        paste.setPadding(0, dp(8), dp(12), dp(8))
        paste.isClickable = true
        paste.setOnClickListener {
            val c = clipUrl()
            if (c.isEmpty()) {
                toast("No hay ningún enlace copiado")
            } else {
                input.setText(c)
                input.setSelection(c.length)
            }
        }
        box.addView(paste)

        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Descargar video")
                .setView(box)
                .setPositiveButton("Analizar") { _, _ -> analyzeLink(input.text.toString().trim()) }
                .setNegativeButton("Cancelar", null)
        )
    }

    private fun analyzeLink(u: String) {
        if (!u.startsWith("http", true)) {
            toast("Pega un enlace que empiece con http")
            return
        }
        toast("Analizando calidades…")
        val sameSite = AdBlocker.registrable(AdBlocker.host(u)) == AdBlocker.registrable(AdBlocker.host(currentPageUrl))
        val ref = if (sameSite) currentPageUrl else ""
        Thread {
            val qualities = try { MediaProbe.probe(u, ref) } catch (e: Exception) { emptyList() }
            runOnUiThread {
                if (qualities.isEmpty()) toast("No se encontró ningún video en ese enlace")
                else showQualityPicker(qualities, ref, videoName(u))
            }
        }.start()
    }

    /** Lista de calidades detectadas: el usuario elige una y arranca la descarga. */
    private fun showQualityPicker(qualities: List<Quality>, referer: String, name: String) {
        val labels = qualities.map { q ->
            val bits = mutableListOf(q.label)
            if (q.isLive) bits.add("EN VIVO") else if (q.durationSec > 0) bits.add(fmtDuration(q.durationSec))
            if (q.kind == Quality.Kind.UNSUPPORTED) bits.add("(solo info, aún no descargable)")
            bits.joinToString("  •  ")
        }.toTypedArray()

        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Elige la calidad")
                .setItems(labels) { _, which -> startDownload(qualities[which], referer, name) }
                .setNegativeButton("Cancelar", null)
        )
    }

    /** Arranca la descarga (pide permiso de almacenamiento solo en Android 8 y 9) y abre la ventana de progreso. */
    private fun startDownload(q: Quality, referer: String, name: String) {
        if (q.isLive) { toast("Es una transmisión en vivo: no se puede descargar"); return }
        if (q.kind == Quality.Kind.UNSUPPORTED) { toast("Este formato (DASH) todavía no se puede descargar completo"); return }

        if (Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDownload = Triple(q, referer, name)
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 77)
            return
        }

        val label = if (q.height > 0) "$name ${q.height}p" else name
        val cancel = VideoDownloader.cancelFlag()
        val progress = VideoDownloader.Progress()
        val d = ActiveDl(label, progress, cancel)
        active.add(d)
        val appCtx = applicationContext
        Thread { VideoDownloader.download(appCtx, q, referer, label, cancel, progress) }.start()
        startTick()
        showProgressDialog(d)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77) {
            val p = pendingDownload
            pendingDownload = null
            if (p != null) {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startDownload(p.first, p.second, p.third)
                } else {
                    toast("Sin permiso de almacenamiento no se puede guardar en Descargas")
                }
            }
        }
    }

    /** Ventana de progreso: barra, porcentaje, tamaño, velocidad y tiempo restante. */
    private fun showProgressDialog(d: ActiveDl) {
        val a = accent
        val dim = Color.parseColor("#8FBF86")
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(12), dp(24), dp(4))

        val tvName = TextView(this)
        tvName.text = d.name
        tvName.setTextColor(Color.WHITE)
        tvName.textSize = 14f
        tvName.maxLines = 2
        tvName.ellipsize = TextUtils.TruncateAt.END

        val tvPct = TextView(this)
        tvPct.text = "0%"
        tvPct.setTextColor(a)
        tvPct.textSize = 30f
        tvPct.setTypeface(tvPct.typeface, Typeface.BOLD)
        tvPct.setPadding(0, dp(8), 0, dp(4))

        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 1000
        bar.isIndeterminate = false
        bar.progressTintList = ColorStateList.valueOf(a)
        bar.progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#2A2A2A"))

        val tvSize = TextView(this)
        tvSize.setTextColor(dim)
        tvSize.textSize = 12f
        tvSize.setPadding(0, dp(8), 0, 0)

        val tvSpeed = TextView(this)
        tvSpeed.setTextColor(Color.WHITE)
        tvSpeed.textSize = 13f
        tvSpeed.setPadding(0, dp(2), 0, dp(6))

        box.addView(tvName)
        box.addView(tvPct)
        box.addView(bar)
        box.addView(tvSize)
        box.addView(tvSpeed)

        fun refresh() {
            val p = d.progress
            if (p.percent >= 0) {
                bar.isIndeterminate = false
                bar.progress = p.percent * 10
                tvPct.text = "${p.percent}%"
            } else {
                bar.isIndeterminate = true
                tvPct.text = "…"
            }
            val total = p.totalBytes
            tvSize.text = if (total > 0) {
                fmtSize(p.bytes) + " de " + (if (p.totalEstimated) "~" else "") + fmtSize(total)
            } else {
                fmtSize(p.bytes)
            }
            val eta = if (total > 0 && d.speed > 1.0) fmtDuration((total - p.bytes) / d.speed) else ""
            tvSpeed.text = "⚡ " + fmtSpeed(d.speed) + (if (eta.isNotEmpty()) "   •   quedan $eta" else "")
        }

        val dlg = showDlg(
            AlertDialog.Builder(this)
                .setTitle("Descargando…")
                .setView(box)
                .setNeutralButton("Segundo plano", null)
                .setNegativeButton("Cancelar") { _, _ -> d.cancel.set(true) }
                .setCancelable(false)
                .setOnDismissListener { progressRefresh = null }
        )
        progressRefresh = { if (d.progress.done) dlg.dismiss() else refresh() }
        refresh()
    }

    // ------------------------------------------------------------------ Mis descargas

    private fun uriExists(u: String): Boolean = try {
        contentResolver.openFileDescriptor(Uri.parse(u), "r")?.use { true } ?: false
    } catch (e: Exception) {
        false
    }

    private fun deleteUri(u: String) {
        try {
            val uri = Uri.parse(u)
            if (uri.scheme == "file") java.io.File(uri.path ?: "").delete()
            else contentResolver.delete(uri, null, null)
        } catch (e: Exception) { /* ya no estaba */ }
    }

    private fun openDownload(item: DlItem) {
        if (!uriExists(item.uri)) {
            dls.remove(item.uri)
            toast("Ese archivo ya no existe")
            return
        }
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(Uri.parse(item.uri), item.mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast("No hay ninguna app para reproducir el video")
        }
    }

    private fun shareDownload(item: DlItem) {
        if (!uriExists(item.uri)) {
            dls.remove(item.uri)
            toast("Ese archivo ya no existe")
            return
        }
        val send = Intent(Intent.ACTION_SEND)
            .setType(item.mime)
            .putExtra(Intent.EXTRA_STREAM, Uri.parse(item.uri))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(Intent.createChooser(send, "Compartir video"))
        } catch (e: Exception) {
            toast("No se pudo compartir")
        }
    }

    private fun confirmDeleteDownload(item: DlItem, after: () -> Unit) {
        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Borrar video")
                .setMessage(item.name)
                .setPositiveButton("Borrar del celular") { _, _ ->
                    deleteUri(item.uri)
                    dls.remove(item.uri)
                    after()
                }
                .setNeutralButton("Solo quitar de la lista") { _, _ ->
                    dls.remove(item.uri)
                    after()
                }
                .setNegativeButton("Cancelar", null)
        )
    }

    /** Lista de descargas en curso (con progreso en vivo) y de videos ya guardados. */
    private fun showDownloads() {
        val a = accent
        val dim = Color.parseColor("#8FBF86")
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), dp(8))
        val scroll = ScrollView(this)
        scroll.addView(col)
        val liveRows = ArrayList<Triple<ActiveDl, ProgressBar, TextView>>()

        fun chip(label: String, onClick: () -> Unit): TextView {
            val t = TextView(this)
            t.text = label
            t.setTextColor(a)
            t.textSize = 13f
            t.setTypeface(t.typeface, Typeface.BOLD)
            t.setPadding(0, dp(8), dp(18), dp(8))
            t.isClickable = true
            t.setOnClickListener { onClick() }
            return t
        }

        fun render() {
            col.removeAllViews()
            liveRows.clear()
            val items = dls.all()
            if (active.isEmpty() && items.isEmpty()) {
                val empty = TextView(this)
                empty.text = "Aún no hay descargas.\nLos videos que descargues se guardan en la carpeta Descargas/EstebanTV de tu celular."
                empty.setTextColor(dim)
                empty.textSize = 13f
                empty.setPadding(0, dp(12), 0, dp(12))
                col.addView(empty)
                return
            }
            for (d in active) {
                val t = TextView(this)
                t.text = "⭳  " + d.name
                t.setTextColor(Color.WHITE)
                t.textSize = 14f
                t.maxLines = 1
                t.ellipsize = TextUtils.TruncateAt.END
                t.setPadding(0, dp(10), 0, dp(4))
                val b = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
                b.max = 1000
                b.progressTintList = ColorStateList.valueOf(a)
                b.progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#2A2A2A"))
                val s = TextView(this)
                s.setTextColor(dim)
                s.textSize = 12f
                s.setPadding(0, dp(4), 0, dp(2))
                col.addView(t)
                col.addView(b)
                col.addView(s)
                col.addView(chip("Cancelar") { d.cancel.set(true) })
                liveRows.add(Triple(d, b, s))
            }
            for (item in items) {
                val t = TextView(this)
                t.text = item.name
                t.setTextColor(Color.WHITE)
                t.textSize = 15f
                t.maxLines = 2
                t.ellipsize = TextUtils.TruncateAt.END
                t.setPadding(0, dp(14), 0, 0)
                val whenTxt = java.text.DateFormat
                    .getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT)
                    .format(java.util.Date(item.time))
                val meta = TextView(this)
                meta.text = fmtSize(item.size) + "  •  " + whenTxt
                meta.setTextColor(dim)
                meta.textSize = 12f
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.addView(chip("Abrir") { openDownload(item) })
                row.addView(chip("Compartir") { shareDownload(item) })
                row.addView(chip("Borrar") { confirmDeleteDownload(item) { render() } })
                col.addView(t)
                col.addView(meta)
                col.addView(row)
            }
        }

        fun refreshLive() {
            if (liveRows.any { it.first.progress.done }) {
                render()
                return
            }
            for ((d, b, s) in liveRows) {
                val p = d.progress
                if (p.percent >= 0) {
                    b.isIndeterminate = false
                    b.progress = p.percent * 10
                } else {
                    b.isIndeterminate = true
                }
                val pct = if (p.percent >= 0) "${p.percent}%  •  " else ""
                s.text = pct + fmtSize(p.bytes) + "  •  " + fmtSpeed(d.speed)
            }
        }

        render()
        refreshLive()
        listRefresh = { refreshLive() }
        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Mis descargas")
                .setView(scroll)
                .setPositiveButton("Cerrar", null)
                .setOnDismissListener { listRefresh = null }
        )
    }

    /** Escribir una dirección o una búsqueda (la barra de arriba ya no se edita). */
    private fun showGoTo() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val e = styledEdit("Buscar o escribir dirección", "")
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        e.imeOptions = EditorInfo.IME_ACTION_GO
        box.addView(e)
        val d = showDlg(
            AlertDialog.Builder(this)
                .setTitle("Ir a…")
                .setView(box)
                .setPositiveButton("Ir") { _, _ -> loadInput(e.text.toString()) }
                .setNegativeButton("Cancelar", null)
        )
        e.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                loadInput(e.text.toString())
                d.dismiss()
                true
            } else {
                false
            }
        }
        e.requestFocus()
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    // ------------------------------------------------------------------ aviso de ExoPlayer

    /** Ventana Sí / No antes de abrir ExoPlayer: mini vista previa, duración, nombre, descargar y copiar enlace. */
    private fun offerPlayer(url: String, ref: String) {
        if (pc.isOpen || askDialog != null || isFinishing) return
        if (System.currentTimeMillis() < sniffCooldownUntil) return
        if (!prefs.confirmExo) {
            openPlayer(url, ref)
            return
        }

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(8), dp(24), dp(4))

        val q = TextView(this)
        q.text = "Se va a ejecutar ExoPlayer. ¿Continuar?"
        q.setTextColor(Color.WHITE)
        q.textSize = 15f
        box.addView(q)

        // Mini vista previa muda y en bucle, estilo GIF, del video que se va a abrir.
        val previewFrame = FrameLayout(this)
        previewFrame.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(140))
            .apply { topMargin = dp(12) }
        previewFrame.setBackgroundColor(Color.parseColor("#0A0A0A"))
        val previewPlayer = ExoPlayer.Builder(this).build()
        val previewView = PlayerView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            useController = false
            player = previewPlayer
        }
        previewFrame.addView(previewView)

        // Etiqueta de duración o EN VIVO, esquina inferior derecha de la vista previa.
        val badge = TextView(this).apply {
            text = "…"
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(dp(8), dp(3), dp(8), dp(3))
            setBackgroundResource(R.drawable.bg_pill)
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.BOTTOM or Gravity.END
                setMargins(0, 0, dp(8), dp(8))
            }
        }
        previewFrame.addView(badge)
        box.addView(previewFrame)

        try {
            val httpFactory = DefaultHttpDataSource.Factory()
                .setUserAgent(webView.settings.userAgentString)
                .setAllowCrossProtocolRedirects(true)
                .setDefaultRequestProperties(if (ref.isNotEmpty()) mapOf("Referer" to ref) else emptyMap())
            previewPlayer.setMediaSource(DefaultMediaSourceFactory(httpFactory).createMediaSource(MediaItem.fromUri(url)))
            previewPlayer.volume = 0f
            previewPlayer.repeatMode = Player.REPEAT_MODE_ALL
            previewPlayer.prepare()
            previewPlayer.playWhenReady = true
        } catch (e: Exception) { /* si falla la vista previa, se deja el recuadro vacío */ }

        // Duración/EN VIVO: se averigua aparte (playlist HLS/DASH), sin bloquear la vista previa.
        Thread {
            val qs = try { MediaProbe.probe(url, ref) } catch (e: Exception) { emptyList() }
            val info = qs.firstOrNull()
            runOnUiThread {
                badge.text = when {
                    info == null -> ""
                    info.isLive -> "🔴 EN VIVO"
                    info.durationSec > 0 -> fmtDuration(info.durationSec)
                    else -> ""
                }
                if (badge.text.isEmpty()) previewFrame.removeView(badge)
            }
        }.start()

        val small = TextView(this)
        small.text = "▶ " + videoName(url)
        small.setTextColor(accent)
        small.textSize = 12f
        small.maxLines = 1
        small.ellipsize = TextUtils.TruncateAt.END
        small.setPadding(0, dp(10), 0, 0)
        box.addView(small)

        fun actionChip(label: String, filled: Boolean, onClick: () -> Unit): TextView {
            val t = TextView(this)
            t.text = label
            t.gravity = Gravity.CENTER
            t.textSize = 13f
            t.setTypeface(t.typeface, Typeface.BOLD)
            t.setTextColor(if (filled) Color.BLACK else accent)
            t.background = if (filled) Ui.filled(accent, dp(20).toFloat())
            else Ui.outline(Color.TRANSPARENT, accent, dp(1), dp(20).toFloat())
            t.setPadding(dp(10), dp(10), dp(10), dp(10))
            t.isClickable = true
            t.isFocusable = true
            t.setOnClickListener { onClick() }
            return t
        }

        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(14) }
        val bDl = actionChip("⭳  Descargar", true) { downloadVideo(url) }
        val bCopy = actionChip("🔗  Copiar enlace", false) {
            copyText("enlace del video", url)
            toast("Enlace del video copiado ✔")
        }
        actions.addView(bDl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val copyLp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        copyLp.marginStart = dp(10)
        actions.addView(bCopy, copyLp)
        box.addView(actions)

        fun cleanupPreview() {
            previewPlayer.release()
        }

        val d = AlertDialog.Builder(this)
            .setTitle("ExoPlayer")
            .setView(box)
            .setPositiveButton("Sí") { _, _ -> cleanupPreview(); openPlayer(url, ref) }
            .setNegativeButton("No") { _, _ -> cleanupPreview(); declineExo(url) }
            .setOnCancelListener { cleanupPreview(); declineExo(url) }
            .setOnDismissListener { cleanupPreview(); askDialog = null }
            .create()
        askDialog = d
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(accent)
        d.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(accent)
    }

    /**
     * "No": ese video se reproduce en la propia página (se recarga una vez). No hay espera ni bloqueo del sitio:
     * el siguiente video que se detecte vuelve a mostrar el aviso de inmediato.
     */
    private fun declineExo(url: String) {
        val plain = url.substringBefore('?').substringBefore('#')
        val key = if (plain.endsWith(".mp4", true)) plain else plain.substringBeforeLast('/') + "/"
        declinedStreams[key] = System.currentTimeMillis()
        lastDeclineHost = AdBlocker.registrable(AdBlocker.host(url))
        lastDeclineTime = System.currentTimeMillis()
        askDialog = null
        if (webView.visibility == View.VISIBLE) webView.reload()
    }

    private fun openPlayer(url: String, referer: String) {
        if (pc.isOpen || isFinishing) return
        webView.evaluateJavascript(
            "document.querySelectorAll('video,audio').forEach(function(v){try{v.pause()}catch(e){}})", null
        )
        webView.onPause()
        hideSystemBars(true)
        askNotifPermission()
        pc.open(
            url, referer, webView.settings.userAgentString,
            CookieManager.getInstance().getCookie(url), videoName(url)
        )
    }

    /** Android 13+: permiso para mostrar la notificación del reproductor (una sola vez). */
    private fun askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 78)
        }
    }

    private fun hideSystemBars(hide: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (hide) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }
}
