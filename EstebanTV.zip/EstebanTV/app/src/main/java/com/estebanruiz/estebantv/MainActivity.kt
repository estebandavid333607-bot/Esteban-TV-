package com.estebanruiz.estebantv

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import java.io.ByteArrayInputStream

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var etUrl: EditText
    private lateinit var progress: ProgressBar
    private lateinit var home: View
    private lateinit var btnFav: ImageButton
    private lateinit var favContainer: LinearLayout
    private lateinit var playerLayer: View
    private lateinit var playerView: PlayerView
    private lateinit var customContainer: FrameLayout
    private lateinit var favs: FavoritesStore
    private lateinit var prefs: SharedPreferences

    private var player: ExoPlayer? = null
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var defaultUa = ""
    private var pageTitle = ""
    private var clearHistoryOnBlank = false

    @Volatile private var currentPageUrl = ""
    @Volatile private var playerOpen = false
    @Volatile private var sniffCooldownUntil = 0L
    @Volatile private var blockAds = true
    @Volatile private var autoPlayer = true
    private var desktopMode = false

    private val desktopUa =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        favs = FavoritesStore(this)
        prefs = getSharedPreferences("settings", MODE_PRIVATE)
        blockAds = prefs.getBoolean("blockAds", true)
        autoPlayer = prefs.getBoolean("autoPlayer", true)
        desktopMode = prefs.getBoolean("desktopMode", false)

        webView = findViewById(R.id.webView)
        etUrl = findViewById(R.id.etUrl)
        progress = findViewById(R.id.progress)
        home = findViewById(R.id.home)
        btnFav = findViewById(R.id.btnFav)
        favContainer = findViewById(R.id.favContainer)
        playerLayer = findViewById(R.id.playerLayer)
        playerView = findViewById(R.id.playerView)
        customContainer = findViewById(R.id.customContainer)

        setupWebView()
        setupUi()
        refreshFavs()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> hideCustomView()
                    playerOpen -> closePlayer()
                    webView.visibility == View.VISIBLE && webView.canGoBack() -> webView.goBack()
                    webView.visibility == View.VISIBLE -> goHome()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })
    }

    override fun onPause() {
        super.onPause()
        player?.pause()
        webView.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (!playerOpen) webView.onResume()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        webView.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ interfaz

    private fun setupUi() {
        findViewById<View>(R.id.btnHome).setOnClickListener { goHome() }
        findViewById<View>(R.id.googleCard).setOnClickListener { openUrl("https://www.google.com") }
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu(it) }
        findViewById<View>(R.id.btnClosePlayer).setOnClickListener { closePlayer() }

        btnFav.setOnClickListener { toggleFavorite() }

        etUrl.setOnEditorActionListener { _, actionId, event ->
            val enter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                loadInput(etUrl.text.toString())
                hideKeyboard()
                true
            } else false
        }
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(etUrl.windowToken, 0)
        etUrl.clearFocus()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Recargar")
        pm.menu.add(0, 2, 1, "Modo escritorio").apply { isCheckable = true; isChecked = desktopMode }
        pm.menu.add(0, 3, 2, "Bloquear popups y anuncios").apply { isCheckable = true; isChecked = blockAds }
        pm.menu.add(0, 4, 3, "Abrir videos en el reproductor").apply { isCheckable = true; isChecked = autoPlayer }
        pm.menu.add(0, 5, 4, "Acerca de")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> if (webView.visibility == View.VISIBLE) webView.reload()
                2 -> {
                    desktopMode = !desktopMode
                    prefs.edit().putBoolean("desktopMode", desktopMode).apply()
                    webView.settings.userAgentString = if (desktopMode) desktopUa else defaultUa
                    if (webView.visibility == View.VISIBLE) webView.reload()
                }
                3 -> {
                    blockAds = !blockAds
                    prefs.edit().putBoolean("blockAds", blockAds).apply()
                }
                4 -> {
                    autoPlayer = !autoPlayer
                    prefs.edit().putBoolean("autoPlayer", autoPlayer).apply()
                }
                5 -> AlertDialog.Builder(this)
                    .setTitle("Esteban TV")
                    .setMessage("Hecho por: Esteban Ruiz\nVersión 1.0")
                    .setPositiveButton("OK", null)
                    .show()
            }
            true
        }
        pm.show()
    }

    // ------------------------------------------------------------------ navegación

    private fun loadInput(raw: String) {
        val t = raw.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://", true) || t.startsWith("https://", true) -> t
            t.contains(' ') || !t.contains('.') -> "https://www.google.com/search?q=" + Uri.encode(t)
            else -> "https://$t"
        }
        openUrl(url)
    }

    private fun openUrl(url: String) {
        home.visibility = View.GONE
        webView.visibility = View.VISIBLE
        webView.loadUrl(url)
    }

    private fun goHome() {
        if (webView.visibility == View.VISIBLE) {
            clearHistoryOnBlank = true
            webView.loadUrl("about:blank")
        }
        webView.visibility = View.GONE
        home.visibility = View.VISIBLE
        progress.visibility = View.GONE
        currentPageUrl = ""
        pageTitle = ""
        etUrl.setText("")
        hideKeyboard()
        refreshFavs()
        updateFavIcon()
    }

    // ------------------------------------------------------------------ favoritos

    private fun updateFavIcon() {
        val fav = currentPageUrl.isNotEmpty() && favs.contains(currentPageUrl)
        btnFav.setImageResource(if (fav) R.drawable.ic_star else R.drawable.ic_star_border)
    }

    private fun toggleFavorite() {
        val url = currentPageUrl
        if (url.isEmpty()) {
            toast("Abre una página primero")
            return
        }
        if (favs.contains(url)) {
            favs.remove(url)
            toast("Quitado de favoritos")
        } else {
            val title = pageTitle.ifEmpty { AdBlocker.host(url).removePrefix("www.") }
            favs.add(Fav(title, url))
            toast("Agregado a favoritos")
        }
        updateFavIcon()
    }

    private fun refreshFavs() {
        favContainer.removeAllViews()
        val cells = ArrayList<View>()
        favs.all().forEach { f ->
            val letter = f.title.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
            cells.add(makeTile(letter, f.title, { openUrl(f.url) }, { confirmDelete(f) }))
        }
        cells.add(makeTile("+", "Agregar", { showAddDialog() }, null))

        cells.chunked(3).forEach { rowCells ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            rowCells.forEach { row.addView(it) }
            repeat(3 - rowCells.size) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            favContainer.addView(row)
        }
    }

    private fun makeTile(letter: String, label: String, onClick: () -> Unit, onLong: (() -> Unit)?): View {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(10), dp(4), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
            if (onLong != null) setOnLongClickListener { onLong(); true }
        }
        val circle = TextView(this).apply {
            text = letter
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#39FF14"))
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.bg_circle_outline)
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
        }
        val name = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 12f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        }
        tile.addView(circle)
        tile.addView(name)
        return tile
    }

    private fun confirmDelete(f: Fav) {
        AlertDialog.Builder(this)
            .setTitle("Eliminar favorito")
            .setMessage(f.title)
            .setPositiveButton("Eliminar") { _, _ ->
                favs.remove(f.url)
                refreshFavs()
                updateFavIcon()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showAddDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val name = EditText(this).apply {
            hint = "Nombre"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#8FBF86"))
            isSingleLine = true
        }
        val url = EditText(this).apply {
            hint = "https://ejemplo.com"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#8FBF86"))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            isSingleLine = true
        }
        box.addView(name)
        box.addView(url)

        AlertDialog.Builder(this)
            .setTitle("Nuevo favorito")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                var u = url.text.toString().trim()
                if (u.isEmpty()) return@setPositiveButton
                if (!u.startsWith("http", true)) u = "https://$u"
                val n = name.text.toString().trim().ifEmpty { AdBlocker.host(u).removePrefix("www.") }
                favs.add(Fav(n, u))
                refreshFavs()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ------------------------------------------------------------------ WebView

    private fun emptyResponse() =
        WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))

    private fun injectScripts(view: WebView?) {
        if (blockAds) view?.evaluateJavascript(AdBlocker.AD_JS, null)
        if (autoPlayer) view?.evaluateJavascript(AdBlocker.VIDEO_HOOK_JS, null)
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    private fun setupWebView() {
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(webView, true)

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            allowFileAccess = false
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            // Popups: no se permiten ventanas nuevas
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
        }
        defaultUa = webView.settings.userAgentString
        if (desktopMode) webView.settings.userAgentString = desktopUa

        webView.addJavascriptInterface(Bridge(), "EstebanBridge")

        webView.webViewClient = object : WebViewClient() {

            // Detección de video: mira cada petición de la página
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url.toString()
                if (blockAds && AdBlocker.isAdUrl(url)) return emptyResponse()

                if (autoPlayer && request.method == "GET" && AdBlocker.isStreamUrl(url)) {
                    val now = System.currentTimeMillis()
                    if (!playerOpen && now >= sniffCooldownUntil) {
                        val ref = currentPageUrl
                        runOnUiThread { openPlayer(url, ref) }
                    }
                    // Evita que la página también descargue el stream
                    return emptyResponse()
                }
                return null
            }

            // Bloqueo de redirecciones, popunders y esquemas raros
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest): Boolean {
                val uri = request.url
                val url = uri.toString()
                val scheme = uri.scheme?.lowercase()

                if (scheme != "http" && scheme != "https") {
                    if (request.hasGesture() && (scheme == "tel" || scheme == "mailto")) {
                        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (e: Exception) { }
                    }
                    return true
                }
                if (blockAds) {
                    if (AdBlocker.isAdUrl(url)) return true
                    val sameSite = AdBlocker.registrable(AdBlocker.host(url)) ==
                        AdBlocker.registrable(AdBlocker.host(currentPageUrl))
                    if (request.isForMainFrame && !request.hasGesture() && !request.isRedirect &&
                        currentPageUrl.isNotEmpty() && !sameSite
                    ) return true // popunder: salto a otro dominio sin que el usuario toque nada
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url == null || url == "about:blank") return
                currentPageUrl = url
                if (!etUrl.hasFocus()) etUrl.setText(url)
                updateFavIcon()
                if (blockAds) view?.evaluateJavascript(AdBlocker.AD_JS, null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (url == "about:blank") {
                    if (clearHistoryOnBlank) {
                        view?.clearHistory()
                        clearHistoryOnBlank = false
                    }
                    return
                }
                progress.visibility = View.GONE
                if (url != null) {
                    currentPageUrl = url
                    if (!etUrl.hasFocus()) etUrl.setText(url)
                }
                updateFavIcon()
                injectScripts(view)
            }

            // Certificados inválidos: se permite, pero preguntando primero
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler, error: SslError?) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Certificado no válido")
                    .setMessage("Este sitio tiene un problema de seguridad. ¿Continuar de todas formas?")
                    .setPositiveButton("Continuar") { _, _ -> handler.proceed() }
                    .setNegativeButton("Cancelar") { _, _ -> handler.cancel() }
                    .setCancelable(false)
                    .show()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                pageTitle = title.orEmpty()
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customCallback = callback
                customContainer.addView(
                    view,
                    FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                )
                customContainer.visibility = View.VISIBLE
                hideSystemBars(true)
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }

            override fun onHideCustomView() = hideCustomView()
        }
    }

    private fun hideCustomView() {
        if (customView == null) return
        customContainer.removeAllViews()
        customContainer.visibility = View.GONE
        customCallback?.onCustomViewHidden()
        customView = null
        customCallback = null
        hideSystemBars(false)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    /** Puente JS -> Kotlin: recibe fuentes de video detectadas dentro de la página. */
    inner class Bridge {
        @JavascriptInterface
        fun onSource(url: String) {
            if (!autoPlayer || !url.startsWith("http", true)) return
            if (!AdBlocker.isStreamUrl(url) || AdBlocker.isAdUrl(url)) return
            val ref = currentPageUrl
            runOnUiThread {
                if (!playerOpen && System.currentTimeMillis() >= sniffCooldownUntil) openPlayer(url, ref)
            }
        }
    }

    // ------------------------------------------------------------------ reproductor (ExoPlayer)

    private fun openPlayer(url: String, referer: String) {
        if (playerOpen || isFinishing) return
        playerOpen = true

        webView.evaluateJavascript(
            "document.querySelectorAll('video,audio').forEach(function(v){try{v.pause()}catch(e){}})", null
        )
        webView.onPause()

        val headers = HashMap<String, String>()
        if (referer.isNotEmpty()) {
            headers["Referer"] = referer
            val u = Uri.parse(referer)
            if (u.scheme != null && u.host != null) headers["Origin"] = "${u.scheme}://${u.host}"
        }
        CookieManager.getInstance().getCookie(url)?.let { headers["Cookie"] = it }

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(webView.settings.userAgentString)
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(headers)

        val item = MediaItem.Builder().setUri(url).apply {
            when {
                AdBlocker.isM3u8(url) -> setMimeType(MimeTypes.APPLICATION_M3U8)
                AdBlocker.isMpd(url) -> setMimeType(MimeTypes.APPLICATION_MPD)
            }
        }.build()

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                toast("No se pudo reproducir este video")
                playerView.post { closePlayer() }
            }
        })
        playerView.player = p
        p.setMediaItem(item)
        p.prepare()
        p.playWhenReady = true
        player = p

        playerLayer.visibility = View.VISIBLE
        hideSystemBars(true)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    private fun closePlayer() {
        if (!playerOpen) return
        playerView.player = null
        player?.release()
        player = null
        playerLayer.visibility = View.GONE
        hideSystemBars(false)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        webView.onResume()
        playerOpen = false
        sniffCooldownUntil = System.currentTimeMillis() + 3000
    }

    private fun hideSystemBars(hide: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (hide) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }
}
