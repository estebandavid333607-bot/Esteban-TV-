package com.estebanruiz.estebantv

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.widget.doAfterTextChanged
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import java.io.ByteArrayInputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var etUrl: EditText
    private lateinit var progress: ProgressBar
    private lateinit var home: View
    private lateinit var btnHome: ImageButton
    private lateinit var btnFav: ImageButton
    private lateinit var btnGoogle: ImageButton
    private lateinit var btnMenu: ImageButton
    private lateinit var favContainer: LinearLayout
    private lateinit var googleCard: View
    private lateinit var dlCard: View
    private lateinit var dlListCard: View
    private lateinit var footCard: View
    private lateinit var agendaCard: View
    private lateinit var agendaSub: TextView
    private lateinit var agendaStore: AgendaStore
    private var agendaDialog: AlertDialog? = null
    private var agendaLoading = false
    private lateinit var scoreStore: ScoreStore
    private lateinit var reminders: ReminderStore
    private var scoreCache: List<Score> = emptyList()
    private val scoreMemo = HashMap<String, ScoreFetcher.Match?>()
    private var scoresLoading = false
    private var scoresFetchedAt = 0L
    private var agendaRerender: (() -> Unit)? = null
    private var exactAskedThisSession = false
    private val agendaWaiters = ArrayList<(Agenda?) -> Unit>()
    private var footDialog: AlertDialog? = null
    private lateinit var dls: DownloadsStore
    private lateinit var homeTitle: TextView
    private lateinit var homeFavLabel: TextView
    private lateinit var homeMadeBy: TextView
    private lateinit var playerLayer: View
    private lateinit var customContainer: FrameLayout
    private lateinit var favs: FavoritesStore
    private lateinit var prefs: Prefs
    private lateinit var icons: IconStore
    private lateinit var pc: PlayerController

    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var defaultUa = ""
    private var pageTitle = ""
    private var clearHistoryOnBlank = false
    private var askDialog: AlertDialog? = null
    private val iconRequested = HashSet<String>()
    // Videos a los que el usuario dijo "No" (carpeta/archivo -> hora). Solo esos se reproducen en la página;
    // cualquier otro video nuevo vuelve a preguntar de inmediato.
    private val declinedStreams: MutableMap<String, Long> = ConcurrentHashMap<String, Long>()
    @Volatile private var lastDeclineHost = ""
    @Volatile private var lastDeclineTime = 0L
    private var pill: TextView? = null

    @Volatile private var currentPageUrl = ""
    @Volatile private var sniffCooldownUntil = 0L

    // Protección anti-redirección
    @Volatile private var tapCount = 0
    @Volatile private var lastLinkHref = ""
    @Volatile private var lastLinkTrusted = false
    @Volatile private var lastLinkTime = 0L
    private var lastBlocked = ""
    private var lastBlockedToast = 0L
    private var downX = 0f
    private var downY = 0f
    private var downT = 0L

    private val accent: Int get() = prefs.accent

    private val desktopUa =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private val engines = arrayOf(
        "Google" to "https://www.google.com/search?q=",
        "Bing" to "https://www.bing.com/search?q=",
        "DuckDuckGo" to "https://duckduckgo.com/?q=",
        "Brave" to "https://search.brave.com/search?q="
    )

    private val palette = arrayOf(
        "Verde neón" to 0xFF39FF14.toInt(),
        "Cian" to 0xFF00E5FF.toInt(),
        "Azul" to 0xFF448AFF.toInt(),
        "Violeta" to 0xFFB388FF.toInt(),
        "Magenta" to 0xFFFF2BD6.toInt(),
        "Rojo" to 0xFFFF1744.toInt(),
        "Naranja" to 0xFFFF9100.toInt(),
        "Amarillo" to 0xFFFFEA00.toInt(),
        "Blanco" to 0xFFFFFFFF.toInt()
    )

    private val playerHost = object : PlayerController.Host {
        override fun accent(): Int = prefs.accent
        override fun setOrientation(o: Int) {
            requestedOrientation = o
        }

        override fun onPlayerClosed() {
            hideSystemBars(prefs.fullscreen)
            applyRotation()
            webView.onResume()
            sniffCooldownUntil = System.currentTimeMillis() + 3000
            if (moviesReturn) {
                moviesReturn = false
                // Al salir de la película la pantalla vuelve a vertical; luego se respeta el ajuste de rotación.
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                Handler(Looper.getMainLooper()).postDelayed({ if (!isFinishing) applyRotation() }, 800)
                showMovies(restore = true)
            }
            // Igual que Películas: al cerrar el reproductor se vuelve al menú de adultos.
            if (adultReturn) {
                adultReturn = false
                showAdult(restore = true)
            }
        }

        override fun showDialog(b: AlertDialog.Builder): AlertDialog = showDlg(b)
        override fun showAgendaFromPlayer() = showAgenda(fromPlayer = true)

        override fun onPlayerClosing(positionMs: Long, durationMs: Long) {
            home.removeCallbacks(progressTick)
            if (moviesReturn) saveMovieProgress(positionMs, durationMs)
            currentMovie = null
        }

        override fun retryNewSignal(): Boolean {
            val w = lastWatch.get() ?: return false
            if (w.kind != "agenda") return false
            playAgendaChannel(AgendaEvent("", w.title, emptyList()), AgendaChannel("", "", w.url), fromPlayer = true)
            return true
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        CfGate.activity = this

        favs = FavoritesStore(this)
        prefs = Prefs(this)
        icons = IconStore(this)
        dls = DownloadsStore(this)
        lastWatch = LastWatch(this)

        webView = findViewById(R.id.webView)
        etUrl = findViewById(R.id.etUrl)
        progress = findViewById(R.id.progress)
        home = findViewById(R.id.home)
        btnHome = findViewById(R.id.btnHome)
        btnFav = findViewById(R.id.btnFav)
        btnGoogle = findViewById(R.id.btnGoogle)
        btnMenu = findViewById(R.id.btnMenu)
        favContainer = findViewById(R.id.favContainer)
        googleCard = findViewById(R.id.googleCard)
        dlCard = findViewById(R.id.dlCard)
        dlListCard = findViewById(R.id.dlListCard)
        footCard = findViewById(R.id.footCard)
        agendaCard = findViewById(R.id.agendaCard)
        movieCard = findViewById(R.id.movieCard)
        adultCard = findViewById(R.id.adultCard)
        adultStore = AdultStore(this)
        movieStore = MovieStore(this)
        movieProgress = MovieProgress(this)
        agendaSub = findViewById(R.id.agendaSub)
        agendaStore = AgendaStore(this)
        scoreStore = ScoreStore(this)
        scoreCache = scoreStore.all()
        reminders = ReminderStore(this)
        reminders.prune()
        AgendaWorker.schedule(applicationContext)
        homeTitle = findViewById(R.id.homeTitle)
        homeFavLabel = findViewById(R.id.homeFavLabel)
        homeMadeBy = findViewById(R.id.homeMadeBy)
        playerLayer = findViewById(R.id.playerLayer)
        customContainer = findViewById(R.id.customContainer)

        pc = PlayerController(this, playerLayer, prefs, playerHost)

        setupWebView()
        setupUi()
        showUrlSlogan()
        applyRotation()
        hideSystemBars(prefs.fullscreen)
        applyAccent()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> hideCustomView()
                    movieDialog?.isShowing == true && !pc.isOpen -> movieDialog?.dismiss()
                    pc.isOpen -> if (pc.isLocked) toast("Desbloquea los controles (🔒) para salir") else pc.close()
                    webView.visibility == View.VISIBLE && webView.canGoBack() -> webView.goBack()
                    webView.visibility == View.VISIBLE -> goHome()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        if (savedInstanceState == null) {
            if (prefs.welcome) showWelcome()
            lastWatch.get()?.let { w -> home.post { showResumeBanner(w) } }
            if (prefs.restoreLast && prefs.lastPage.isNotEmpty()) openUrl(prefs.lastPage)
        }
    }

    override fun onPause() {
        super.onPause()
        // Con el reproductor abierto y "segundo plano" activo NO se pausa: sigue sonando (y con pantalla apagada).
        if (!(pc.isOpen && prefs.bgPlay)) pc.pause()
        webView.onPause()
    }

    override fun onStart() {
        super.onStart()
        pc.onAppForeground()
    }

    override fun onStop() {
        if (pc.isOpen && currentMovie != null) saveMovieProgress(pc.positionMs(), pc.durationMs())
        pc.onAppBackground()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (!pc.isOpen) webView.onResume()
    }

    override fun onDestroy() {
        if (CfGate.activity === this) CfGate.activity = null
        streamResolver?.cancel()
        pc.release()
        webView.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ interfaz

    private fun setupUi() {
        btnHome.setOnClickListener { goHome() }
        btnGoogle.setOnClickListener { openUrl("https://www.google.com") }
        googleCard.setOnClickListener { openUrl("https://www.google.com") }
        btnMenu.setOnClickListener { showMenu(it) }
        btnFav.setOnClickListener { toggleFavorite() }

        dlCard.setOnClickListener { showDownloader() }
        dlListCard.setOnClickListener { showDownloads() }
        footCard.setOnClickListener { showFootball() }
        agendaCard.setOnClickListener { showAgenda() }
        movieCard.setOnClickListener { chooseCatalog() }
        adultCard.setOnClickListener { askAdultPin() }
        updateAgendaCardText()
        handleAgendaIntent(intent)
        // Deja la agenda lista: si la guardada tiene más de 15 minutos, se actualiza sola en segundo plano.
        home.postDelayed({
            val c = agendaStore.cached()
            if (!isFinishing && (c == null || System.currentTimeMillis() - c.fetchedAt > 15 * 60_000L)) fetchAgenda { }
        }, 1500)

        // La barra de arriba solo muestra el eslogan: no se puede tocar, editar ni ver la URL.
        etUrl.isFocusable = false
        etUrl.isFocusableInTouchMode = false
        etUrl.isCursorVisible = false
        etUrl.isLongClickable = false
        etUrl.setOnClickListener { }
    }

    /** Muestra el nombre/eslogan de la app en la barra en vez de la URL real. */
    private fun showUrlSlogan() {
        etUrl.setText(if (currentPageUrl.isEmpty()) getString(R.string.app_name_caps) else getString(R.string.url_slogan))
    }

    /** Aplica el color (paleta) elegido a toda la interfaz. */
    private fun applyAccent() {
        val a = accent
        progress.progressTintList = ColorStateList.valueOf(a)
        listOf(btnHome, btnFav, btnMenu).forEach { it.setColorFilter(a) }
        etUrl.background = Ui.outline(Color.parseColor("#0F0F0F"), a, dp(1), dp(22).toFloat())
        googleCard.background = Ui.outline(Color.parseColor("#0A0A0A"), a, dp(2), dp(18).toFloat())
        dlCard.background = Ui.outline(Color.parseColor("#0A0A0A"), a, dp(2), dp(18).toFloat())
        dlListCard.background = Ui.outline(Color.parseColor("#0A0A0A"), a, dp(2), dp(18).toFloat())
        footCard.background = Ui.outline(Color.parseColor("#0A0A0A"), a, dp(2), dp(18).toFloat())
        agendaCard.background = Ui.outline(Color.parseColor("#0A0A0A"), a, dp(2), dp(18).toFloat())
        movieCard.background = Ui.outline(Color.parseColor("#0A0A0A"), a, dp(2), dp(18).toFloat())
        adultCard.background = Ui.outline(Color.parseColor("#0A0A0A"), a, dp(2), dp(18).toFloat())
        listOf(R.id.dlIcon, R.id.dlListIcon, R.id.footIcon, R.id.agendaIcon, R.id.movieIcon, R.id.adultIcon).forEach { id ->
            val iv = findViewById<ImageView>(id)
            iv.background = Ui.outline(Color.parseColor("#0A0A0A"), a, dp(2), 0f, oval = true)
            iv.setColorFilter(a)
        }
        homeTitle.setTextColor(a)
        homeTitle.setShadowLayer(20f, 0f, 0f, a)
        homeFavLabel.setTextColor(a)
        homeMadeBy.setTextColor(ColorUtils.blendARGB(a, Color.BLACK, 0.45f))
        pc.applyAccent()
        refreshFavs()
    }

    private fun applyRotation() {
        requestedOrientation = when (prefs.rotation) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            3 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    private fun applyWebSettings() {
        with(webView.settings) {
            textZoom = prefs.textZoom
            blockNetworkImage = !prefs.loadImages
            userAgentString = if (prefs.desktopMode) desktopUa else defaultUa
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, prefs.thirdPartyCookies)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(etUrl.windowToken, 0)
        etUrl.clearFocus()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun showDlg(b: AlertDialog.Builder): AlertDialog {
        val d = b.create()
        d.show()
        val a = accent
        d.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(a)
        d.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(a)
        d.getButton(AlertDialog.BUTTON_NEUTRAL)?.setTextColor(a)
        return d
    }

    private lateinit var lastWatch: LastWatch

    /** Pestaña pequeña abajo (8 s) con lo último que viste: tócala para seguir. */
    private fun showResumeBanner(item: LastWatch.Item) {
        val a = accent
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = Ui.outline(Color.parseColor("#F2000000"), a, dp(2), dp(18).toFloat())
        card.elevation = dp(8).toFloat()
        card.alpha = 0f

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(16), dp(10), dp(4), dp(8))
        val play = TextView(this)
        play.text = "▶"
        play.setTextColor(a)
        play.textSize = 22f
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t1 = TextView(this)
        t1.text = "Seguir viendo"
        t1.setTextColor(a)
        t1.textSize = 12f
        t1.setTypeface(t1.typeface, Typeface.BOLD)
        val t2 = TextView(this)
        t2.text = item.title.ifEmpty { "Último video" }
        t2.setTextColor(Color.WHITE)
        t2.textSize = 15f
        t2.setTypeface(t2.typeface, Typeface.BOLD)
        t2.maxLines = 1
        t2.ellipsize = TextUtils.TruncateAt.END
        col.addView(t1)
        col.addView(t2)
        val x = TextView(this)
        x.text = "✕"
        x.setTextColor(Color.parseColor("#8FBF86"))
        x.textSize = 18f
        x.setPadding(dp(14), dp(10), dp(14), dp(10))
        row.addView(play)
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12) })
        row.addView(x)

        val timer = View(this)
        timer.setBackgroundColor(a)
        timer.pivotX = 0f
        card.addView(row)
        card.addView(timer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)).apply { setMargins(dp(14), 0, dp(14), dp(8)) })

        val content = findViewById<ViewGroup>(android.R.id.content)
        content.addView(
            card,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
                .apply { setMargins(dp(16), 0, dp(16), dp(36)) }
        )

        var gone = false
        fun remove() {
            if (gone) return
            gone = true
            timer.animate().cancel()
            card.animate().alpha(0f).setDuration(250).withEndAction { (card.parent as? ViewGroup)?.removeView(card) }.start()
        }
        row.setOnClickListener {
            remove()
            resumeLast(item)
        }
        x.setOnClickListener { remove() }

        card.animate().alpha(1f).setDuration(300).start()
        timer.animate().scaleX(0f).setDuration(8000).setInterpolator(android.view.animation.LinearInterpolator())
            .withEndAction { remove() }.start()
    }

    /** Vuelve a abrir lo último que se vio, buscando de nuevo la señal si hace falta. */
    private fun resumeLast(i: LastWatch.Item) {
        if (pc.isOpen) return
        when (i.kind) {
            "movie" -> {
                val e = movieProgress.get(i.url)
                playMovie(e?.movie ?: Movie(i.url, i.title, "", "", "", "", "", "", i.url), e?.posMs ?: 0L)
            }
            "agenda" -> playAgendaChannel(AgendaEvent("", i.title, emptyList()), AgendaChannel("", "", i.url))
            "direct" -> openPlayer(i.url, i.referer, i.title)
            else -> openUrl(i.url)
        }
    }

    private fun openPlayerWeb(url: String, ref: String) {
        if (ref.isNotEmpty()) lastWatch.save("web", videoName(url), ref)
        openPlayer(url, ref)
    }

    private fun showWelcome() {
        val card = TextView(this).apply {
            text = "👋 ¡Bienvenido a Esteban TV!\nApp hecha por Esteban Ruiz"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(24), dp(16), dp(24), dp(16))
            background = Ui.outline(Color.parseColor("#F2000000"), accent, dp(2), dp(18).toFloat())
            elevation = dp(8).toFloat()
            alpha = 0f
        }
        val content = findViewById<ViewGroup>(android.R.id.content)
        content.addView(
            card,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
        )
        // 300 ms entrada + 1400 ms visible + 300 ms salida ≈ 2 s
        card.animate().alpha(1f).setDuration(300).withEndAction {
            card.animate().alpha(0f).setStartDelay(1400).setDuration(300).withEndAction {
                (card.parent as? ViewGroup)?.removeView(card)
            }.start()
        }.start()
    }

    // ------------------------------------------------------------------ menú ⋮

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        val m = pm.menu
        val onPage = webView.visibility == View.VISIBLE && currentPageUrl.isNotEmpty()
        m.add(0, 1, 0, "Recargar")
        m.add(0, 2, 1, "Modo escritorio").apply { isCheckable = true; isChecked = prefs.desktopMode }
        m.add(0, 11, 2, "Buscar / ir a una dirección")
        if (onPage) {
            m.add(0, 3, 2, "Copiar enlace")
            m.add(0, 4, 3, "Compartir enlace")
            m.add(0, 5, 4, "Abrir en otro navegador")
        }
        if (lastBlocked.isNotEmpty()) m.add(0, 6, 5, "Permitir última redirección bloqueada")
        m.add(0, 10, 7, "Descargar video")
        m.add(0, 12, 8, "Mis descargas")
        m.add(0, 8, 9, "Ajustes")
        m.add(0, 9, 10, "Acerca de")

        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> if (webView.visibility == View.VISIBLE) webView.reload()
                2 -> setDesktop(!prefs.desktopMode)
                3 -> {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("enlace", currentPageUrl))
                    toast("Enlace copiado")
                }
                4 -> startActivity(
                    Intent.createChooser(
                        Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, currentPageUrl),
                        "Compartir enlace"
                    )
                )
                5 -> try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(currentPageUrl)))
                } catch (e: Exception) {
                    toast("No hay otro navegador")
                }
                6 -> {
                    val u = lastBlocked
                    lastBlocked = ""
                    if (u.isNotEmpty()) openUrl(u)
                }
                8 -> showSettings()
                9 -> showAbout()
                10 -> showDownloader()
                11 -> showGoTo()
                12 -> showDownloads()
            }
            true
        }
        pm.show()
    }

    private fun setDesktop(v: Boolean) {
        prefs.desktopMode = v
        webView.settings.userAgentString = if (v) desktopUa else defaultUa
        if (webView.visibility == View.VISIBLE) webView.reload()
    }

    private fun showAbout() {
        val ver = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Esteban TV")
                .setMessage("App hecha por Esteban Ruiz\nVersión $ver")
                .setPositiveButton("OK", null)
        )
    }

    // ------------------------------------------------------------------ ajustes

    private fun showSettings() {
        val a = accent
        val dim = Color.parseColor("#8FBF86")
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(8))
        }
        val scroll = ScrollView(this)
        scroll.addView(col)

        fun section(t: String) {
            val tv = TextView(this)
            tv.text = t
            tv.setTextColor(a)
            tv.textSize = 12f
            tv.letterSpacing = 0.12f
            tv.setTypeface(tv.typeface, Typeface.BOLD)
            tv.setPadding(0, dp(18), 0, dp(4))
            col.addView(tv)
        }

        fun switchRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(8), 0, dp(8))
            val texts = LinearLayout(this)
            texts.orientation = LinearLayout.VERTICAL
            texts.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            val t = TextView(this)
            t.text = title
            t.setTextColor(Color.WHITE)
            t.textSize = 15f
            texts.addView(t)
            if (sub != null) {
                val s = TextView(this)
                s.text = sub
                s.setTextColor(dim)
                s.textSize = 12f
                texts.addView(s)
            }
            val sw = SwitchCompat(this)
            sw.isChecked = checked
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            sw.thumbTintList = ColorStateList(states, intArrayOf(a, Color.GRAY))
            sw.trackTintList = ColorStateList(
                states, intArrayOf(ColorUtils.setAlphaComponent(a, 110), Color.parseColor("#33FFFFFF"))
            )
            sw.setOnCheckedChangeListener { _, v -> onChange(v) }
            row.setOnClickListener { sw.toggle() }
            row.addView(texts)
            row.addView(sw)
            col.addView(row)
        }

        fun choiceRow(title: String, options: Array<String>, current: () -> Int, onPick: (Int) -> Unit) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(0, dp(10), 0, dp(10))
            row.isClickable = true
            val t = TextView(this)
            t.text = title
            t.setTextColor(Color.WHITE)
            t.textSize = 15f
            val v = TextView(this)
            v.text = options[current().coerceIn(0, options.size - 1)]
            v.setTextColor(a)
            v.textSize = 13f
            row.addView(t)
            row.addView(v)
            row.setOnClickListener {
                showDlg(
                    AlertDialog.Builder(this)
                        .setTitle(title)
                        .setSingleChoiceItems(options, current()) { d, w ->
                            onPick(w)
                            v.text = options[w]
                            d.dismiss()
                        }
                        .setNegativeButton("Cancelar", null)
                )
            }
            col.addView(row)
        }

        fun actionRow(title: String, sub: String?, onClick: () -> Unit) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(0, dp(10), 0, dp(10))
            row.isClickable = true
            val t = TextView(this)
            t.text = title
            t.setTextColor(Color.WHITE)
            t.textSize = 15f
            row.addView(t)
            if (sub != null) {
                val s = TextView(this)
                s.text = sub
                s.setTextColor(dim)
                s.textSize = 12f
                row.addView(s)
            }
            row.setOnClickListener { onClick() }
            col.addView(row)
        }

        // ---- Navegación
        section("NAVEGACIÓN")
        choiceRow("Motor de búsqueda", engines.map { it.first }.toTypedArray(),
            { prefs.searchEngine }, { prefs.searchEngine = it })
        choiceRow("Protección anti-redirección",
            arrayOf("Desactivada", "Solo tras 2 toques (recomendado)", "Nunca redirigir a otras webs"),
            { prefs.redirMode }, { prefs.redirMode = it })
        switchRow("Bloquear popups y anuncios", "Filtra dominios de publicidad y ventanas emergentes",
            prefs.blockAds) { prefs.blockAds = it }
        switchRow("Modo escritorio", "Pide la versión de PC de las webs", prefs.desktopMode) { setDesktop(it) }
        val zoomVals = intArrayOf(85, 100, 125, 150)
        choiceRow("Tamaño del texto", arrayOf("Pequeño (85%)", "Normal (100%)", "Grande (125%)", "Muy grande (150%)"),
            { zoomVals.indexOf(prefs.textZoom).coerceAtLeast(1) }) {
            prefs.textZoom = zoomVals[it]
            webView.settings.textZoom = zoomVals[it]
        }
        switchRow("Cargar imágenes", "Apágalo para ahorrar datos", prefs.loadImages) {
            prefs.loadImages = it
            webView.settings.blockNetworkImage = !it
        }
        switchRow("Cookies de terceros", "Algunas webs las necesitan para iniciar sesión",
            prefs.thirdPartyCookies) {
            prefs.thirdPartyCookies = it
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, it)
        }
        switchRow("Recordar la última página", "Al abrir la app vuelve a donde estabas", prefs.restoreLast) {
            prefs.restoreLast = it
            if (!it) prefs.lastPage = ""
        }
        switchRow("Pantalla completa", "Oculta las barras del sistema", prefs.fullscreen) {
            prefs.fullscreen = it
            hideSystemBars(it)
        }

        // ---- Reproductor
        section("REPRODUCTOR (EXOPLAYER)")
        switchRow("Abrir videos en ExoPlayer", "Detecta streams .m3u8, .mpd y .mp4", prefs.autoPlayer) {
            prefs.autoPlayer = it
        }
        switchRow("Preguntar antes de abrir", "Muestra Sí / No con el nombre del video", prefs.confirmExo) {
            prefs.confirmExo = it
        }
        val qVals = intArrayOf(0, 1080, 720, 480, 360)
        choiceRow("Resolución máxima", arrayOf("Sin límite (Auto)", "1080p", "720p", "480p", "360p"),
            { qVals.indexOf(prefs.maxQuality).coerceAtLeast(0) }) { prefs.maxQuality = qVals[it] }

        // ---- Apariencia
        section("APARIENCIA")
        choiceRow("Paleta de colores", palette.map { it.first }.toTypedArray(),
            { palette.indexOfFirst { it.second == prefs.accent }.coerceAtLeast(0) }) {
            prefs.accent = palette[it].second
            applyAccent()
        }
        choiceRow("Rotación de pantalla",
            arrayOf("Según el sistema", "Automática (siempre gira)", "Solo vertical", "Solo horizontal"),
            { prefs.rotation }) {
            prefs.rotation = it
            applyRotation()
        }
        switchRow("Mensaje de bienvenida", "Aparece 2 segundos al abrir la app", prefs.welcome) { prefs.welcome = it }

        // ---- Datos
        section("DATOS")
        actionRow("Borrar caché", "Libera espacio de las páginas guardadas") {
            webView.clearCache(true)
            toast("Caché borrada")
        }
        actionRow("Borrar cookies y datos de sitios", "Cierra tus sesiones en las webs") {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            WebStorage.getInstance().deleteAllData()
            toast("Cookies y datos borrados")
        }
        actionRow("Restablecer ajustes", "Vuelve a los valores originales (no borra favoritos)") {
            showDlg(
                AlertDialog.Builder(this)
                    .setTitle("Restablecer ajustes")
                    .setMessage("¿Volver a los ajustes originales?")
                    .setPositiveButton("Restablecer") { _, _ ->
                        prefs.reset()
                        clearDeclined()
                        applyWebSettings()
                        applyRotation()
                        hideSystemBars(prefs.fullscreen)
                        applyAccent()
                        toast("Ajustes restablecidos")
                    }
                    .setNegativeButton("Cancelar", null)
            )
        }

        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Ajustes")
                .setView(scroll)
                .setPositiveButton("Listo", null)
        )
    }

    // ------------------------------------------------------------------ navegación

    private fun loadInput(raw: String) {
        val t = raw.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://", true) || t.startsWith("https://", true) -> t
            t.contains(' ') || !t.contains('.') ->
                engines[prefs.searchEngine.coerceIn(0, engines.size - 1)].second + Uri.encode(t)
            else -> "https://$t"
        }
        openUrl(url)
    }

    private fun openUrl(url: String) {
        tapCount = 0
        home.visibility = View.GONE
        webView.visibility = View.VISIBLE
        webView.loadUrl(url)
    }

    private fun goHome() {
        if (webView.visibility == View.VISIBLE) {
            clearHistoryOnBlank = true
            webView.loadUrl("about:blank")
        }
        webView.visibility = View.GONE
        home.visibility = View.VISIBLE
        progress.visibility = View.GONE
        currentPageUrl = ""
        pageTitle = ""
        clearDeclined()
        prefs.lastPage = ""
        etUrl.setText("")
        showUrlSlogan()
        hideKeyboard()
        refreshFavs()
        updateFavIcon()
    }

    // ------------------------------------------------------------------ Adultos XXX (lista M3U con clave)

    private lateinit var adultCard: View
    private lateinit var adultStore: AdultStore
    private var adultDialog: AlertDialog? = null
    private var adultReturn = false
    private var adultGroup = ""

    /** Pide la clave (AdultStore.PIN) antes de mostrar los canales. */
    private fun askAdultPin() {
        val et = EditText(this)
        et.hint = "Clave"
        et.setTextColor(Color.WHITE)
        et.setHintTextColor(Color.parseColor("#8FBF86"))
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        et.isSingleLine = true
        et.gravity = Gravity.CENTER
        et.textSize = 22f
        val box = FrameLayout(this)
        box.setPadding(dp(24), dp(8), dp(24), 0)
        box.addView(et)
        val d = showDlg(
            AlertDialog.Builder(this)
                .setTitle("Adultos XXX 🔞")
                .setMessage("Solo mayores de edad. Escribe la clave para entrar.")
                .setView(box)
                .setPositiveButton("Entrar", null)
                .setNegativeButton("Cancelar", null)
        )
        fun check() {
            if (et.text.toString() == AdultStore.PIN) {
                d.dismiss()
                showAdult()
            } else {
                toast("Clave incorrecta")
                et.setText("")
            }
        }
        d.getButton(AlertDialog.BUTTON_POSITIVE)?.setOnClickListener { check() }
        et.setOnEditorActionListener { _, _, _ -> check(); true }
        et.requestFocus()
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    /** Lista de canales de la M3U: buscador, grupos y un toque para verlo en ExoPlayer. */
    private fun showAdult(restore: Boolean = false) {
        adultDialog?.dismiss()
        val a = accent
        val dim = Color.parseColor("#8FBF86")
        var all: List<AdultChannel> = adultStore.cached()
        var group = if (restore) adultGroup else ""
        var limit = 80
        var loading = false

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(4), dp(16), 0)
        val search = styledEdit("Buscar canal…", "")
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        val chipsScroll = HorizontalScrollView(this)
        chipsScroll.isHorizontalScrollBarEnabled = false
        chipsScroll.addView(chips)
        val status = TextView(this)
        status.setTextColor(dim)
        status.textSize = 12f
        status.setPadding(0, dp(8), 0, dp(4))
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(this)
        scroll.addView(list)
        root.addView(search)
        root.addView(chipsScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        root.addView(status)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(400)))

        var render: () -> Unit = { }
        var fillChips: () -> Unit = { }

        fun chip(label: String, value: String): View {
            val sel = value == group
            val t = TextView(this)
            t.text = label
            t.textSize = 12f
            t.setTypeface(t.typeface, Typeface.BOLD)
            t.setTextColor(if (sel) Color.BLACK else a)
            t.background = if (sel) Ui.filled(a, dp(14).toFloat()) else Ui.outline(Color.TRANSPARENT, a, dp(1), dp(14).toFloat())
            t.setPadding(dp(12), dp(6), dp(12), dp(6))
            t.isClickable = true
            t.setOnClickListener {
                group = value
                limit = 80
                fillChips()
                render()
            }
            return t
        }

        fillChips = {
            chips.removeAllViews()
            val groups = all.map { it.group }.filter { it.isNotEmpty() }.distinct().take(40)
            if (groups.size > 1) {
                chips.addView(chip("Todos", ""), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(6) })
                groups.forEach { g ->
                    chips.addView(chip(g, g), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(6) })
                }
            }
            chipsScroll.visibility = if (groups.size > 1) View.VISIBLE else View.GONE
        }

        fun row(ch: AdultChannel): View {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(0, dp(8), 0, dp(8))
            r.isClickable = true
            val logo = ImageView(this)
            logo.scaleType = ImageView.ScaleType.FIT_CENTER
            logo.setBackgroundColor(Color.parseColor("#1A1A1A"))
            roundView(logo, 8)
            if (ch.logo.isNotEmpty()) MovieImages.load(ch.logo, logo)
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            val t = TextView(this)
            t.text = ch.name
            t.setTextColor(Color.WHITE)
            t.textSize = 14f
            t.maxLines = 2
            t.ellipsize = TextUtils.TruncateAt.END
            col.addView(t)
            if (ch.group.isNotEmpty()) {
                val g = TextView(this)
                g.text = ch.group
                g.setTextColor(dim)
                g.textSize = 11f
                col.addView(g)
            }
            r.addView(logo, LinearLayout.LayoutParams(dp(44), dp(44)))
            r.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12) })
            r.setOnClickListener {
                adultDialog?.dismiss()
                adultGroup = group
                adultReturn = true
                lastWatch.save("direct", ch.name, ch.url, ch.referer)
                openPlayer(ch.url, ch.referer, ch.name)
            }
            return r
        }

        render = {
            list.removeAllViews()
            val q = movieNorm(search.text.toString().trim())
            val shown = all.filter { (group.isEmpty() || it.group == group) && (q.isEmpty() || movieNorm(it.name).contains(q)) }
            status.text = when {
                loading && all.isEmpty() -> "Cargando canales…"
                all.isEmpty() -> "No se pudo cargar la lista. Toca Actualizar."
                loading -> "Actualizando…"
                else -> "${shown.size} canal" + (if (shown.size == 1) "" else "es")
            }
            shown.take(limit).forEach { ch ->
                list.addView(row(ch))
                val line = View(this)
                line.setBackgroundColor(Color.parseColor("#222222"))
                list.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
            }
            if (shown.size > limit) {
                val more = TextView(this)
                more.text = "Mostrar más ⬇"
                more.setTextColor(a)
                more.textSize = 14f
                more.gravity = Gravity.CENTER
                more.setTypeface(more.typeface, Typeface.BOLD)
                more.setPadding(0, dp(14), 0, dp(14))
                more.isClickable = true
                more.setOnClickListener { limit += 80; render() }
                list.addView(more)
            }
        }

        fun refresh() {
            if (loading) return
            loading = true
            render()
            adultStore.fetch { res ->
                loading = false
                if (res != null) {
                    all = res
                    fillChips()
                } else if (adultDialog?.isShowing == true) {
                    toast("No se pudo actualizar la lista")
                }
                if (adultDialog?.isShowing == true) render()
            }
        }

        search.doAfterTextChanged { limit = 80; render() }
        fillChips()
        render()
        val d = showDlg(
            AlertDialog.Builder(this)
                .setTitle("Adultos XXX 🔞")
                .setView(root)
                .setPositiveButton("Actualizar", null)
                .setNegativeButton("Cerrar", null)
                .setOnDismissListener { adultDialog = null }
        )
        adultDialog = d
        d.getButton(AlertDialog.BUTTON_POSITIVE)?.setOnClickListener { refresh() }
        refresh()
    }

    // ------------------------------------------------------------------ Películas (guía de LocoPelis)

    private lateinit var movieCard: View
    private lateinit var movieStore: MovieStore
    private lateinit var movieProgress: MovieProgress
    private var currentMovie: Movie? = null
    private var movieStartMs = 0L
    private var movieListRefresh: (() -> Unit)? = null

    private fun fmtTime(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val mi = (s % 3600) / 60
        val se = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, mi, se) else String.format("%02d:%02d", mi, se)
    }

    /** Guarda en qué minuto va la película (o la quita si ya casi termina). */
    private fun saveMovieProgress(pos: Long, dur: Long) {
        val mv = currentMovie ?: return
        if (dur <= 0) return
        if (dur - pos < 120_000 || pos > dur * 0.95) {
            movieProgress.remove(mv.url)
        } else if (pos >= 20_000) {
            movieProgress.save(mv, pos, dur)
        }
    }

    private val progressTick = object : Runnable {
        override fun run() {
            if (pc.isOpen && currentMovie != null) {
                saveMovieProgress(pc.positionMs(), pc.durationMs())
                home.postDelayed(this, 10_000)
            }
        }
    }
    private var movieDialog: MovieOverlay? = null

    /** La lista de películas se dibuja encima de la actividad (ocupa TODA la pantalla, sin huecos). */
    private inner class MovieOverlay(val view: View) {
        val isShowing: Boolean get() = view.parent != null
        fun dismiss() {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(view.windowToken, 0)
            (view.parent as? ViewGroup)?.removeView(view)
            if (movieDialog === this) movieDialog = null
        }
    }
    private var moviesReturn = false

    /** Catálogo activo: 1 = LocoPelis, 2 = RePelis24. */
    private var movieSource = 1

    /** Al tocar Películas: elegir Catálogo 1 o Catálogo 2. */
    private fun chooseCatalog() {
        val names = arrayOf("Catálogo 1", "Catálogo 2")
        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Películas 🎬")
                .setItems(names) { _, which ->
                    movieSource = which + 1
                    movieSnap = null
                    showMovies()
                }
                .setNegativeButton("Cerrar", null)
        )
    }

    private class MovieSnap(val feedKey: String, val items: List<Movie>, val page: Int, val canMore: Boolean, val src: Int = 1)
    private var movieSnap: MovieSnap? = null
    private val movieDetails = HashMap<String, MovieDetail>()

    /** Esquinas redondeadas para carátulas. */
    /** Muestra [url] a pantalla completa sobre fondo negro, con una X para cerrar. */
    private fun showImagePreview(url: String) {
        if (url.isEmpty()) return
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        root.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        MovieImages.load(url, iv)

        val d = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        d.setContentView(root)

        val close = TextView(this)
        close.text = "✕"
        close.setTextColor(Color.WHITE)
        close.textSize = 24f
        close.setTypeface(close.typeface, Typeface.BOLD)
        close.setBackgroundResource(R.drawable.bg_circle_dark)
        close.gravity = Gravity.CENTER
        val cs = dp(44)
        root.addView(close, FrameLayout.LayoutParams(cs, cs, Gravity.TOP or Gravity.END).apply {
            topMargin = dp(16); marginEnd = dp(16)
        })
        close.setOnClickListener { d.dismiss() }
        root.setOnClickListener { d.dismiss() }
        d.show()
    }

    private fun roundView(v: View, radiusDp: Int) {
        val r = dp(radiusDp).toFloat()
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: android.graphics.Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        v.clipToOutline = true
    }

    /**
     * Guía de películas: cuadrícula de carátulas con buscador y listas (Inicio, Últimas, Más vistas y categorías).
     * Al tocar una carátula se ve la sinopsis, el reparto y demás datos; "Abrir página" abre la película en la app.
     */
    private fun showMovies(restore: Boolean = false) {
        movieDialog?.dismiss()
        val a = accent
        val dim = Color.parseColor("#8FBF86")
        val src = movieSource
        val feeds = MovieFeeds.listFor(src)
        val srcName = MovieFeeds.nameFor(src)
        var feed = feeds.first { it.key != "resume" }
        var page = 1
        var loading = false
        var canMore = false
        var gen = 0
        var forceFirst = false
        var activeSearch = ""
        var suppressWatch = false
        val searchHandler = Handler(Looper.getMainLooper())
        val items = ArrayList<Movie>()
        val snap = if (restore) movieSnap?.takeIf { it.src == src } else null
        if (snap != null) {
            feed = feeds.firstOrNull { it.key == snap.feedKey } ?: feed
            if (feed.key == "resume") items.addAll(movieProgress.all().map { it.movie }) else items.addAll(snap.items)
            page = snap.page
            canMore = snap.canMore
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(4), dp(12), 0)
        val search = styledEdit("Buscar película…", "")
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        val chipsScroll = HorizontalScrollView(this)
        chipsScroll.isHorizontalScrollBarEnabled = false
        chipsScroll.addView(chips)
        val status = TextView(this)
        status.setTextColor(dim)
        status.textSize = 12f
        status.setPadding(0, dp(8), 0, dp(4))
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(this)
        scroll.addView(grid)
        root.addView(search)
        root.addView(chipsScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        root.addView(status)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val cols = 3

        var render: () -> Unit = { }
        var load: (Boolean) -> Unit = { }
        var fillChips: () -> Unit = { }
        var checkMore: () -> Unit = { }

        fun chip(f: MovieFeed): View {
            val sel = f.key == feed.key
            val t = TextView(this)
            t.text = f.label
            t.textSize = 12f
            t.setTypeface(t.typeface, Typeface.BOLD)
            t.setTextColor(if (sel) Color.BLACK else a)
            t.background = if (sel) Ui.filled(a, dp(14).toFloat()) else Ui.outline(Color.TRANSPARENT, a, dp(1), dp(14).toFloat())
            t.setPadding(dp(12), dp(6), dp(12), dp(6))
            t.isClickable = true
            t.setOnClickListener {
                if (f.key != feed.key || activeSearch.isNotEmpty()) {
                    searchHandler.removeCallbacksAndMessages(null)
                    if (activeSearch.isNotEmpty()) {
                        activeSearch = ""
                        suppressWatch = true
                        search.setText("")
                        suppressWatch = false
                    }
                    feed = f
                    gen++
                    loading = false
                    canMore = false
                    page = 1
                    items.clear()
                    fillChips()
                    render()
                    load(true)
                }
            }
            return t
        }

        fillChips = {
            chips.removeAllViews()
            feeds.forEach { f ->
                chips.addView(chip(f), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(6) })
            }
        }

        checkMore = {
            val child = scroll.getChildAt(0)
            if (child != null && canMore && !loading && items.isNotEmpty() &&
                child.bottom - (scroll.height + scroll.scrollY) < dp(700)
            ) load(false)
        }
        scroll.setOnScrollChangeListener { _, _, _, _, _ -> checkMore() }

        render = {
            if (items.isNotEmpty() && activeSearch.isEmpty()) movieSnap = MovieSnap(feed.key, ArrayList(items), page, canMore, src)
            grid.removeAllViews()
            val searching = activeSearch.isNotEmpty()
            val list: List<Movie> = items
            val resumeMap = if (feed.key == "resume" && !searching) movieProgress.all().associateBy { it.movie.url } else emptyMap()
            status.text = when {
                feed.key == "resume" && !searching && items.isEmpty() ->
                    "Aquí aparecen las películas que dejes a medias o guardes con «Ver más tarde»."
                feed.key == "resume" && !searching -> "${items.size} para continuar  •  toca una carátula"
                searching && loading && items.isEmpty() -> "Buscando “$activeSearch” en $srcName…"
                searching && items.isEmpty() -> "Sin resultados para “$activeSearch”"
                searching -> "${items.size} resultado" + (if (items.size == 1) "" else "s") + " en $srcName"
                loading && items.isEmpty() -> "Cargando películas…"
                items.isEmpty() -> "No se pudieron cargar. Toca Actualizar."
                loading -> "Actualizando…"
                else -> "${items.size} películas  •  toca una carátula"
            }
            var i = 0
            while (i < list.size) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                for (c in 0 until cols) {
                    val m = list.getOrNull(i + c)
                    val cell = LinearLayout(this)
                    cell.orientation = LinearLayout.VERTICAL
                    cell.setPadding(dp(3), dp(4), dp(3), dp(6))
                    if (m != null) {
                        val iv = PosterView(this)
                        iv.scaleType = ImageView.ScaleType.CENTER_CROP
                        iv.setBackgroundColor(Color.parseColor("#1A1A1A"))
                        roundView(iv, 10)
                        MovieImages.load(m.cover, iv)
                        val tt = TextView(this)
                        tt.text = m.title
                        tt.setTextColor(Color.WHITE)
                        tt.textSize = 11f
                        tt.maxLines = 2
                        tt.ellipsize = TextUtils.TruncateAt.END
                        tt.setPadding(0, dp(4), 0, 0)
                        val sub = TextView(this)
                        val ent2 = resumeMap[m.url]
                        sub.text = when {
                            ent2 != null && ent2.posMs > 0 -> "Minuto " + fmtTime(ent2.posMs)
                            ent2 != null -> "Ver más tarde"
                            else -> listOf(m.year, m.quality).filter { it.isNotEmpty() }.joinToString("  •  ")
                        }
                        sub.setTextColor(dim)
                        sub.textSize = 10f
                        cell.addView(iv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                        val ent = resumeMap[m.url]
                        if (ent != null) {
                            if (ent.posMs > 0 && ent.durMs > 0) {
                                val pbar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
                                pbar.max = 1000
                                pbar.progress = (ent.posMs * 1000 / ent.durMs).toInt().coerceIn(0, 1000)
                                pbar.progressTintList = android.content.res.ColorStateList.valueOf(a)
                                cell.addView(pbar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4)).apply { topMargin = dp(3) })
                            }
                        }
                        cell.addView(tt)
                        cell.addView(sub)
                        cell.isClickable = true
                        cell.setOnClickListener {
                            val en = resumeMap[m.url]
                            if (en != null) showResumeChoice(en) else showMovieDetail(m)
                        }
                    }
                    row.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                }
                grid.addView(row)
                i += cols
            }
            if (canMore && items.isNotEmpty()) {
                // Sin botón: al llegar al final se cargan solas las siguientes. Solo un girito mientras baja.
                val pb = ProgressBar(this)
                pb.isIndeterminate = true
                pb.indeterminateTintList = android.content.res.ColorStateList.valueOf(a)
                pb.visibility = if (loading) View.VISIBLE else View.INVISIBLE
                grid.addView(pb, LinearLayout.LayoutParams(dp(28), dp(28)).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                    topMargin = dp(14)
                    bottomMargin = dp(14)
                })
            }
            scroll.post { checkMore() }
        }

        load = { reset ->
            if (feed.key == "resume" && activeSearch.isEmpty()) {
                gen++
                loading = false
                canMore = false
                items.clear()
                items.addAll(movieProgress.all().map { it.movie })
                render()
            } else {
            if (reset) {
                gen++
                loading = false
                // Cada vez arranca en una página al azar para que salgan películas distintas.
                page = if (feed.paged && !forceFirst && activeSearch.isEmpty()) (1..12).random() else 1
                forceFirst = false
            }
            if (!loading) {
                loading = true
                val g = gen
                val f = if (activeSearch.isNotEmpty()) MovieFeeds.searchFor(src, activeSearch) else feed
                val p = page
                render()
                MovieFetcher(this).fetchPage(f.urlFor(p)) { res ->
                    if (g == gen) {
                        loading = false
                        if (reset && p > 1 && res.isNullOrEmpty() && activeSearch.isEmpty()) {
                            // Esa página al azar no existe: se empieza por la primera.
                            forceFirst = true
                            load(true)
                            return@fetchPage
                        }
                        if (res == null) {
                            if (p > 1) canMore = false
                            else {
                                if (items.isEmpty() && f.key != "search") items.addAll(movieStore.cached(f.key))
                                if (movieDialog?.isShowing == true) toast("No se pudo actualizar las películas")
                            }
                        } else {
                            if (reset) items.clear()
                            val known = items.map { it.id }.toSet()
                            val fresh = (if (!f.paged) res.shuffled() else res).filter { it.id !in known }
                                .map { if (it.genre.isEmpty() && f.genre.isNotEmpty()) it.copy(genre = f.genre) else it }
                            if (fresh.isEmpty()) {
                                canMore = false
                            } else {
                                items.addAll(fresh)
                                canMore = f.paged
                                if (p == 1 && f.key != "search") movieStore.save(f.key, items)
                                page = p + 1
                            }
                        }
                        if (movieDialog?.isShowing == true) render()
                    }
                }
            }
            }
        }

        fillChips()
        search.doAfterTextChanged {
            if (suppressWatch) return@doAfterTextChanged
            val q = search.text.toString().trim()
            searchHandler.removeCallbacksAndMessages(null)
            searchHandler.postDelayed({
                if (q == activeSearch) return@postDelayed
                if (q.length >= 2) {
                    // Busca en el catálogo activo en segundo plano.
                    activeSearch = q
                    items.clear()
                    canMore = false
                    forceFirst = true
                    load(true)
                } else if (activeSearch.isNotEmpty()) {
                    // Borró la búsqueda: vuelve a la lista normal.
                    activeSearch = ""
                    items.clear()
                    canMore = false
                    load(true)
                }
            }, 700)
        }
        render()
        // Pantalla completa: barra de título con Actualizar / Cerrar y la lista ocupa el resto.
        val full = LinearLayout(this)
        full.orientation = LinearLayout.VERTICAL
        full.setBackgroundColor(Color.BLACK)
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(16), dp(14), dp(8), dp(4))
        val ttl = TextView(this)
        ttl.text = "Películas 🎬"
        ttl.setTextColor(Color.WHITE)
        ttl.textSize = 22f
        ttl.setTypeface(ttl.typeface, Typeface.BOLD)
        bar.addView(ttl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fun barBtn(label: String, onClick: () -> Unit): TextView {
            val b = TextView(this)
            b.text = label
            b.setTextColor(a)
            b.textSize = 13f
            b.setTypeface(b.typeface, Typeface.BOLD)
            b.setPadding(dp(12), dp(10), dp(12), dp(10))
            b.isClickable = true
            b.setOnClickListener { onClick() }
            return b
        }
        val d = MovieOverlay(full)
        bar.addView(barBtn("ACTUALIZAR") { load(true) })
        bar.addView(barBtn("CERRAR") { d.dismiss() })
        full.addView(bar)
        full.addView(root, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        full.isClickable = true
        findViewById<ViewGroup>(android.R.id.content).addView(
            full, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        movieDialog = d
        movieListRefresh = { if (feed.key == "resume") load(true) }
        if (snap == null) load(true)
    }

    /** Al tocar una película de "Seguir viendo": continuar, empezar de cero, ver la ficha o quitarla. */
    private fun showResumeChoice(e: MovieProgress.Entry) {
        val opts = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (e.posMs > 0) {
            opts.add("▶  Continuar desde el minuto " + fmtTime(e.posMs))
            acts.add { playMovie(e.movie, e.posMs) }
        }
        opts.add(if (e.posMs > 0) "↺  Ver desde el inicio" else "▶  Ver ahora")
        acts.add { playMovie(e.movie, 0L) }
        opts.add("ℹ  Ver ficha")
        acts.add { showMovieDetail(e.movie) }
        opts.add("✕  Quitar de la lista")
        acts.add {
            movieProgress.remove(e.movie.url)
            if (movieDialog?.isShowing == true) movieListRefresh?.invoke()
        }
        showDlg(
            AlertDialog.Builder(this)
                .setTitle(e.movie.title)
                .setItems(opts.toTypedArray()) { _, which -> acts[which]() }
                .setNegativeButton("Cerrar", null)
        )
    }

    /** Reproduce una película: el video se ve horizontal y al salir se regresa a la lista, en vertical. */
    private fun openMoviePlayer(url: String, referer: String, title: String, mv: Movie) {
        lastWatch.save("movie", title, mv.url)
        currentMovie = mv
        pc.startPositionMs = movieStartMs
        movieStartMs = 0L
        home.removeCallbacks(progressTick)
        home.postDelayed(progressTick, 10_000)
        moviesReturn = true
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        openPlayer(url, referer, title)
    }

    private var movieSeq = 0
    private var movieResolver: StreamResolver? = null
    private var movieResolveDialog: AlertDialog? = null

    /**
     * Botón "Ver": abre la página de la película en un WebView invisible, saca los reproductores (Opción 1, 2…),
     * busca en cada uno la señal (.m3u8 / .mpd / .mp4) y la reproduce directo en ExoPlayer, sin mostrar la web.
     * Si no encuentra nada, abre la página de la película como antes.
     */
    private fun playMovie(m: Movie, startMs: Long = 0L) {
        if (pc.isOpen) return
        movieStartMs = startMs
        // La lista a la que se regresa es la del catálogo de esta película.
        movieSource = if (MovieFetcher.isR24(m.url)) 2 else 1
        movieResolver?.cancel()
        movieResolver = null
        movieResolveDialog?.dismiss()
        val seq = ++movieSeq
        val ua = webView.settings.userAgentString

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(8), dp(24), dp(4))
        val msg = TextView(this)
        msg.text = m.title
        msg.setTextColor(Color.WHITE)
        msg.textSize = 16f
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        bar.isIndeterminate = true
        bar.progressTintList = ColorStateList.valueOf(accent)
        bar.indeterminateTintList = ColorStateList.valueOf(accent)
        bar.progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#333333"))
        box.addView(msg)
        box.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(14) })

        val dlg = showDlg(
            AlertDialog.Builder(this)
                .setTitle("Buscando reproductor…")
                .setView(box)
                .setNegativeButton("Cancelar") { _, _ ->
                    movieSeq++
                    movieResolver?.cancel()
                    movieResolver = null
                }
        )
        movieResolveDialog = dlg

        val ref = if (MovieFetcher.isR24(m.url)) "https://repelis24.shop/" else "https://www.locopelis.com/"

        fun fail() {
            if (seq != movieSeq) return
            dlg.dismiss()
            movieResolveDialog = null
            movieDialog?.dismiss()
            toast("No se encontró la señal de esta película. Prueba con otra o inténtalo más tarde.")
        }

        fun success(found: ResolvedStream) {
            Handler(Looper.getMainLooper()).postDelayed({
                if (seq != movieSeq) return@postDelayed
                val still = dlg.isShowing
                dlg.dismiss()
                movieResolveDialog = null
                if (still && !isFinishing) {
                    movieDialog?.dismiss()
                    openMoviePlayer(found.url, found.referer, m.title, m)
                }
            }, 250)
        }

        fun tryEmbeds(list: List<String>, i: Int) {
            if (seq != movieSeq) return
            if (i >= list.size) {
                // Ninguno dio señal sola: probablemente piden verificación. Se muestra el primero a la vista.
                if (seq != movieSeq) return
                dlg.dismiss()
                movieResolveDialog = null
                showMovieVerify(m, list, 0, seq)
                return
            }
            if (dlg.isShowing) {
                bar.isIndeterminate = false
                bar.progress = 0
                dlg.setTitle("Cargando señal… 0%")
            }
            val r = StreamResolver(this, ua)
            movieResolver = r
            r.onProgress = { p ->
                if (seq == movieSeq && dlg.isShowing) {
                    dlg.setTitle("Cargando señal… $p%")
                    bar.progress = p
                }
            }
            // La página pide "verificar que eres humano": se muestra a la vista para que la toques.
            r.onNeedsUser = {
                if (seq == movieSeq) {
                    r.cancel()
                    movieResolver = null
                    dlg.dismiss()
                    movieResolveDialog = null
                    showMovieVerify(m, list, i, seq)
                }
            }
            r.resolve(list[i], ref) { found ->
                if (seq != movieSeq) return@resolve
                movieResolver = null
                if (found != null) success(found) else tryEmbeds(list, i + 1)
            }
        }

        MovieFetcher(this).fetchEmbeds(m.url) { embeds ->
            if (seq != movieSeq) return@fetchEmbeds
            if (embeds.isNullOrEmpty()) fail() else tryEmbeds(embeds, 0)
        }
    }

    /**
     * Pantalla completa con el reproductor VISIBLE para pasar la verificación ("haz clic para verificar que eres humano")
     * y tocar play. La app sigue escuchando: en cuanto la página pide el video, cierra esto y lo abre en ExoPlayer.
     * Arriba se puede cambiar entre Opción 1, 2, 3.
     */
    private fun showMovieVerify(m: Movie, embeds: List<String>, start: Int, seq: Int) {
        val ua = webView.settings.userAgentString
        val a = accent
        val ref = if (MovieFetcher.isR24(m.url)) "https://repelis24.shop/" else "https://www.locopelis.com/"
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)

        val hint = TextView(this)
        hint.text = "Toca ▶ en el reproductor para verificar. La película se abrirá sola. (Atrás para salir)"
        hint.setTextColor(Color.WHITE)
        hint.textSize = 14f
        hint.setPadding(dp(12), dp(10), dp(12), dp(4))
        root.addView(hint)

        val chipsRow = LinearLayout(this)
        chipsRow.orientation = LinearLayout.HORIZONTAL
        chipsRow.setPadding(dp(8), dp(4), dp(8), dp(6))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chipsRow)
        root.addView(hs)
        if (embeds.size < 2) hs.visibility = View.GONE

        val holder = FrameLayout(this)
        root.addView(holder, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val d = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        d.setContentView(root)
        var cur: StreamResolver? = null
        val chips = ArrayList<TextView>()

        fun load(i: Int) {
            cur?.cancel()
            holder.removeAllViews()
            chips.forEachIndexed { k, c -> c.alpha = if (k == i) 1f else 0.55f }
            val r = StreamResolver(this, ua, manual = true)
            cur = r
            r.resolve(embeds[i], ref, holder) { found ->
                if (seq != movieSeq || cur !== r) return@resolve
                if (found != null) {
                    d.dismiss()
                    movieDialog?.dismiss()
                    openMoviePlayer(found.url, found.referer, m.title, m)
                } else {
                    toast("No apareció la señal. Prueba la otra opción.")
                }
            }
        }

        embeds.forEachIndexed { i, _ ->
            val c = TextView(this, null, 0, R.style.EtvChip)
            c.text = "Opción ${i + 1}"
            c.setOnClickListener { load(i) }
            chips.add(c)
            chipsRow.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(8) })
        }
        d.setOnCancelListener { movieSeq++ }
        d.setOnDismissListener { cur?.cancel() }
        d.show()
        load(start.coerceIn(0, embeds.size - 1))
    }

    /** Ficha de una película: carátula, datos, sinopsis completa y reparto (se baja de su página). */
    private fun showMovieDetail(m: Movie) {
        var detailDlg: AlertDialog? = null
        val a = accent
        val dim = Color.parseColor("#8FBF86")

        fun line(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
            val t = TextView(this)
            t.text = text
            t.textSize = size
            t.setTextColor(color)
            if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
            t.setPadding(0, 0, 0, dp(4))
            return t
        }

        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), dp(8))
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        val poster = ImageView(this)
        poster.scaleType = ImageView.ScaleType.CENTER_CROP
        poster.setBackgroundColor(Color.parseColor("#1A1A1A"))
        roundView(poster, 12)
        MovieImages.load(m.cover, poster)
        poster.isClickable = true
        poster.isFocusable = true
        poster.setOnClickListener { showImagePreview(m.cover) }

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        val tvTitle = line(m.title, 18f, Color.WHITE, true)
        val tvAlt = line("", 12f, dim)
        val tvMeta = line(listOf(m.year, m.genre).filter { it.isNotEmpty() }.joinToString("  •  "), 13f, a)
        val tvQ = line(listOf(m.quality, m.lang).filter { it.isNotEmpty() }.joinToString("  •  "), 12f, dim)
        val tvDir = line("", 12f, dim)
        tvAlt.visibility = View.GONE
        tvDir.visibility = View.GONE
        listOf(tvTitle, tvAlt, tvMeta, tvQ, tvDir).forEach { info.addView(it) }
        top.addView(poster, LinearLayout.LayoutParams(dp(120), dp(180)))
        top.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(14) })

        val tvSyn = TextView(this)
        tvSyn.setTextColor(Color.parseColor("#DDDDDD"))
        tvSyn.textSize = 14f
        tvSyn.setLineSpacing(dp(2).toFloat(), 1f)
        tvSyn.setPadding(0, dp(14), 0, 0)
        tvSyn.text = m.synopsis.ifEmpty { "Cargando sinopsis…" }
        val tvCast = line("", 12f, dim)
        tvCast.setPadding(0, dp(12), 0, dp(4))
        tvCast.visibility = View.GONE

        col.addView(top)
        val btnWatch = TextView(this)
        btnWatch.text = "▶  Ver"
        btnWatch.textSize = 16f
        btnWatch.setTypeface(btnWatch.typeface, Typeface.BOLD)
        btnWatch.setTextColor(Color.BLACK)
        btnWatch.gravity = Gravity.CENTER
        btnWatch.background = Ui.filled(a, dp(22).toFloat())
        btnWatch.setPadding(0, dp(12), 0, dp(12))
        btnWatch.isClickable = true
        col.addView(btnWatch, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(14) })
        val prog = movieProgress.get(m.url)
        fun extraBtn(label: String, onClick: () -> Unit) {
            val b = TextView(this)
            b.text = label
            b.textSize = 14f
            b.setTypeface(b.typeface, Typeface.BOLD)
            b.setTextColor(a)
            b.gravity = Gravity.CENTER
            b.background = Ui.outline(Color.TRANSPARENT, a, dp(1), dp(22).toFloat())
            b.setPadding(0, dp(10), 0, dp(10))
            b.isClickable = true
            b.setOnClickListener { onClick() }
            col.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        }
        if (prog != null && prog.posMs > 0) {
            extraBtn("⏵  Continuar desde el minuto " + fmtTime(prog.posMs)) {
                detailDlg?.dismiss()
                playMovie(m, prog.posMs)
            }
        }
        if (prog == null) {
            extraBtn("＋  Ver más tarde") {
                movieProgress.save(m, 0L, 0L)
                toast("Guardada en «Seguir viendo»")
                detailDlg?.dismiss()
                if (movieDialog?.isShowing == true) movieListRefresh?.invoke()
            }
        } else {
            extraBtn("✕  Quitar de «Seguir viendo»") {
                movieProgress.remove(m.url)
                toast("Quitada de la lista")
                detailDlg?.dismiss()
                if (movieDialog?.isShowing == true) movieListRefresh?.invoke()
            }
        }
        col.addView(tvSyn)
        col.addView(tvCast)
        sv.addView(col)

        val d = showDlg(
            AlertDialog.Builder(this)
                .setView(sv)
                .setNegativeButton("Cerrar", null)
        )

        detailDlg = d
        btnWatch.setOnClickListener {
            d.dismiss()
            playMovie(m)
        }

        fun fill(det: MovieDetail) {
            if (det.synopsis.isNotEmpty()) tvSyn.text = det.synopsis
            if (det.alt.isNotEmpty()) {
                tvAlt.text = "Título original: " + det.alt
                tvAlt.visibility = View.VISIBLE
            }
            if (det.director.isNotEmpty()) {
                tvDir.text = "Director: " + det.director
                tvDir.visibility = View.VISIBLE
            }
            if (det.cast.isNotEmpty()) {
                tvCast.text = "Reparto: " + det.cast.joinToString(", ")
                tvCast.visibility = View.VISIBLE
            }
            if (det.poster.isNotEmpty()) MovieImages.load(det.poster, poster)
        }

        val cached = movieDetails[m.url]
        if (cached != null) {
            fill(cached)
        } else {
            MovieFetcher(this).fetchDetail(m.url) { det ->
                if (det != null) {
                    movieDetails[m.url] = det
                    if (d.isShowing) fill(det)
                } else if (d.isShowing && m.synopsis.isEmpty()) {
                    tvSyn.text = "No se pudo cargar la sinopsis."
                }
            }
        }
    }

    // ------------------------------------------------------------------ Agenda (eventos de Rústico TV)

    private fun hhmm(t: Long): String = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(t))

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAgendaIntent(intent)
    }

    /** Si se abrió desde la notificación de un partido, muestra la Agenda. */
    private fun handleAgendaIntent(i: Intent?) {
        val ii = i ?: return
        if (!ii.getBooleanExtra(ReminderStore.EXTRA_OPEN_AGENDA, false)) return
        ii.removeExtra(ReminderStore.EXTRA_OPEN_AGENDA)
        window.decorView.postDelayed({
            if (!isFinishing) showAgenda(fromPlayer = pc.isOpen)
        }, 400)
    }

    private val LIVE_WINDOW_MS = 2 * 3_600_000L + 45 * 60_000L // ~2h45 (partido + entretiempo + alargue)

    /** Convierte "8:45 PM" / "20:45" en la fecha de hoy (el "día de fútbol" empieza a las 05:00). */
    private fun eventEpoch(ev: AgendaEvent): Long? {
        val m = Regex("(\\d{1,2}):(\\d{2})\\s*([AaPp])?").find(ev.time) ?: return null
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].toInt()
        if (m.groupValues[3].isNotEmpty()) {
            h %= 12
            if (m.groupValues[3].lowercase() == "p") h += 12
        }
        val minutesOfDay = h * 60 + min
        val cal = java.util.Calendar.getInstance()
        if (cal.get(java.util.Calendar.HOUR_OF_DAY) < 5) cal.add(java.util.Calendar.DAY_OF_YEAR, -1)
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        if (minutesOfDay < 300) cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
        cal.add(java.util.Calendar.MINUTE, minutesOfDay)
        return cal.timeInMillis
    }

    /** Marcador del evento (si ESPN lo trae). Se guarda en memoria para no repetir la búsqueda. */
    private fun scoreOf(ev: AgendaEvent): ScoreFetcher.Match? {
        val key = ev.title + "|" + ev.time
        if (scoreMemo.containsKey(key)) return scoreMemo[key]
        val m = if (scoreCache.isEmpty()) null else ScoreFetcher.find(scoreCache, ev.title, eventEpoch(ev))
        scoreMemo[key] = m
        return m
    }

    /** Un evento terminado se quita de la Agenda 2 horas después de que termina. */
    private val EXPIRE_AFTER_MS = 2 * 3_600_000L

    private fun isExpired(ev: AgendaEvent): Boolean {
        val epoch = eventEpoch(ev) ?: return false
        return matchStatus(ev) == 2 && System.currentTimeMillis() > epoch + LIVE_WINDOW_MS + EXPIRE_AFTER_MS
    }

    /** 0 = en vivo ahora, 1 = todavía no empieza, 2 = terminado, 3 = sin hora reconocible. */
    private fun matchStatus(ev: AgendaEvent): Int {
        val epoch = eventEpoch(ev) ?: return 3
        val now = System.currentTimeMillis()
        val st = scoreOf(ev)?.score?.state
        // El marcador manda cuando es coherente con la hora (evita datos viejos).
        if (st == "post" && now > epoch) return 2
        if (st == "in" && now >= epoch && now < epoch + LIVE_WINDOW_MS + 3_600_000L) return 0
        return when {
            now in epoch until (epoch + LIVE_WINDOW_MS) -> 0
            now < epoch -> 1
            else -> 2
        }
    }

    /** Baja los marcadores (ESPN) en segundo plano y vuelve a dibujar la Agenda si está abierta. */
    private fun refreshScores(force: Boolean = false) {
        if (scoresLoading) return
        if (!force && System.currentTimeMillis() - scoresFetchedAt < 3 * 60_000L) return
        scoresLoading = true
        Thread {
            val sc = try { ScoreFetcher.fetch() } catch (e: Exception) { null }
            runOnUiThread {
                scoresLoading = false
                scoresFetchedAt = System.currentTimeMillis()
                if (sc != null) {
                    scoreStore.save(sc)
                    scoreCache = sc
                    scoreMemo.clear()
                }
                agendaRerender?.invoke()
            }
        }.start()
    }

    /** Campana de un partido: marca o quita el aviso de 10 minutos antes. */
    private fun toggleReminder(ev: AgendaEvent, after: () -> Unit) {
        val key = ReminderStore.keyOf(ev.title)
        if (reminders.has(key)) {
            reminders.remove(key)
            toast("🔕 Aviso quitado")
            after()
            return
        }
        val epoch = eventEpoch(ev)
        if (epoch == null) { toast("Este evento no tiene hora"); return }
        if (epoch <= System.currentTimeMillis()) { toast("Ese partido ya empezó"); return }
        askNotifPermission()
        reminders.add(Reminder(key, ev.title.replace(AgendaFetcher.OPC2, "").trim(), ev.time, epoch))
        val at = epoch - ReminderStore.LEAD_MS
        toast(if (at > System.currentTimeMillis()) "🔔 Te aviso a las ${hhmm(at)} (10 min antes)" else "🔔 Empieza en menos de 10 min: te aviso ya")
        after()
        if (!reminders.canExact() && !exactAskedThisSession) {
            exactAskedThisSession = true
            showDlg(
                AlertDialog.Builder(this)
                    .setTitle("Para que avise justo a tiempo")
                    .setMessage("Activa \"Alarmas y recordatorios\" para Esteban TV. Sin eso el aviso puede llegar con unos minutos de retraso.")
                    .setPositiveButton("Abrir ajustes") { _, _ ->
                        try {
                            startActivity(
                                Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                            )
                        } catch (e: Exception) { toast("No se pudo abrir los ajustes") }
                    }
                    .setNegativeButton("Ahora no", null)
            )
        }
    }

    private fun updateAgendaCardText() {
        val c = agendaStore.cached()
        val active = c?.events?.count { !isExpired(it) } ?: 0
        agendaSub.text = if (c != null && active > 0)
            "$active eventos  •  actualizada ${hhmm(c.fetchedAt)}"
        else "Los partidos de hoy, uno por uno"
    }

    /** Baja la agenda en segundo plano; si ya hay una descarga en curso, solo espera su resultado. */
    private fun fetchAgenda(done: (Agenda?) -> Unit) {
        agendaWaiters.add(done)
        if (agendaLoading) return
        agendaLoading = true
        AgendaFetcher(this).fetch { ag ->
            agendaLoading = false
            if (ag != null) {
                agendaStore.save(ag)
                updateAgendaCardText()
            }
            val ws = ArrayList(agendaWaiters)
            agendaWaiters.clear()
            ws.forEach { it(ag) }
            refreshScores()
        }
    }

    /** Lista de eventos uno por uno: busca, toca un evento y elige el canal. No hace falta abrir la web de Rústico. */
    private fun showAgenda(fromPlayer: Boolean = false) {
        agendaDialog?.dismiss()
        val a = accent
        val dim = Color.parseColor("#8FBF86")
        var data: Agenda? = agendaStore.cached()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(4), dp(16), 0)
        val tvDay = TextView(this)
        tvDay.setTextColor(dim)
        tvDay.textSize = 12f
        tvDay.setPadding(0, 0, 0, dp(4))
        val search = styledEdit("Buscar partido o liga…", "")
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(this)
        scroll.addView(list)
        root.addView(tvDay)
        root.addView(search)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380)))

        fun msg(t: String) {
            val tv = TextView(this)
            tv.text = t
            tv.setTextColor(dim)
            tv.textSize = 13f
            tv.setPadding(dp(4), dp(16), dp(4), dp(16))
            list.addView(tv)
        }

        var rerender: () -> Unit = { }

        fun row(ev: AgendaEvent): View {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(0, dp(10), 0, dp(10))
            r.isClickable = true
            val status = matchStatus(ev)
            val sc = scoreOf(ev)
            val live = status == 0
            val done = status == 2
            val chip = TextView(this)
            chip.text = when {
                live -> if (sc != null) "🔴 ${sc.goalsFirst}-${sc.goalsSecond}" else "🔴 EN VIVO"
                done -> if (sc != null) "${sc.goalsFirst} - ${sc.goalsSecond}" else "FIN"
                else -> ev.time.ifEmpty { "--:--" }
            }
            chip.setTextColor(if (live) Color.WHITE else if (done) Color.WHITE else a)
            chip.textSize = if (done && sc != null) 15f else 12f
            chip.gravity = Gravity.CENTER
            chip.setTypeface(chip.typeface, Typeface.BOLD)
            chip.background = when {
                live -> Ui.outline(Color.parseColor("#B3FF0000"), Color.parseColor("#FF3B30"), dp(1), dp(14).toFloat())
                done -> Ui.outline(Color.parseColor("#222222"), Color.parseColor("#555555"), dp(1), dp(14).toFloat())
                else -> Ui.outline(Color.TRANSPARENT, a, dp(1), dp(14).toFloat())
            }
            chip.setPadding(dp(8), dp(4), dp(8), dp(4))
            chip.minWidth = dp(78)
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            val t = TextView(this)
            t.text = ev.title
            t.setTextColor(if (done) Color.parseColor("#CCCCCC") else Color.WHITE)
            t.textSize = 14f
            t.maxLines = 3
            t.ellipsize = TextUtils.TruncateAt.END
            val sub = TextView(this)
            val nch = if (ev.channels.isEmpty()) "Aún sin canales" else "${ev.channels.size} canal" + (if (ev.channels.size == 1) "" else "es")
            sub.text = when {
                done && sc != null -> "Terminado  •  resultado final"
                done -> "Terminado  •  " + ev.time
                live && sc != null && sc.score.detail.isNotEmpty() -> sc.score.detail + "  •  " + nch
                else -> "$nch  •  toca para ver"
            }
            sub.setTextColor(dim)
            sub.textSize = 11f
            col.addView(t)
            col.addView(sub)
            val cl = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            cl.marginStart = dp(12)
            r.addView(chip)
            r.addView(col, cl)
            if (status == 1) {
                val set = reminders.has(ReminderStore.keyOf(ev.title))
                val bell = TextView(this)
                bell.text = "🔔"
                bell.textSize = 18f
                bell.gravity = Gravity.CENTER
                bell.alpha = if (set) 1f else 0.35f
                bell.background = if (set) Ui.outline(Color.TRANSPARENT, a, dp(1), 0f, oval = true) else null
                bell.setPadding(dp(8), dp(8), dp(8), dp(8))
                bell.isClickable = true
                bell.contentDescription = "Avisarme 10 minutos antes"
                bell.setOnClickListener { toggleReminder(ev) { rerender() } }
                r.addView(bell, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(4) })
            }
            r.setOnClickListener {
                if (ev.channels.isEmpty()) toast("Este evento todavía no tiene canales")
                else showAgendaChannels(ev, fromPlayer)
            }
            return r
        }

        fun render() {
            list.removeAllViews()
            val d = data
            tvDay.text = when {
                agendaLoading -> "Actualizando…"
                d != null -> (d.day.ifEmpty { "Agenda" }) + "  •  actualizada " + hhmm(d.fetchedAt)
                else -> ""
            }
            if (d == null || d.events.isEmpty()) {
                msg(if (agendaLoading) "Cargando la agenda…" else "No se pudo cargar la agenda. Toca Actualizar.")
                return
            }
            val q = search.text.toString().trim().lowercase()
            val evs = d.events.filter { !isExpired(it) && (q.isEmpty() || it.title.lowercase().contains(q)) }
            if (evs.isEmpty()) {
                msg(if (q.isEmpty()) "No hay eventos por ahora. Toca Actualizar." else "Sin resultados para \"$q\"")
                return
            }

            fun section(title: String, items: List<AgendaEvent>) {
                if (items.isEmpty()) return
                val h = TextView(this)
                h.text = title
                h.setTextColor(a)
                h.textSize = 12f
                h.setTypeface(h.typeface, Typeface.BOLD)
                h.setPadding(dp(2), dp(14), dp(2), dp(4))
                list.addView(h)
                items.forEach { ev ->
                    list.addView(row(ev))
                    val line = View(this)
                    line.setBackgroundColor(Color.parseColor("#222222"))
                    list.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
                }
            }

            val byStatus = evs.groupBy { matchStatus(it) }
            section("🔴 En vivo ahora", byStatus[0].orEmpty())
            section("🕐 Próximos", byStatus[1].orEmpty().sortedBy { eventEpoch(it) ?: Long.MAX_VALUE })
            section("✅ Terminados", byStatus[2].orEmpty().sortedByDescending { eventEpoch(it) ?: 0L })
            section("Sin hora", byStatus[3].orEmpty())
        }

        fun refresh() {
            render()
            fetchAgenda { ag ->
                if (ag != null) data = ag
                else if (agendaDialog?.isShowing == true) toast("No se pudo actualizar la agenda")
                if (agendaDialog?.isShowing == true) render()
            }
            render()
        }

        rerender = { if (agendaDialog?.isShowing == true) render() }
        agendaRerender = rerender
        search.doAfterTextChanged { render() }
        render()
        refreshScores()
        val d = showDlg(
            AlertDialog.Builder(this)
                .setTitle("Agenda Fútbol 🛰️")
                .setView(root)
                .setPositiveButton("Actualizar", null)
                .setNegativeButton("Cerrar", null)
                .setOnDismissListener { agendaDialog = null; agendaRerender = null }
        )
        agendaDialog = d
        // "Actualizar" no cierra la ventana.
        d.getButton(AlertDialog.BUTTON_POSITIVE)?.setOnClickListener { refresh() }
        val c = data
        if (c == null || System.currentTimeMillis() - c.fetchedAt > 10 * 60_000L) refresh()
    }

    /** Canales de un evento: al tocar uno se abre en la app y el aviso de ExoPlayer hace lo demás. */
    private fun showAgendaChannels(ev: AgendaEvent, fromPlayer: Boolean = false) {
        val labels = ev.channels.map { c ->
            c.name + (if (c.quality.isNotEmpty()) "  •  ${c.quality}" else "")
        }.toTypedArray()
        showDlg(
            AlertDialog.Builder(this)
                .setTitle((if (ev.time.isNotEmpty()) ev.time + "  " else "") + ev.title)
                .setItems(labels) { _, which ->
                    agendaDialog?.dismiss()
                    playAgendaChannel(ev, ev.channels[which], fromPlayer)
                }
                .setNegativeButton("Volver", null)
        )
    }

    private var streamResolver: StreamResolver? = null
    private var resolveDialog: AlertDialog? = null

    /**
     * Abre un canal de la Agenda directo en ExoPlayer: una página oculta busca la señal (.m3u8/.mpd/.mp4)
     * y se reproduce sin mostrar la web. Si no se encuentra la señal, solo se avisa "Emisión no disponible" (nunca se abre la web).
     */
    private fun playAgendaChannel(ev: AgendaEvent, ch: AgendaChannel, fromPlayer: Boolean = false) {
        if (pc.isOpen && !fromPlayer) return
        streamResolver?.cancel()
        resolveDialog?.dismiss()
        val title = ev.title + (if (ch.name.isNotEmpty()) "  •  " + ch.name else "")

        val r = StreamResolver(this, webView.settings.userAgentString)
        streamResolver = r

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(8), dp(24), dp(4))
        val msg = TextView(this)
        msg.text = title
        msg.setTextColor(Color.WHITE)
        msg.textSize = 16f
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        bar.progress = 0
        bar.progressTintList = ColorStateList.valueOf(accent)
        bar.progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#333333"))
        box.addView(msg)
        box.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(14) })

        val dlg = showDlg(
            AlertDialog.Builder(this)
                .setTitle("Cargando señal… 0%")
                .setView(box)
                .setNegativeButton("Cancelar") { _, _ ->
                    r.cancel()
                    if (streamResolver === r) streamResolver = null
                }
        )
        resolveDialog = dlg
        r.onProgress = { p ->
            if (streamResolver === r && dlg.isShowing) {
                dlg.setTitle("Cargando señal… $p%")
                bar.progress = p
            }
        }
        r.resolve(ch.url) { found ->
            if (streamResolver !== r) return@resolve
            streamResolver = null
            if (found != null) {
                // Deja ver el 100% un instante y abre (o cambia) el reproductor.
                Handler(Looper.getMainLooper()).postDelayed({
                    val still = dlg.isShowing
                    dlg.dismiss()
                    if (resolveDialog === dlg) resolveDialog = null
                    if (still && !isFinishing) {
                        lastWatch.save("agenda", title, ch.url)
                        if (fromPlayer) {
                            pc.setEventsVisible(true)
                            pc.swap(found.url, found.referer, webView.settings.userAgentString, CookieManager.getInstance().getCookie(found.url), title)
                        } else {
                            openPlayer(found.url, found.referer, title, fromAgenda = true)
                        }
                    }
                }, 250)
            } else {
                resolveDialog?.dismiss()
                resolveDialog = null
                // Sin señal: solo se avisa. La web NUNCA se abre.
                val b = AlertDialog.Builder(this)
                    .setTitle("Emisión no disponible 📡")
                    .setMessage(title + "\n\nEn este momento no hay señal para este evento. Puede que todavía no haya empezado o que el canal esté caído. Prueba con otro canal o inténtalo en unos minutos.")
                    .setNegativeButton("Cerrar", null)
                if (ev.channels.size > 1) b.setPositiveButton("Otro canal") { _, _ -> showAgendaChannels(ev, fromPlayer) }
                showDlg(b)
            }
        }
    }

    // ------------------------------------------------------------------ Fútbol (guías preinstaladas)

    private fun showFootball() {
        footDialog?.dismiss()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(8), dp(8), dp(8), dp(8))
        val scroll = ScrollView(this)
        scroll.addView(col)
        val cells = ArrayList<View>()
        FootballGuides.list.forEach { g ->
            if (icons.get(g.url) == null) icons.ensure(g.url) { if (footDialog?.isShowing == true) showFootball() }
            cells.add(makeChannelTile(g.name, icons.get(g.url), {
                footDialog?.dismiss()
                openUrl(g.url)
            }, null))
        }
        cells.chunked(3).forEach { rowCells ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            rowCells.forEach { row.addView(it) }
            repeat(3 - rowCells.size) { row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            col.addView(row)
        }
        footDialog = showDlg(
            AlertDialog.Builder(this)
                .setTitle("Páginas Fútbol opc2")
                .setView(scroll)
                .setNegativeButton("Cerrar", null)
        )
    }

    private fun makeChannelTile(
        label: String, logo: Bitmap?, onClick: () -> Unit, onLong: (() -> Unit)?, plus: Boolean = false
    ): View {
        val a = accent
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(8), dp(4), dp(8))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
            if (onLong != null) setOnLongClickListener { onLong(); true }
        }
        val box = FrameLayout(this)
        box.background = Ui.outline(
            if (logo != null) Color.WHITE else Color.parseColor("#0A0A0A"), a, dp(2), dp(14).toFloat()
        )
        box.outlineProvider = ViewOutlineProvider.BACKGROUND
        box.clipToOutline = true
        box.layoutParams = LinearLayout.LayoutParams(dp(78), dp(62))
        if (logo != null) {
            val img = ImageView(this)
            img.setImageBitmap(logo)
            img.scaleType = ImageView.ScaleType.FIT_CENTER
            img.setPadding(dp(6), dp(6), dp(6), dp(6))
            box.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            val tv = TextView(this)
            tv.text = if (plus) "+" else (label.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?")
            tv.gravity = Gravity.CENTER
            tv.setTextColor(a)
            tv.textSize = 24f
            tv.setTypeface(tv.typeface, Typeface.BOLD)
            box.addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        val name = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 12f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        }
        tile.addView(box)
        tile.addView(name)
        return tile
    }

    // ------------------------------------------------------------------ favoritos

    private fun updateFavIcon() {
        val fav = currentPageUrl.isNotEmpty() && favs.contains(currentPageUrl)
        btnFav.setImageResource(if (fav) R.drawable.ic_star else R.drawable.ic_star_border)
    }

    private fun toggleFavorite() {
        val url = currentPageUrl
        if (url.isEmpty()) {
            toast("Abre una página primero")
            return
        }
        if (favs.contains(url)) {
            favs.remove(url)
            toast("Quitado de favoritos")
            updateFavIcon()
        } else {
            askNameAndSave(cleanTitle(pageTitle).ifEmpty { suggestName(url) }, url)
        }
    }

    /** Antes de guardar, deja elegir el nombre (con una sugerencia). */
    private fun askNameAndSave(suggested: String, url: String) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val name = styledEdit("Nombre", suggested)
        name.selectAll()
        box.addView(name)
        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Guardar en favoritos")
                .setMessage(AdBlocker.host(url).removePrefix("www."))
                .setView(box)
                .setPositiveButton("Guardar") { _, _ ->
                    val n = name.text.toString().trim().ifEmpty { suggestName(url) }
                    favs.add(Fav(n, url))
                    icons.ensure(url) { refreshFavs() }
                    toast("Agregado a favoritos")
                    updateFavIcon()
                    refreshFavs()
                }
                .setNegativeButton("Cancelar", null)
        )
    }

    private fun styledEdit(hint: String, text: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(text)
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Color.parseColor("#8FBF86"))
        e.isSingleLine = true
        return e
    }

    /** "Mi página - Sitio | Otra cosa" -> "Mi página". */
    private fun cleanTitle(t: String): String {
        val first = t.split(" - ", " | ", " – ", " · ").map { it.trim() }.firstOrNull { it.length >= 2 } ?: return ""
        return if (first.length > 30) first.take(30).trim() else first
    }

    /** youtube.com -> "Youtube". */
    private fun suggestName(u: String): String {
        val t = u.trim()
        if (t.isEmpty()) return ""
        val h = AdBlocker.host(if (t.startsWith("http", true)) t else "https://$t").removePrefix("www.")
        if (h.isEmpty()) return ""
        return AdBlocker.registrable(h).substringBefore('.').replaceFirstChar { it.uppercaseChar() }
    }

    private fun refreshFavs() {
        if (!::favContainer.isInitialized) return
        favContainer.removeAllViews()
        val cells = ArrayList<View>()
        favs.all().forEach { f ->
            val icon = icons.get(f.url)
            if (icon == null && iconRequested.add(f.url)) {
                icons.ensure(f.url) { if (home.visibility == View.VISIBLE) refreshFavs() }
            }
            val letter = f.title.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
            cells.add(makeTile(f.title, icon, letter, { openUrl(f.url) }, { favMenu(f) }))
        }
        cells.add(makeTile("Agregar", null, "+", { showAddDialog() }, null))

        cells.chunked(3).forEach { rowCells ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            rowCells.forEach { row.addView(it) }
            repeat(3 - rowCells.size) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            favContainer.addView(row)
        }
    }

    private fun makeTile(
        label: String, icon: Bitmap?, letter: String, onClick: () -> Unit, onLong: (() -> Unit)?
    ): View {
        val a = accent
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(10), dp(4), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
            if (onLong != null) setOnLongClickListener { onLong(); true }
        }
        val circle = FrameLayout(this)
        circle.background = Ui.outline(
            if (icon != null) Color.WHITE else Color.parseColor("#0A0A0A"), a, dp(2), 0f, oval = true
        )
        circle.outlineProvider = ViewOutlineProvider.BACKGROUND
        circle.clipToOutline = true
        circle.layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
        if (icon != null) {
            val img = ImageView(this)
            img.setImageBitmap(icon)
            img.scaleType = ImageView.ScaleType.FIT_CENTER
            circle.addView(img, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER))
        } else {
            val tv = TextView(this)
            tv.text = letter
            tv.gravity = Gravity.CENTER
            tv.setTextColor(a)
            tv.textSize = 22f
            tv.setTypeface(tv.typeface, Typeface.BOLD)
            circle.addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        val name = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 12f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        }
        tile.addView(circle)
        tile.addView(name)
        return tile
    }

    private fun favMenu(f: Fav) {
        showDlg(
            AlertDialog.Builder(this)
                .setTitle(f.title)
                .setItems(arrayOf("Renombrar", "Eliminar")) { _, which ->
                    if (which == 0) renameFav(f) else confirmDelete(f)
                }
                .setNegativeButton("Cancelar", null)
        )
    }

    private fun renameFav(f: Fav) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val name = styledEdit("Nombre", f.title)
        name.selectAll()
        box.addView(name)
        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Renombrar")
                .setView(box)
                .setPositiveButton("Guardar") { _, _ ->
                    val n = name.text.toString().trim()
                    if (n.isNotEmpty()) {
                        favs.rename(f.url, n)
                        refreshFavs()
                    }
                }
                .setNegativeButton("Cancelar", null)
        )
    }

    private fun confirmDelete(f: Fav) {
        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Eliminar favorito")
                .setMessage(f.title)
                .setPositiveButton("Eliminar") { _, _ ->
                    favs.remove(f.url)
                    refreshFavs()
                    updateFavIcon()
                }
                .setNegativeButton("Cancelar", null)
        )
    }

    private fun showAddDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val url = styledEdit("https://ejemplo.com", "")
        url.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        val name = styledEdit("Nombre (te sugerimos uno, puedes cambiarlo)", "")
        box.addView(url)
        box.addView(name)

        var programmatic = false
        var edited = false
        name.doAfterTextChanged { if (!programmatic) edited = true }
        url.doAfterTextChanged {
            if (!edited) {
                programmatic = true
                name.setText(suggestName(it?.toString().orEmpty()))
                programmatic = false
            }
        }

        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Nueva página")
                .setView(box)
                .setPositiveButton("Guardar") { _, _ ->
                    var u = url.text.toString().trim()
                    if (u.isEmpty()) return@setPositiveButton
                    if (!u.startsWith("http", true)) u = "https://$u"
                    val n = name.text.toString().trim().ifEmpty { suggestName(u) }
                    favs.add(Fav(n, u))
                    icons.ensure(u) { refreshFavs() }
                    refreshFavs()
                }
                .setNegativeButton("Cancelar", null)
        )
    }

    // ------------------------------------------------------------------ WebView

    private fun emptyResponse() =
        WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))

    private fun injectScripts(view: WebView?) {
        if (prefs.blockAds) view?.evaluateJavascript(AdBlocker.AD_JS, null)
        if (prefs.redirMode > 0) view?.evaluateJavascript(AdBlocker.LINK_GUARD_JS, null)
        if (prefs.autoPlayer) view?.evaluateJavascript(AdBlocker.VIDEO_HOOK_JS, null)
    }

    private fun clearDeclined() {
        declinedStreams.clear()
        lastDeclineHost = ""
    }

    /** ¿El usuario ya dijo "No" a este video? Solo ese (o sus listas internas) se deja pasar a la página. */
    private fun isDeclined(url: String): Boolean {
        if (declinedStreams.isEmpty()) return false
        val plain = url.substringBefore('?').substringBefore('#')
        if (declinedStreams.keys.any { plain.startsWith(it) }) return true
        val host = AdBlocker.registrable(AdBlocker.host(url))
        return host.isNotEmpty() && host == lastDeclineHost && System.currentTimeMillis() - lastDeclineTime < 15000
    }

    /** Mensaje flotante propio (sin el ícono de Android del Toast). */
    private fun showPill(msg: String) {
        pill?.let { (it.parent as? ViewGroup)?.removeView(it) }
        val tv = TextView(this).apply {
            text = msg
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(20), dp(10), dp(20), dp(10))
            background = Ui.outline(Color.parseColor("#F2000000"), accent, dp(1), dp(22).toFloat())
            elevation = dp(8).toFloat()
            alpha = 0f
        }
        pill = tv
        val content = findViewById<ViewGroup>(android.R.id.content)
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        lp.bottomMargin = dp(56)
        content.addView(tv, lp)
        tv.animate().alpha(1f).setDuration(180).withEndAction {
            tv.animate().alpha(0f).setStartDelay(1400).setDuration(300).withEndAction {
                (tv.parent as? ViewGroup)?.removeView(tv)
                if (pill === tv) pill = null
            }.start()
        }.start()
    }

    /**
     * ¿Se permite que la página actual navegue a OTRA web?
     *  - Desde buscadores siempre.
     *  - Si el usuario tocó un enlace visible y real hacia ese destino.
     *  - Modo "2 toques": solo tras 2 toques o más en la página.
     *  - Modo "nunca": no (salvo los casos anteriores).
     */
    private fun crossSiteAllowed(url: String, request: WebResourceRequest): Boolean {
        val mode = prefs.redirMode
        if (mode == 0) return true
        if (AdBlocker.isSearchHub(AdBlocker.host(currentPageUrl))) return true
        val fresh = System.currentTimeMillis() - lastLinkTime < 2500
        val sameTarget = AdBlocker.registrable(AdBlocker.host(lastLinkHref)) ==
            AdBlocker.registrable(AdBlocker.host(url))
        if (fresh && lastLinkTrusted && sameTarget && request.hasGesture()) return true
        if (mode == 1 && request.hasGesture() && tapCount >= 2) return true
        return false
    }

    private fun blockedRedirect(url: String) {
        lastBlocked = url
        val now = System.currentTimeMillis()
        if (now - lastBlockedToast > 1500) {
            lastBlockedToast = now
            runOnUiThread { showPill("Redirección bloqueada  ✔") }
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface", "ClickableViewAccessibility")
    private fun setupWebView() {
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            allowFileAccess = false
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            // Popups: no se permiten ventanas nuevas
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
        }
        defaultUa = webView.settings.userAgentString
        applyWebSettings()

        webView.addJavascriptInterface(Bridge(), "EstebanBridge")

        // Cuenta los toques reales del usuario en la página (para la protección anti-redirección)
        webView.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x
                    downY = ev.y
                    downT = ev.eventTime
                }
                MotionEvent.ACTION_UP -> {
                    if (abs(ev.x - downX) < dp(12) && abs(ev.y - downY) < dp(12) && ev.eventTime - downT < 500) {
                        tapCount++
                    }
                }
            }
            false
        }

        webView.webViewClient = object : WebViewClient() {

            // Detección de video: mira cada petición de la página
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url.toString()
                if (prefs.blockAds && AdBlocker.isAdUrl(url)) return emptyResponse()

                if (prefs.autoPlayer && request.method == "GET" && AdBlocker.isStreamUrl(url) && !isDeclined(url)) {
                    if (!pc.isOpen && askDialog == null && System.currentTimeMillis() >= sniffCooldownUntil) {
                        val ref = currentPageUrl
                        runOnUiThread { offerPlayer(url, ref) }
                    }
                    // Evita que la página también descargue el stream
                    return emptyResponse()
                }
                return null
            }

            // Bloqueo de redirecciones, popunders y esquemas raros
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest): Boolean {
                val uri = request.url
                val url = uri.toString()
                val scheme = uri.scheme?.lowercase()

                if (scheme != "http" && scheme != "https") {
                    if (request.hasGesture() && (scheme == "tel" || scheme == "mailto")) {
                        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (e: Exception) { }
                    }
                    return true
                }
                if (prefs.blockAds && AdBlocker.isAdUrl(url)) return true

                if (request.isForMainFrame && !request.isRedirect && currentPageUrl.isNotEmpty()) {
                    val cross = AdBlocker.registrable(AdBlocker.host(url)) !=
                        AdBlocker.registrable(AdBlocker.host(currentPageUrl))
                    if (cross) {
                        if (!crossSiteAllowed(url, request)) {
                            blockedRedirect(url)
                            return true
                        }
                        tapCount = 0
                    }
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url == null || url == "about:blank") return
                if (url != currentPageUrl) clearDeclined()
                currentPageUrl = url
                pageTitle = ""
                if (!etUrl.hasFocus()) showUrlSlogan()
                updateFavIcon()
                if (prefs.blockAds) view?.evaluateJavascript(AdBlocker.AD_JS, null)
                if (prefs.redirMode > 0) view?.evaluateJavascript(AdBlocker.LINK_GUARD_JS, null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (url == "about:blank") {
                    if (clearHistoryOnBlank) {
                        view?.clearHistory()
                        clearHistoryOnBlank = false
                    }
                    return
                }
                progress.visibility = View.GONE
                if (url != null) {
                    currentPageUrl = url
                    if (!etUrl.hasFocus()) showUrlSlogan()
                    if (prefs.restoreLast && url.startsWith("http")) prefs.lastPage = url
                }
                updateFavIcon()
                injectScripts(view)
            }

            // Certificados inválidos: se permite, pero preguntando primero
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler, error: SslError?) {
                showDlg(
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Certificado no válido")
                        .setMessage("Este sitio tiene un problema de seguridad. ¿Continuar de todas formas?")
                        .setPositiveButton("Continuar") { _, _ -> handler.proceed() }
                        .setNegativeButton("Cancelar") { _, _ -> handler.cancel() }
                        .setCancelable(false)
                )
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                pageTitle = title.orEmpty()
            }

            // Logotipo de la web: se guarda para mostrarlo en favoritos
            override fun onReceivedIcon(view: WebView?, icon: Bitmap?) {
                if (icon != null && currentPageUrl.isNotEmpty()) icons.save(currentPageUrl, icon)
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customCallback = callback
                customContainer.addView(
                    view,
                    FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                )
                customContainer.visibility = View.VISIBLE
                hideSystemBars(true)
                if (prefs.rotation != 2) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }

            override fun onHideCustomView() = hideCustomView()
        }
    }

    private fun hideCustomView() {
        if (customView == null) return
        customContainer.removeAllViews()
        customContainer.visibility = View.GONE
        customCallback?.onCustomViewHidden()
        customView = null
        customCallback = null
        hideSystemBars(prefs.fullscreen)
        applyRotation()
    }

    /** Puente JS -> Kotlin: fuentes de video y clics en enlaces detectados dentro de la página. */
    inner class Bridge {
        @JavascriptInterface
        fun onSource(url: String) {
            if (!prefs.autoPlayer || !url.startsWith("http", true)) return
            if (!AdBlocker.isStreamUrl(url) || AdBlocker.isAdUrl(url) || isDeclined(url)) return
            val ref = currentPageUrl
            runOnUiThread {
                if (!pc.isOpen && askDialog == null && System.currentTimeMillis() >= sniffCooldownUntil) {
                    offerPlayer(url, ref)
                }
            }
        }

        @JavascriptInterface
        fun onLinkClick(href: String, trusted: Boolean) {
            lastLinkHref = href
            lastLinkTrusted = trusted
            lastLinkTime = System.currentTimeMillis()
        }
    }

    // ------------------------------------------------------------------ reproductor (ExoPlayer)

    /** Nombre corto del video: título de la página, o el nombre del archivo, o el sitio. */
    private fun videoName(url: String): String {
        val t = cleanTitle(pageTitle)
        if (t.isNotEmpty()) return t
        val seg = try { Uri.parse(url).lastPathSegment.orEmpty() } catch (e: Exception) { "" }
        val base = Uri.decode(seg).substringBeforeLast('.').replace('_', ' ').replace('-', ' ').trim()
        val generic = setOf("index", "master", "playlist", "manifest", "stream", "video", "chunklist", "main", "live", "hls")
        if (base.length > 3 && base.lowercase() !in generic) return base.take(40)
        return AdBlocker.host(url).removePrefix("www.")
    }

    // ------------------------------------------------------------------ descargas

    /** Una descarga en marcha (para la barra, el porcentaje y la velocidad). */
    private class ActiveDl(val name: String, val progress: VideoDownloader.Progress, val cancel: AtomicBoolean) {
        var lastBytes = 0L
        var lastTime = System.currentTimeMillis()
        var speed = 0.0   // bytes por segundo, suavizado
    }

    private val active = ArrayList<ActiveDl>()
    private val ui = Handler(Looper.getMainLooper())
    private var tickRunning = false
    private var progressRefresh: (() -> Unit)? = null
    private var listRefresh: (() -> Unit)? = null
    private var pendingDownload: Triple<Quality, String, String>? = null

    /** Cada medio segundo calcula la velocidad, avisa cuando una descarga termina y refresca las ventanas. */
    private val ticker = object : Runnable {
        override fun run() {
            val iter = active.iterator()
            while (iter.hasNext()) {
                val d = iter.next()
                val now = System.currentTimeMillis()
                val dt = now - d.lastTime
                if (dt >= 400) {
                    val inst = (d.progress.bytes - d.lastBytes) * 1000.0 / dt
                    d.speed = if (d.speed <= 0.0) inst else d.speed * 0.6 + inst * 0.4
                    d.lastBytes = d.progress.bytes
                    d.lastTime = now
                }
                if (d.progress.done) {
                    iter.remove()
                    finishDownload(d)
                }
            }
            progressRefresh?.invoke()
            listRefresh?.invoke()
            if (active.isNotEmpty()) ui.postDelayed(this, 500) else tickRunning = false
        }
    }

    private fun startTick() {
        if (!tickRunning) {
            tickRunning = true
            ui.post(ticker)
        }
    }

    private fun finishDownload(d: ActiveDl) {
        val p = d.progress
        val err = p.error
        val u = p.outputUri
        if (err != null || u == null) {
            toast("✖ " + (err ?: "No se pudo guardar el video"))
            return
        }
        dls.add(DlItem(p.outputName.ifEmpty { d.name }, u, p.mime, p.bytes, System.currentTimeMillis()))
        toast("Descarga completa ✔  Guardado en Descargas/EstebanTV")
    }

    private fun fmtSize(b: Long): String {
        val kb = b / 1024.0
        val mb = kb / 1024.0
        return when {
            b < 1024 -> "$b B"
            kb < 1024 -> String.format("%.0f KB", kb)
            mb < 1024 -> String.format("%.1f MB", mb)
            else -> String.format("%.2f GB", mb / 1024.0)
        }
    }

    private fun fmtSpeed(bps: Double): String = fmtSize(bps.toLong()) + "/s"

    private fun fmtDuration(sec: Double): String {
        if (sec <= 0) return ""
        val s = sec.toInt()
        val h = s / 3600; val m = (s % 3600) / 60; val ss = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, ss) else String.format("%d:%02d", m, ss)
    }

    private fun copyText(label: String, text: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
    }

    /** Enlace http(s) que haya en el portapapeles (o vacío). */
    private fun clipUrl(): String {
        return try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            val t = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this)?.toString().orEmpty().trim() else ""
            if (t.startsWith("http", true)) t else ""
        } catch (e: Exception) {
            ""
        }
    }

    /** Descarga rápida desde la ventana de ExoPlayer: usa MediaProbe para saber si hay varias calidades. */
    private fun downloadVideo(url: String) {
        val askedRef = currentPageUrl
        toast("Analizando video…")
        Thread {
            val qualities = try { MediaProbe.probe(url, askedRef) } catch (e: Exception) { emptyList() }
            runOnUiThread {
                if (qualities.size <= 1) {
                    val q = qualities.firstOrNull() ?: Quality("Original", 0, 0, 0, Quality.Kind.PROGRESSIVE, url, 0.0, false)
                    startDownload(q, askedRef, videoName(url))
                } else {
                    showQualityPicker(qualities, askedRef, videoName(url))
                }
            }
        }.start()
    }

    /** Pantalla "Descargar video": pega un enlace, se analizan las calidades y se elige una. */
    private fun showDownloader() {
        val a = accent
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(8), dp(24), dp(4))

        val info = TextView(this)
        info.text = "Pega el enlace del video (.mp4, .m3u8 o .mpd). Se guarda en Descargas/EstebanTV de tu celular."
        info.setTextColor(Color.parseColor("#8FBF86"))
        info.textSize = 12f
        box.addView(info)

        val input = EditText(this)
        input.hint = "https://ejemplo.com/video.m3u8"
        input.setTextColor(Color.WHITE)
        input.setHintTextColor(Color.parseColor("#8FBF86"))
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        input.isSingleLine = true
        input.setPadding(0, dp(10), 0, dp(6))
        val fromClip = clipUrl()
        if (fromClip.isNotEmpty()) {
            input.setText(fromClip)
            input.setSelection(fromClip.length)
        }
        box.addView(input)

        val paste = TextView(this)
        paste.text = "📋  Pegar enlace copiado"
        paste.setTextColor(a)
        paste.textSize = 13f
        paste.setTypeface(paste.typeface, Typeface.BOLD)
        paste.setPadding(0, dp(8), dp(12), dp(8))
        paste.isClickable = true
        paste.setOnClickListener {
            val c = clipUrl()
            if (c.isEmpty()) {
                toast("No hay ningún enlace copiado")
            } else {
                input.setText(c)
                input.setSelection(c.length)
            }
        }
        box.addView(paste)

        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Descargar video")
                .setView(box)
                .setPositiveButton("Analizar") { _, _ -> analyzeLink(input.text.toString().trim()) }
                .setNegativeButton("Cancelar", null)
        )
    }

    private fun analyzeLink(u: String) {
        if (!u.startsWith("http", true)) {
            toast("Pega un enlace que empiece con http")
            return
        }
        toast("Analizando calidades…")
        val sameSite = AdBlocker.registrable(AdBlocker.host(u)) == AdBlocker.registrable(AdBlocker.host(currentPageUrl))
        val ref = if (sameSite) currentPageUrl else ""
        Thread {
            val qualities = try { MediaProbe.probe(u, ref) } catch (e: Exception) { emptyList() }
            runOnUiThread {
                if (qualities.isEmpty()) toast("No se encontró ningún video en ese enlace")
                else showQualityPicker(qualities, ref, videoName(u))
            }
        }.start()
    }

    /** Lista de calidades detectadas: el usuario elige una y arranca la descarga. */
    private fun showQualityPicker(qualities: List<Quality>, referer: String, name: String) {
        val labels = qualities.map { q ->
            val bits = mutableListOf(q.label)
            if (q.isLive) bits.add("EN VIVO") else if (q.durationSec > 0) bits.add(fmtDuration(q.durationSec))
            if (q.kind == Quality.Kind.UNSUPPORTED) bits.add("(solo info, aún no descargable)")
            bits.joinToString("  •  ")
        }.toTypedArray()

        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Elige la calidad")
                .setItems(labels) { _, which -> startDownload(qualities[which], referer, name) }
                .setNegativeButton("Cancelar", null)
        )
    }

    /** Arranca la descarga (pide permiso de almacenamiento solo en Android 8 y 9) y abre la ventana de progreso. */
    private fun startDownload(q: Quality, referer: String, name: String) {
        if (q.isLive) { toast("Es una transmisión en vivo: no se puede descargar"); return }
        if (q.kind == Quality.Kind.UNSUPPORTED) { toast("Este formato (DASH) todavía no se puede descargar completo"); return }

        if (Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDownload = Triple(q, referer, name)
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 77)
            return
        }

        val label = if (q.height > 0) "$name ${q.height}p" else name
        val cancel = VideoDownloader.cancelFlag()
        val progress = VideoDownloader.Progress()
        val d = ActiveDl(label, progress, cancel)
        active.add(d)
        val appCtx = applicationContext
        Thread { VideoDownloader.download(appCtx, q, referer, label, cancel, progress) }.start()
        startTick()
        showProgressDialog(d)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77) {
            val p = pendingDownload
            pendingDownload = null
            if (p != null) {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startDownload(p.first, p.second, p.third)
                } else {
                    toast("Sin permiso de almacenamiento no se puede guardar en Descargas")
                }
            }
        }
    }

    /** Ventana de progreso: barra, porcentaje, tamaño, velocidad y tiempo restante. */
    private fun showProgressDialog(d: ActiveDl) {
        val a = accent
        val dim = Color.parseColor("#8FBF86")
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(12), dp(24), dp(4))

        val tvName = TextView(this)
        tvName.text = d.name
        tvName.setTextColor(Color.WHITE)
        tvName.textSize = 14f
        tvName.maxLines = 2
        tvName.ellipsize = TextUtils.TruncateAt.END

        val tvPct = TextView(this)
        tvPct.text = "0%"
        tvPct.setTextColor(a)
        tvPct.textSize = 30f
        tvPct.setTypeface(tvPct.typeface, Typeface.BOLD)
        tvPct.setPadding(0, dp(8), 0, dp(4))

        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 1000
        bar.isIndeterminate = false
        bar.progressTintList = ColorStateList.valueOf(a)
        bar.progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#2A2A2A"))

        val tvSize = TextView(this)
        tvSize.setTextColor(dim)
        tvSize.textSize = 12f
        tvSize.setPadding(0, dp(8), 0, 0)

        val tvSpeed = TextView(this)
        tvSpeed.setTextColor(Color.WHITE)
        tvSpeed.textSize = 13f
        tvSpeed.setPadding(0, dp(2), 0, dp(6))

        box.addView(tvName)
        box.addView(tvPct)
        box.addView(bar)
        box.addView(tvSize)
        box.addView(tvSpeed)

        fun refresh() {
            val p = d.progress
            if (p.percent >= 0) {
                bar.isIndeterminate = false
                bar.progress = p.percent * 10
                tvPct.text = "${p.percent}%"
            } else {
                bar.isIndeterminate = true
                tvPct.text = "…"
            }
            val total = p.totalBytes
            tvSize.text = if (total > 0) {
                fmtSize(p.bytes) + " de " + (if (p.totalEstimated) "~" else "") + fmtSize(total)
            } else {
                fmtSize(p.bytes)
            }
            val eta = if (total > 0 && d.speed > 1.0) fmtDuration((total - p.bytes) / d.speed) else ""
            tvSpeed.text = "⚡ " + fmtSpeed(d.speed) + (if (eta.isNotEmpty()) "   •   quedan $eta" else "")
        }

        val dlg = showDlg(
            AlertDialog.Builder(this)
                .setTitle("Descargando…")
                .setView(box)
                .setNeutralButton("Segundo plano", null)
                .setNegativeButton("Cancelar") { _, _ -> d.cancel.set(true) }
                .setCancelable(false)
                .setOnDismissListener { progressRefresh = null }
        )
        progressRefresh = { if (d.progress.done) dlg.dismiss() else refresh() }
        refresh()
    }

    // ------------------------------------------------------------------ Mis descargas

    private fun uriExists(u: String): Boolean = try {
        contentResolver.openFileDescriptor(Uri.parse(u), "r")?.use { true } ?: false
    } catch (e: Exception) {
        false
    }

    private fun deleteUri(u: String) {
        try {
            val uri = Uri.parse(u)
            if (uri.scheme == "file") java.io.File(uri.path ?: "").delete()
            else contentResolver.delete(uri, null, null)
        } catch (e: Exception) { /* ya no estaba */ }
    }

    private fun openDownload(item: DlItem) {
        if (!uriExists(item.uri)) {
            dls.remove(item.uri)
            toast("Ese archivo ya no existe")
            return
        }
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(Uri.parse(item.uri), item.mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast("No hay ninguna app para reproducir el video")
        }
    }

    private fun shareDownload(item: DlItem) {
        if (!uriExists(item.uri)) {
            dls.remove(item.uri)
            toast("Ese archivo ya no existe")
            return
        }
        val send = Intent(Intent.ACTION_SEND)
            .setType(item.mime)
            .putExtra(Intent.EXTRA_STREAM, Uri.parse(item.uri))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(Intent.createChooser(send, "Compartir video"))
        } catch (e: Exception) {
            toast("No se pudo compartir")
        }
    }

    private fun confirmDeleteDownload(item: DlItem, after: () -> Unit) {
        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Borrar video")
                .setMessage(item.name)
                .setPositiveButton("Borrar del celular") { _, _ ->
                    deleteUri(item.uri)
                    dls.remove(item.uri)
                    after()
                }
                .setNeutralButton("Solo quitar de la lista") { _, _ ->
                    dls.remove(item.uri)
                    after()
                }
                .setNegativeButton("Cancelar", null)
        )
    }

    /** Lista de descargas en curso (con progreso en vivo) y de videos ya guardados. */
    private fun showDownloads() {
        val a = accent
        val dim = Color.parseColor("#8FBF86")
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), dp(8))
        val scroll = ScrollView(this)
        scroll.addView(col)
        val liveRows = ArrayList<Triple<ActiveDl, ProgressBar, TextView>>()

        fun chip(label: String, onClick: () -> Unit): TextView {
            val t = TextView(this)
            t.text = label
            t.setTextColor(a)
            t.textSize = 13f
            t.setTypeface(t.typeface, Typeface.BOLD)
            t.setPadding(0, dp(8), dp(18), dp(8))
            t.isClickable = true
            t.setOnClickListener { onClick() }
            return t
        }

        fun render() {
            col.removeAllViews()
            liveRows.clear()
            val items = dls.all()
            if (active.isEmpty() && items.isEmpty()) {
                val empty = TextView(this)
                empty.text = "Aún no hay descargas.\nLos videos que descargues se guardan en la carpeta Descargas/EstebanTV de tu celular."
                empty.setTextColor(dim)
                empty.textSize = 13f
                empty.setPadding(0, dp(12), 0, dp(12))
                col.addView(empty)
                return
            }
            for (d in active) {
                val t = TextView(this)
                t.text = "⭳  " + d.name
                t.setTextColor(Color.WHITE)
                t.textSize = 14f
                t.maxLines = 1
                t.ellipsize = TextUtils.TruncateAt.END
                t.setPadding(0, dp(10), 0, dp(4))
                val b = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
                b.max = 1000
                b.progressTintList = ColorStateList.valueOf(a)
                b.progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#2A2A2A"))
                val s = TextView(this)
                s.setTextColor(dim)
                s.textSize = 12f
                s.setPadding(0, dp(4), 0, dp(2))
                col.addView(t)
                col.addView(b)
                col.addView(s)
                col.addView(chip("Cancelar") { d.cancel.set(true) })
                liveRows.add(Triple(d, b, s))
            }
            for (item in items) {
                val t = TextView(this)
                t.text = item.name
                t.setTextColor(Color.WHITE)
                t.textSize = 15f
                t.maxLines = 2
                t.ellipsize = TextUtils.TruncateAt.END
                t.setPadding(0, dp(14), 0, 0)
                val whenTxt = java.text.DateFormat
                    .getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT)
                    .format(java.util.Date(item.time))
                val meta = TextView(this)
                meta.text = fmtSize(item.size) + "  •  " + whenTxt
                meta.setTextColor(dim)
                meta.textSize = 12f
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.addView(chip("Abrir") { openDownload(item) })
                row.addView(chip("Compartir") { shareDownload(item) })
                row.addView(chip("Borrar") { confirmDeleteDownload(item) { render() } })
                col.addView(t)
                col.addView(meta)
                col.addView(row)
            }
        }

        fun refreshLive() {
            if (liveRows.any { it.first.progress.done }) {
                render()
                return
            }
            for ((d, b, s) in liveRows) {
                val p = d.progress
                if (p.percent >= 0) {
                    b.isIndeterminate = false
                    b.progress = p.percent * 10
                } else {
                    b.isIndeterminate = true
                }
                val pct = if (p.percent >= 0) "${p.percent}%  •  " else ""
                s.text = pct + fmtSize(p.bytes) + "  •  " + fmtSpeed(d.speed)
            }
        }

        render()
        refreshLive()
        listRefresh = { refreshLive() }
        showDlg(
            AlertDialog.Builder(this)
                .setTitle("Mis descargas")
                .setView(scroll)
                .setPositiveButton("Cerrar", null)
                .setOnDismissListener { listRefresh = null }
        )
    }

    /** Escribir una dirección o una búsqueda (la barra de arriba ya no se edita). */
    private fun showGoTo() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val e = styledEdit("Buscar o escribir dirección", "")
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        e.imeOptions = EditorInfo.IME_ACTION_GO
        box.addView(e)
        val d = showDlg(
            AlertDialog.Builder(this)
                .setTitle("Ir a…")
                .setView(box)
                .setPositiveButton("Ir") { _, _ -> loadInput(e.text.toString()) }
                .setNegativeButton("Cancelar", null)
        )
        e.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                loadInput(e.text.toString())
                d.dismiss()
                true
            } else {
                false
            }
        }
        e.requestFocus()
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    // ------------------------------------------------------------------ aviso de ExoPlayer

    /** Ventana Sí / No antes de abrir ExoPlayer: mini vista previa, duración, nombre, descargar y copiar enlace. */
    private fun offerPlayer(url: String, ref: String) {
        if (pc.isOpen || askDialog != null || isFinishing) return
        if (System.currentTimeMillis() < sniffCooldownUntil) return
        if (!prefs.confirmExo) {
            openPlayerWeb(url, ref)
            return
        }

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(8), dp(24), dp(4))

        val q = TextView(this)
        q.text = "Se va a ejecutar ExoPlayer. ¿Continuar?"
        q.setTextColor(Color.WHITE)
        q.textSize = 15f
        box.addView(q)

        // Mini vista previa muda y en bucle, estilo GIF, del video que se va a abrir.
        val previewFrame = FrameLayout(this)
        previewFrame.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(140))
            .apply { topMargin = dp(12) }
        previewFrame.setBackgroundColor(Color.parseColor("#0A0A0A"))
        val previewPlayer = ExoPlayer.Builder(this).build()
        val previewView = PlayerView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            useController = false
            player = previewPlayer
        }
        previewFrame.addView(previewView)

        // Etiqueta de duración o EN VIVO, esquina inferior derecha de la vista previa.
        val badge = TextView(this).apply {
            text = "…"
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(dp(8), dp(3), dp(8), dp(3))
            setBackgroundResource(R.drawable.bg_pill)
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.BOTTOM or Gravity.END
                setMargins(0, 0, dp(8), dp(8))
            }
        }
        previewFrame.addView(badge)
        box.addView(previewFrame)

        try {
            val httpFactory = DefaultHttpDataSource.Factory()
                .setUserAgent(webView.settings.userAgentString)
                .setAllowCrossProtocolRedirects(true)
                .setDefaultRequestProperties(if (ref.isNotEmpty()) mapOf("Referer" to ref) else emptyMap())
            previewPlayer.setMediaSource(DefaultMediaSourceFactory(httpFactory).createMediaSource(MediaItem.fromUri(url)))
            previewPlayer.volume = 0f
            previewPlayer.repeatMode = Player.REPEAT_MODE_ALL
            previewPlayer.prepare()
            previewPlayer.playWhenReady = true
        } catch (e: Exception) { /* si falla la vista previa, se deja el recuadro vacío */ }

        // Duración/EN VIVO: se averigua aparte (playlist HLS/DASH), sin bloquear la vista previa.
        Thread {
            val qs = try { MediaProbe.probe(url, ref) } catch (e: Exception) { emptyList() }
            val info = qs.firstOrNull()
            runOnUiThread {
                badge.text = when {
                    info == null -> ""
                    info.isLive -> "🔴 EN VIVO"
                    info.durationSec > 0 -> fmtDuration(info.durationSec)
                    else -> ""
                }
                if (badge.text.isEmpty()) previewFrame.removeView(badge)
            }
        }.start()

        val small = TextView(this)
        small.text = "▶ " + videoName(url)
        small.setTextColor(accent)
        small.textSize = 12f
        small.maxLines = 1
        small.ellipsize = TextUtils.TruncateAt.END
        small.setPadding(0, dp(10), 0, 0)
        box.addView(small)

        fun actionChip(label: String, filled: Boolean, onClick: () -> Unit): TextView {
            val t = TextView(this)
            t.text = label
            t.gravity = Gravity.CENTER
            t.textSize = 13f
            t.setTypeface(t.typeface, Typeface.BOLD)
            t.setTextColor(if (filled) Color.BLACK else accent)
            t.background = if (filled) Ui.filled(accent, dp(20).toFloat())
            else Ui.outline(Color.TRANSPARENT, accent, dp(1), dp(20).toFloat())
            t.setPadding(dp(10), dp(10), dp(10), dp(10))
            t.isClickable = true
            t.isFocusable = true
            t.setOnClickListener { onClick() }
            return t
        }

        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(14) }
        val bDl = actionChip("⭳  Descargar", true) { downloadVideo(url) }
        val bCopy = actionChip("🔗  Copiar enlace", false) {
            copyText("enlace del video", url)
            toast("Enlace del video copiado ✔")
        }
        actions.addView(bDl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val copyLp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        copyLp.marginStart = dp(10)
        actions.addView(bCopy, copyLp)
        box.addView(actions)

        fun cleanupPreview() {
            previewPlayer.release()
        }

        val d = AlertDialog.Builder(this)
            .setTitle("ExoPlayer")
            .setView(box)
            .setPositiveButton("Sí") { _, _ -> cleanupPreview(); openPlayerWeb(url, ref) }
            .setNegativeButton("No") { _, _ -> cleanupPreview(); declineExo(url) }
            .setOnCancelListener { cleanupPreview(); declineExo(url) }
            .setOnDismissListener { cleanupPreview(); askDialog = null }
            .create()
        askDialog = d
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(accent)
        d.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(accent)
    }

    /**
     * "No": ese video se reproduce en la propia página (se recarga una vez). No hay espera ni bloqueo del sitio:
     * el siguiente video que se detecte vuelve a mostrar el aviso de inmediato.
     */
    private fun declineExo(url: String) {
        val plain = url.substringBefore('?').substringBefore('#')
        val key = if (plain.endsWith(".mp4", true)) plain else plain.substringBeforeLast('/') + "/"
        declinedStreams[key] = System.currentTimeMillis()
        lastDeclineHost = AdBlocker.registrable(AdBlocker.host(url))
        lastDeclineTime = System.currentTimeMillis()
        askDialog = null
        if (webView.visibility == View.VISIBLE) webView.reload()
    }

    private fun openPlayer(url: String, referer: String, title: String? = null, fromAgenda: Boolean = false) {
        if (pc.isOpen || isFinishing) return
        pc.setEventsVisible(fromAgenda)
        webView.evaluateJavascript(
            "document.querySelectorAll('video,audio').forEach(function(v){try{v.pause()}catch(e){}})", null
        )
        webView.onPause()
        hideSystemBars(true)
        askNotifPermission()
        pc.open(
            url, referer, webView.settings.userAgentString,
            CookieManager.getInstance().getCookie(url), title ?: videoName(url)
        )
    }

    /** Android 13+: permiso para mostrar la notificación del reproductor (una sola vez). */
    private fun askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 78)
        }
    }

    private fun hideSystemBars(hide: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (hide) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }
}
