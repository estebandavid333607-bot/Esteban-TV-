# Esteban TV

Navegador con reproductor de video integrado. Interfaz negro AMOLED + verde neón.
Hecho por: Esteban Ruiz

- Logo de Google en el inicio: un toque abre Google.
- Cualquier página se puede guardar con la estrella (☆/★) o con "+ Agregar" en el inicio. Al guardar, la app sugiere nombres (por dominio y por el título de la página) y cada favorito muestra el icono de su web. Mantén pulsado un favorito para editarlo o borrarlo.
- Al reabrir la app vuelves a la última página que tenías (se puede apagar en Ajustes).
- Detecta streams .m3u8 / .mpd / .mp4 y, antes de abrir ExoPlayer (Media3), pregunta Sí / No mostrando el video detectado.
- En ExoPlayer: botón de resolución (Auto o una fija, según lo que ofrezca el video) y botón para girar la pantalla.
- Rotación de pantalla: automática por defecto; en Ajustes puedes fijarla vertical, horizontal o seguir el sistema.
- 8 paletas de color (Ajustes > Tema de color).
- Menú ⋮: recargar, adelante, girar, compartir/copiar enlace, abrir en otro navegador, modo escritorio, anuncios, ExoPlayer y **Ajustes** (buscador, tamaño de texto, pantalla completa, mantener encendida, ocultar imágenes, JavaScript, cookies, resolución máxima, borrar datos y más).
- Bloquea popups, popunders y dominios de anuncios (se puede apagar en el menú ⋮).

## Compilar

**Android Studio:** File > Open > carpeta EstebanTV > Run.

**Desde el celular (sin PC):** sube esta carpeta a un repositorio de GitHub. En la pestaña
Actions se ejecuta "Build APK"; al terminar, descarga el artefacto `EstebanTV-apk`
(app-debug.apk) e instálalo.
