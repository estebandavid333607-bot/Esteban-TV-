# Esteban TV

Navegador con reproductor de video integrado. Interfaz negro AMOLED + color a elegir (paleta).
App hecha por Esteban Ruiz.

## Novedades v2.0
- **Rotación de pantalla** (Ajustes): sistema, automática, vertical u horizontal. En ExoPlayer hay botón "Rotar".
- **ExoPlayer con extras**: botón de resolución (lista las calidades disponibles del video), velocidad,
  aspecto, audio/subtítulos, doble toque ±10 s, brillo/volumen deslizando, bloqueo de controles,
  buffer ampliado, reintento y copiar enlace.
- **Aviso antes de ExoPlayer**: ventana Sí / No con el nombre del video en un renglón.
- **Inicio**: logo real de Google; al guardar una web pide el nombre (con sugerencia) y muestra su logotipo.
- **Anti-redirección**: desactivada / solo tras 2 toques / nunca (Ajustes). Menú ⋮ > "Permitir última redirección bloqueada".
- **Ajustes** en ⋮: buscador, texto, imágenes, cookies, última página, pantalla completa, paleta, datos y más.
- **Bienvenida** de 2 segundos al abrir.

## Compilar
**Android Studio:** File > Open > carpeta EstebanTV > Run.

**Desde el celular (sin PC):** sube esta carpeta a GitHub. En Actions se ejecuta "Build APK";
descarga el artefacto `EstebanTV-apk` (app-debug.apk) e instálalo.

## Versión 2.2
- Descargador de video en el menú principal (tarjeta "Descargar video") y "Mis descargas".
- Descargas guardadas en Descargas/EstebanTV, con barra, porcentaje, velocidad y tiempo restante.
- HLS: descarga en paralelo, reintentos y soporte de cifrado AES-128.
- "Redirección bloqueada ✔" sin mostrar la URL; la barra superior solo muestra el eslogan.
- Aviso de ExoPlayer: al pulsar "No", el siguiente video detectado vuelve a preguntar de inmediato; botón "Copiar enlace".

## Versión 2.9
- Recuadro "Agenda 📅" en el menú principal: lee los eventos de Rústico TV (AgendaStore.kt) y los muestra uno por uno, con buscador y botón Actualizar.
- Al tocar un evento se eligen sus canales y se abre el canal dentro de la app (el aviso de ExoPlayer sigue funcionando).
- Si la dirección de la agenda cambia, se edita `URL` en AgendaFetcher (AgendaStore.kt).

## Versión 3.0
- Al abrir un canal de la Agenda, la ventana ahora dice "Cargando señal… X%" con barra de progreso.
- La Agenda suma también los partidos de Dzri TV (dzritv.com/sport/football), cada uno con un solo canal llamado "Stream 1".
- Si un partido está en Rústico TV y en Dzri TV, el de Dzri TV aparece justo debajo con "(opc2)" en el nombre.
- La agenda se ordena por hora (el día de fútbol empieza a las 05:00) y se actualiza más seguido (cada 10–15 min).
- Direcciones editables en `AgendaFetcher`: `URL` (Rústico) y `DZRI_URL` (Dzri).

## Versión 2.10
- Agenda: sección "✅ Terminados" con el resultado final (marcadores de ESPN, ScoreStore.kt) y marcador en los partidos en vivo.
- Agenda: campana 🔔 en cada partido próximo → notificación 10 minutos antes (Reminders.kt). Al tocarla abre la Agenda.
- ExoPlayer: el botón "Eventos 📅" ahora está en la pantalla principal del reproductor, junto a "Avanzados".

## Versión 2.11
- Menú principal: quitadas (ocultas) las tarjetas Descargar video, Mis descargas y TV. El código sigue; Descargar video y Mis descargas se abren desde el menú ⋮. Para volver a mostrar una tarjeta, quita `android:visibility="gone"` en activity_main.xml (dlCard, dlListCard, tvCard).
- Orden: Google, Agenda Fútbol, Páginas Fútbol opc2.

## Versión 2.12
- Agenda Fútbol usa el emoji 🛰️ en vez de 📅. La tarjeta TV sigue oculta.

## Versión 2.13
- Eliminada por completo la función TV (tarjeta, canales, editor y archivos ChannelStore/DefaultChannels).
- El botón Eventos del reproductor ahora usa 🛰️.

## Versión 2.14
- Nuevo recuadro **Películas 🎬** en el menú principal (debajo de Agenda Fútbol): guía de LocoPelis con carátulas (MovieStore.kt).
- Cuadrícula de carátulas con buscador y listas: Inicio, Últimas, Más vistas y categorías. "Cargar más" baja la siguiente página.
- Al tocar una carátula se abre la ficha: carátula grande, año, género, calidad, idioma, sinopsis completa, director y reparto. "Abrir página" abre la película dentro de la app.
- Lo último visto se guarda para mostrarse al instante al abrir.
- Direcciones y categorías editables en `MovieFeeds` (MovieStore.kt); si la web cambia su diseño se ajusta `LIST_JS` / `DETAIL_JS` en `MovieFetcher`.

## Versión 2.15
- Nuevo recuadro **Adultos XXX 🔞** al final del menú principal, protegido con clave (por defecto `0000`, se cambia en `AdultStore.PIN`).
- Muestra los canales de la lista M3U `https://adultiptv.net/chs.m3u` (AdultStore.kt) con logo, buscador y grupos; al tocar un canal se abre en ExoPlayer.
- La última lista descargada se guarda para mostrarla al instante; el botón Actualizar la vuelve a bajar. La dirección se cambia en `AdultStore.URL`.

## Versión 2.16
- Ficha de película: botón **▶ Ver** (arriba de la sinopsis). Abre la página de la película en un WebView invisible, pulsa "Reproductor Opción 1/2" y el botón de play, saca la señal (.m3u8/.mpd/.mp4) y la reproduce directo en ExoPlayer, igual que la Agenda (MovieFetcher.fetchEmbeds + StreamResolver).
- Prueba hasta 3 reproductores; si ninguno da señal, abre la página de la película como antes.
- Si LocoPelis cambia su página y el botón deja de funcionar, se ajusta `EMBED_JS` en MovieStore.kt.

## Versión 2.17
- Películas: si el reproductor pide "haz clic para verificar que eres humano" (o ninguna opción da señal sola), ya no se repite 3 veces el "Cargando señal…". Se abre a pantalla completa el reproductor VISIBLE: tocas ▶ / la verificación y, en cuanto la página pide el video, se cierra y se reproduce en ExoPlayer. Arriba puedes cambiar entre Opción 1, 2, 3, abrir la página o cancelar.

## Versión 2.18
- Películas: solo se escanean 2 reproductores (Opción 1 y 2); la pantalla de verificación muestra solo esas dos opciones (Atrás para salir).
- Películas en pantalla completa; cada vez que se entra salen películas distintas (página al azar en Inicio/categorías; orden al azar en Últimas y Más vistas). Actualizar también trae otras.
- Al cerrar el reproductor de una película se regresa a la lista de películas (misma lista, no al menú principal).

## Versión 2.19
- ExoPlayer: el botón **Eventos 🛰️** solo aparece cuando el video se abrió desde la sección Agenda.

## Versión 2.20
- Películas: la lista es una capa a pantalla completa (sin hueco negro abajo; Atrás la cierra).
- Solo se escanea 1 reproductor (Opción 1).
- Al dar Ver, el video se abre en horizontal; al salir vuelve a la lista de películas en vertical. Solo aplica a películas.

## Versión 2.21
- Al abrir la app aparece 8 segundos una pestaña pequeña abajo: **▶ Seguir viendo** con el título de lo último que viste (película, canal de la Agenda, canal directo o video de una web). Tócala para reanudar; ✕ la cierra; una barrita muestra el tiempo restante.

## Versión 2.22
- Películas: arreglado el hueco negro (la lista mide todo el alto de la pantalla). Se restauró la altura de la lista de canales +18 que se había tocado por error.
- Verificación/reproducción: se bloquean ventanas emergentes y saltos a otros sitios (anuncios/redirecciones) una vez cargado el reproductor.
- Error de señal (BAD_HTTP_STATUS): dice "Intenta nuevamente, cambiaré de señal."; al reintentar en la Agenda busca una señal nueva del canal.

## Versión 2.23
- Adultos: al cerrar ExoPlayer (✕) se regresa al menú de adultos (misma categoría), no al menú principal.

## Versión 1.0 (numeración nueva)
- Se reinicia el número de versión a **1.0**. Todo lo anterior (antes 2.x) queda incluido aquí.
- Regla de aquí en adelante: mejoras pequeñas = 1.1, 1.2, 1.3…; solo se pasa a 2.0 cuando haya un cambio grande.
- Nota técnica: `versionCode` (número interno de Android) también se reinició a **1**. Esta vez hay que **desinstalar la app anterior** antes de instalar la 1.0; de aquí en adelante sube 1, 2, 3… con cada versión y se instala como actualización.

## Versión 1.1
- Películas: el buscador ahora busca en LocoPelis en segundo plano (no solo entre las cargadas).
- Películas: se quitó "Abrir página" (solo Cerrar); si no hay señal, avisa sin abrir la web.
- Películas: las carátulas mantienen su proporción al volver del video (ya no se ven estiradas).
- Películas: al llegar al final de la lista se cargan solas las siguientes (sin botón "Cargar más").
- ExoPlayer: los botones del centro (pausa, ±10 s, anterior/siguiente) ya responden al tocarlos.

## Versión 1.2
- Películas: nueva lista **⏱ Seguir viendo** (primera pestaña). Si sales de una película a medias (X, Atrás, Inicio o cerrar la app) se guarda el minuto; al tocarla puedes continuar desde ahí, verla desde el inicio, ver la ficha o quitarla. Se borra sola al terminar la película.
- Ficha de película: botones **Ver más tarde**, **Continuar desde el minuto…** y **Quitar de Seguir viendo**.
- La pestaña de 8 s al abrir la app también continúa la película en su minuto.

## Versión 1.3
- Reproductor: medidor de red (⚡ + velocidad) en pantalla, sin óvalo (PlayerController.kt).
- Agenda: si no se encuentra la señal de un evento sale "Emisión no disponible 📡" (con botón "Otro canal" si hay más de uno). La web nunca se abre.
- Agenda: los eventos terminados desaparecen 2 horas después de terminar (`EXPIRE_AFTER_MS` en MainActivity). El contador de la tarjeta solo cuenta los vigentes.
- Películas: sin cambios (sigue solo con LocoPelis).

## Versión 1.4
- Películas: al tocar el recuadro sale un menú con **Catálogo 1 (LocoPelis)** y **Catálogo 2 (RePelis24)**. El Catálogo 1 queda exactamente igual (si LocoPelis está caída, al volver funciona solo).
- Catálogo 2 (repelis24.shop): Inicio, Estrenos y géneros, con carátulas, buscador y carga automática de más páginas. Solo muestra películas (las series se ignoran).
- Ficha: la sinopsis empieza después de «… es una película gratis en HD de RePelis24 Online:» (ese texto nunca se copia). Reparto desde los actores de la página.
- Reproductor igual que LocoPelis (ExoPlayer, verificación a la vista si la pide, «Seguir viendo»), con anuncios, ventanas emergentes y redirecciones bloqueados también al leer las páginas de RePelis24 (`PageScraper` con `guard = true`). Prefiere Latino Opción 1; si no hay, Subtitulado.
- Editable en `MovieFeeds` (géneros, búsqueda) y en `LIST_JS_R24` / `DETAIL_JS_R24` / `EMBED_JS_R24` (MovieStore.kt) si la web cambia.

## Versión 1.5
- Películas (los dos catálogos): barra "Cargando reproductor" también en RePelis24; Seguir viendo → Ver ahora ya muestra la barra.
- Solo se prueba 1 opción (la primera) de cada web.
- Ficha: botón "Descargar" (calidad y peso aproximado antes de bajar; se guarda en Descargas/EstebanTV).

## Versión 1.6
- Al abrir Películas, el Catálogo 2 aparece como "Catálogo 2 (puede pedir verificación)".

## Versión 1.7
- Primera vez: aparece "Elige tu color favorito" con la paleta (vista previa al tocar cada color).
- El logo de la TV (inicio y pantalla de arranque) toma el color elegido.

## Versión 1.8
- Verificación de película: el texto de arriba ("Toca ▶…") se quita al tocar el reproductor o cuando el video empieza.
- Descargas: una sola tabla con los colores de la app (calidad, peso y botón Descargar por fila). Se abre al instante, sin abrir el video ni "Cargando reproductor". Sirve para las películas, el botón Descargar del reproductor y la pantalla de pegar enlace.
- Películas (los 2 catálogos): todos los géneros están en un solo botón "Géneros ▾" que abre el menú; al elegir uno el botón muestra su nombre.

## Versión 1.9
- Botón Descargar de la ficha (y del aviso de ExoPlayer): ahora usa un icono propio con el color de la app (el símbolo de texto salía como un cuadro en algunos celulares).
- Buscador del Catálogo 1: prueba varias direcciones de búsqueda a la vez (la normal, la del formulario de la web y otras) y recuerda la que funciona; además acepta resultados aunque sean pocos o con otro diseño. Al escribir salen al instante las películas ya guardadas que coinciden.
- Los 2 catálogos se mantienen (Catálogo 1 y Catálogo 2).

## Versión 1.10
- Películas (los 2 catálogos): se quitó la opción de descargar (botón "Descargar" de la ficha). Las descargas siguen en el menú ⋮ y en el reproductor normal.
- Catálogo 2 (reproductor de la web): cuando el video empieza se ocultan los botones de navegación del celular (se ven al deslizar desde el borde) y la pantalla no se apaga. El Catálogo 1 (ExoPlayer) queda igual.
- Catálogo 2: el reproductor de la web se cortaba a los 2 min 30 s (límite de espera de la verificación). Ahora el límite se quita en cuanto el video empieza (`StreamResolver.holdOpen`).
- Seguir viendo (los 2 catálogos juntos en la misma lista): el reproductor de la web ahora anota el minuto cada 10 s y al salir; "Continuar desde el minuto" salta a ese punto. En ExoPlayer también se guarda si el reproductor no conoce la duración de la película (`saveMovieProgressFor`).

## Versión 1.11
- Catálogo 2: se intenta que el video salga en ExoPlayer como en el Catálogo 1. La pantalla de verificación ahora (1) reconoce más direcciones de video (.m3u8 / .mpd en cualquier parte de la ruta o dentro de un parámetro) y (2) cada segundo mira el `<video>` de la página: si es un video directo de película (más de 10 min) lo abre en ExoPlayer. Si nada de esto sirve, el video sigue en la web como en la 1.10 (con barras ocultas y Seguir viendo).
- La verificación "eres humano" sigue siendo un toque tuyo: no se salta.
- Botón **Info** en la pantalla de verificación: muestra el video que tiene la página y las últimas peticiones de red, con botón Copiar. Sirve para ajustar la detección si aún no pasa a ExoPlayer (`StreamResolver.debugInfo`).
- El Catálogo 1 no cambia (la detección ampliada solo se usa en el modo manual).

## Versión 1.12
- Catálogo 2: la verificación de Cloudflare aparece más rápido.
  - Si la web ya pidió la verificación antes y no hay cookie válida (`cf_clearance`), la ventana se abre de inmediato al tocar el catálogo, sin leer primero la página en segundo plano (`CfGate.needsGate`). La primera vez sigue igual: la app aprende que la web la pide.
  - Cuando sí se lee primero en segundo plano, la espera antes de abrir la ventana bajó de 4 s a 1,5 s (`PageScraper`).
  - Al terminar la verificación, la ventana se cierra un poco antes (revisa cada 0,6 s en vez de 0,8 s).
- Mientras la cookie siga válida no se vuelve a pedir.

## Versión 1.13
- Catálogo 2: arreglo del error `ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED` al abrir en ExoPlayer. Causa probable: la dirección que sacaba la app era una lista HLS/DASH sin `.m3u8` / `.mpd` al final, y ExoPlayer la trataba como un archivo normal. Ahora, si la dirección es "rara", se lee su inicio antes de abrirla y se le indica el tipo real (`StreamResolver.sniffThenFinish`, `PlayerController.forcedMime`).
- Si ExoPlayer falla en una película del Catálogo 2, el aviso muestra el error, la causa y la dirección, y trae el botón **Ver en web**: cierra ExoPlayer y abre esa película en el reproductor de la web (continúa desde el minuto guardado, si lo hay). El Catálogo 1 no cambia.
- El reproductor de la web abierto con "Ver en web" no intenta pasar el video a ExoPlayer (`StreamResolver(handoff = false)`).

## Versión 1.14
- Reproductor (ExoPlayer): nuevo botón **Info** al lado de "Eventos", en todas las secciones (Agenda, Películas, Adultos, enlaces, descargas…). Muestra el título, la dirección del video, Referer, si lleva cookie (sin mostrar su valor), estado, posición, tipo indicado, formato de video y audio, velocidad de red y el último error. Botón **Copiar**.
- Si el video lo encontró el lector de la web (Agenda, Películas), Info también muestra "Cómo se encontró el video": el video que tenía la página y las últimas peticiones de red (`StreamResolver.debugFor`).
- El botón Info de la pantalla de verificación del Catálogo 2 se mantiene.

## Versión 1.15
- Agenda: cuando un canal falla en ExoPlayer (el aviso "No se pudo reproducir"), ya no hay que tocar Reintentar: la app reintenta el mismo canal sola (busca otra señal) y, si vuelve a fallar, pasa al siguiente canal del evento (p. ej. de "Win Sports+" a "Win Sports+ | OP 2"). Si el evento no tiene más canales, o ya se probaron todos, sale el aviso de siempre. Un canal sin señal durante esa cadena también cuenta como fallo. Si un canal llevaba más de 45 s bien, el fallo siguiente empieza la cuenta de cero.
- Agenda: nuevo botón **Canales** en el menú del reproductor (al lado de Eventos / Info), solo cuando el evento tiene más de un canal. Muestra los canales de ese partido (marca con ▶ el que suena) y al tocar uno cambia sin cerrar el reproductor.
- Solo afecta a la Agenda: Películas, Adultos y enlaces no cambian.

## Color RGB 🌈
- Nueva opción "RGB" al final de Ajustes → Paleta de colores (y en la pregunta de la primera vez).
- Recorre todo el espectro (una vuelta cada 5 s). Cada tarjeta del inicio, sus iconos y los favoritos llevan un tono distinto, así se ve una onda de colores como en un teclado gamer.
- Se anima mientras la app está a la vista (≈15 cuadros por segundo) y se detiene al salir. Las ventanas que se abren toman el color del momento.
- Código: objeto `Rgb` y `Prefs.accentColor` (Prefs.kt); animación en `MainActivity` (`startRgb`, `applyAccent(tick)`).

## Buscador del Catálogo 1
- Busca en `https://www.locopelis.com/buscar/?q=texto` (el que usa la propia web).
- Esa página trae arriba películas populares y los resultados al final, debajo de "Resultados para '…'": `SEARCH_JS` (MovieStore.kt) solo toma lo que viene después de ese título.
- Las páginas siguientes prueban `&page=N` y `/buscar/page/N/?q=` a la vez.
