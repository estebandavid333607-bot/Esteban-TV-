# Esteban TV

Navegador con reproductor de video integrado. Interfaz negro AMOLED + color a elegir (paleta).
App hecha por Esteban Ruiz.

## Novedades v2.0
- **Rotación de pantalla** (Ajustes): sistema, automática, vertical u horizontal. En ExoPlayer hay botón "Rotar".
- **ExoPlayer con extras**: botón de resolución (lista las calidades disponibles del video), velocidad,
  aspecto, audio/subtítulos, doble toque ±10 s, brillo/volumen deslizando, bloqueo de controles,
  buffer ampliado, reintento y copiar enlace.
- **Aviso antes de ExoPlayer**: ventana Sí / No con el nombre del video en un renglón.
- **Inicio**: logo real de Google; al guardar una web pide el nombre (con sugerencia) y muestra su logotipo.
- **Anti-redirección**: desactivada / solo tras 2 toques / nunca (Ajustes). Menú ⋮ > "Permitir última redirección bloqueada".
- **Ajustes** en ⋮: buscador, texto, imágenes, cookies, última página, pantalla completa, paleta, datos y más.
- **Bienvenida** de 2 segundos al abrir.

## Compilar
**Android Studio:** File > Open > carpeta EstebanTV > Run.

**Desde el celular (sin PC):** sube esta carpeta a GitHub. En Actions se ejecuta "Build APK";
descarga el artefacto `EstebanTV-apk` (app-debug.apk) e instálalo.

## Versión 2.2
- Descargador de video en el menú principal (tarjeta "Descargar video") y "Mis descargas".
- Descargas guardadas en Descargas/EstebanTV, con barra, porcentaje, velocidad y tiempo restante.
- HLS: descarga en paralelo, reintentos y soporte de cifrado AES-128.
- "Redirección bloqueada ✔" sin mostrar la URL; la barra superior solo muestra el eslogan.
- Aviso de ExoPlayer: al pulsar "No", el siguiente video detectado vuelve a preguntar de inmediato; botón "Copiar enlace".

## Versión 2.9
- Recuadro "Agenda 📅" en el menú principal: lee los eventos de Rústico TV (AgendaStore.kt) y los muestra uno por uno, con buscador y botón Actualizar.
- Al tocar un evento se eligen sus canales y se abre el canal dentro de la app (el aviso de ExoPlayer sigue funcionando).
- Si la dirección de la agenda cambia, se edita `URL` en AgendaFetcher (AgendaStore.kt).

## Versión 3.0
- Al abrir un canal de la Agenda, la ventana ahora dice "Cargando señal… X%" con barra de progreso.
- La Agenda suma también los partidos de Dzri TV (dzritv.com/sport/football), cada uno con un solo canal llamado "Stream 1".
- Si un partido está en Rústico TV y en Dzri TV, el de Dzri TV aparece justo debajo con "(opc2)" en el nombre.
- La agenda se ordena por hora (el día de fútbol empieza a las 05:00) y se actualiza más seguido (cada 10–15 min).
- Direcciones editables en `AgendaFetcher`: `URL` (Rústico) y `DZRI_URL` (Dzri).

## Versión 2.10
- Agenda: sección "✅ Terminados" con el resultado final (marcadores de ESPN, ScoreStore.kt) y marcador en los partidos en vivo.
- Agenda: campana 🔔 en cada partido próximo → notificación 10 minutos antes (Reminders.kt). Al tocarla abre la Agenda.
- ExoPlayer: el botón "Eventos 📅" ahora está en la pantalla principal del reproductor, junto a "Avanzados".
