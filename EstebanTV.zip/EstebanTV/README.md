# Esteban TV

Navegador con reproductor de video integrado. Interfaz negro AMOLED + color a elegir (paleta).
App hecha por Esteban Ruiz.

## Novedades v2.0
- **Rotación de pantalla** (Ajustes): sistema, automática, vertical u horizontal. En ExoPlayer hay botón "Rotar".
- **ExoPlayer con extras**: botón de resolución (lista las calidades disponibles del video), velocidad,
  aspecto, audio/subtítulos, doble toque ±10 s, brillo/volumen deslizando, bloqueo de controles,
  buffer ampliado, reintento y copiar enlace.
- **Aviso antes de ExoPlayer**: ventana Sí / No con el nombre del video en un renglón.
- **Inicio**: logo real de Google; al guardar una web pide el nombre (con sugerencia) y muestra su logotipo.
- **Anti-redirección**: desactivada / solo tras 2 toques / nunca (Ajustes). Menú ⋮ > "Permitir última redirección bloqueada".
- **Ajustes** en ⋮: buscador, texto, imágenes, cookies, última página, pantalla completa, paleta, datos y más.
- **Bienvenida** de 2 segundos al abrir.

## Compilar
**Android Studio:** File > Open > carpeta EstebanTV > Run.

**Desde el celular (sin PC):** sube esta carpeta a GitHub. En Actions se ejecuta "Build APK";
descarga el artefacto `EstebanTV-apk` (app-debug.apk) e instálalo.

## Versión 2.2
- Descargador de video en el menú principal (tarjeta "Descargar video") y "Mis descargas".
- Descargas guardadas en Descargas/EstebanTV, con barra, porcentaje, velocidad y tiempo restante.
- HLS: descarga en paralelo, reintentos y soporte de cifrado AES-128.
- "Redirección bloqueada ✔" sin mostrar la URL; la barra superior solo muestra el eslogan.
- Aviso de ExoPlayer: al pulsar "No", el siguiente video detectado vuelve a preguntar de inmediato; botón "Copiar enlace".

## Versión 2.9
- Recuadro "Agenda 📅" en el menú principal: lee los eventos de Rústico TV (AgendaStore.kt) y los muestra uno por uno, con buscador y botón Actualizar.
- Al tocar un evento se eligen sus canales y se abre el canal dentro de la app (el aviso de ExoPlayer sigue funcionando).
- Si la dirección de la agenda cambia, se edita `URL` en AgendaFetcher (AgendaStore.kt).

## Versión 3.0
- Al abrir un canal de la Agenda, la ventana ahora dice "Cargando señal… X%" con barra de progreso.
- La Agenda suma también los partidos de Dzri TV (dzritv.com/sport/football), cada uno con un solo canal llamado "Stream 1".
- Si un partido está en Rústico TV y en Dzri TV, el de Dzri TV aparece justo debajo con "(opc2)" en el nombre.
- La agenda se ordena por hora (el día de fútbol empieza a las 05:00) y se actualiza más seguido (cada 10–15 min).
- Direcciones editables en `AgendaFetcher`: `URL` (Rústico) y `DZRI_URL` (Dzri).

## Versión 2.10
- Agenda: sección "✅ Terminados" con el resultado final (marcadores de ESPN, ScoreStore.kt) y marcador en los partidos en vivo.
- Agenda: campana 🔔 en cada partido próximo → notificación 10 minutos antes (Reminders.kt). Al tocarla abre la Agenda.
- ExoPlayer: el botón "Eventos 📅" ahora está en la pantalla principal del reproductor, junto a "Avanzados".

## Versión 2.11
- Menú principal: quitadas (ocultas) las tarjetas Descargar video, Mis descargas y TV. El código sigue; Descargar video y Mis descargas se abren desde el menú ⋮. Para volver a mostrar una tarjeta, quita `android:visibility="gone"` en activity_main.xml (dlCard, dlListCard, tvCard).
- Orden: Google, Agenda Fútbol, Páginas Fútbol opc2.

## Versión 2.12
- Agenda Fútbol usa el emoji 🛰️ en vez de 📅. La tarjeta TV sigue oculta.

## Versión 2.13
- Eliminada por completo la función TV (tarjeta, canales, editor y archivos ChannelStore/DefaultChannels).
- El botón Eventos del reproductor ahora usa 🛰️.

## Versión 2.14
- Nuevo recuadro **Películas 🎬** en el menú principal (debajo de Agenda Fútbol): guía de Web 1 con carátulas (MovieStore.kt).
- Cuadrícula de carátulas con buscador y listas: Inicio, Últimas, Más vistas y categorías. "Cargar más" baja la siguiente página.
- Al tocar una carátula se abre la ficha: carátula grande, año, género, calidad, idioma, sinopsis completa, director y reparto. "Abrir página" abre la película dentro de la app.
- Lo último visto se guarda para mostrarse al instante al abrir.
- Direcciones y categorías editables en `MovieFeeds` (MovieStore.kt); si la web cambia su diseño se ajusta `LIST_JS` / `DETAIL_JS` en `MovieFetcher`.

## Versión 2.15
- Nuevo recuadro **Adultos XXX 🔞** al final del menú principal, protegido con clave (por defecto `0000`, se cambia en `AdultStore.PIN`).
- Muestra los canales de la lista M3U `https://adultiptv.net/chs.m3u` (AdultStore.kt) con logo, buscador y grupos; al tocar un canal se abre en ExoPlayer.
- La última lista descargada se guarda para mostrarla al instante; el botón Actualizar la vuelve a bajar. La dirección se cambia en `AdultStore.URL`.

## Versión 2.16
- Ficha de película: botón **▶ Ver** (arriba de la sinopsis). Abre la página de la película en un WebView invisible, pulsa "Reproductor Opción 1/2" y el botón de play, saca la señal (.m3u8/.mpd/.mp4) y la reproduce directo en ExoPlayer, igual que la Agenda (MovieFetcher.fetchEmbeds + StreamResolver).
- Prueba hasta 3 reproductores; si ninguno da señal, abre la página de la película como antes.
- Si Web 1 cambia su página y el botón deja de funcionar, se ajusta `EMBED_JS` en MovieStore.kt.

## Versión 2.17
- Películas: si el reproductor pide "haz clic para verificar que eres humano" (o ninguna opción da señal sola), ya no se repite 3 veces el "Cargando señal…". Se abre a pantalla completa el reproductor VISIBLE: tocas ▶ / la verificación y, en cuanto la página pide el video, se cierra y se reproduce en ExoPlayer. Arriba puedes cambiar entre Opción 1, 2, 3, abrir la página o cancelar.

## Versión 2.18
- Películas: solo se escanean 2 reproductores (Opción 1 y 2); la pantalla de verificación muestra solo esas dos opciones (Atrás para salir).
- Películas en pantalla completa; cada vez que se entra salen películas distintas (página al azar en Inicio/categorías; orden al azar en Últimas y Más vistas). Actualizar también trae otras.
- Al cerrar el reproductor de una película se regresa a la lista de películas (misma lista, no al menú principal).

## Versión 2.19
- ExoPlayer: el botón **Eventos 🛰️** solo aparece cuando el video se abrió desde la sección Agenda.

## Versión 2.20
- Películas: la lista es una capa a pantalla completa (sin hueco negro abajo; Atrás la cierra).
- Solo se escanea 1 reproductor (Opción 1).
- Al dar Ver, el video se abre en horizontal; al salir vuelve a la lista de películas en vertical. Solo aplica a películas.

## Versión 2.21
- Al abrir la app aparece 8 segundos una pestaña pequeña abajo: **▶ Seguir viendo** con el título de lo último que viste (película, canal de la Agenda, canal directo o video de una web). Tócala para reanudar; ✕ la cierra; una barrita muestra el tiempo restante.

## Versión 2.22
- Películas: arreglado el hueco negro (la lista mide todo el alto de la pantalla). Se restauró la altura de la lista de canales +18 que se había tocado por error.
- Verificación/reproducción: se bloquean ventanas emergentes y saltos a otros sitios (anuncios/redirecciones) una vez cargado el reproductor.
- Error de señal (BAD_HTTP_STATUS): dice "Intenta nuevamente, cambiaré de señal."; al reintentar en la Agenda busca una señal nueva del canal.

## Versión 2.23
- Adultos: al cerrar ExoPlayer (✕) se regresa al menú de adultos (misma categoría), no al menú principal.

## Versión 1.0 (numeración nueva)
- Se reinicia el número de versión a **1.0**. Todo lo anterior (antes 2.x) queda incluido aquí.
- Regla de aquí en adelante: mejoras pequeñas = 1.1, 1.2, 1.3…; solo se pasa a 2.0 cuando haya un cambio grande.
- Nota técnica: `versionCode` (número interno de Android) también se reinició a **1**. Esta vez hay que **desinstalar la app anterior** antes de instalar la 1.0; de aquí en adelante sube 1, 2, 3… con cada versión y se instala como actualización.

## Versión 1.1
- Películas: el buscador ahora busca en Web 1 en segundo plano (no solo entre las cargadas).
- Películas: se quitó "Abrir página" (solo Cerrar); si no hay señal, avisa sin abrir la web.
- Películas: las carátulas mantienen su proporción al volver del video (ya no se ven estiradas).
- Películas: al llegar al final de la lista se cargan solas las siguientes (sin botón "Cargar más").
- ExoPlayer: los botones del centro (pausa, ±10 s, anterior/siguiente) ya responden al tocarlos.

## Versión 1.2
- Películas: nueva lista **⏱ Seguir viendo** (primera pestaña). Si sales de una película a medias (X, Atrás, Inicio o cerrar la app) se guarda el minuto; al tocarla puedes continuar desde ahí, verla desde el inicio, ver la ficha o quitarla. Se borra sola al terminar la película.
- Ficha de película: botones **Ver más tarde**, **Continuar desde el minuto…** y **Quitar de Seguir viendo**.
- La pestaña de 8 s al abrir la app también continúa la película en su minuto.

## Películas
- Los textos de la búsqueda ya no nombran la web: "Buscando “nombre”…" y "N resultados".
- La búsqueda usa `/?s=texto` en la página 1 y solo muestra películas cuyo nombre contiene lo escrito.
- Todos los géneros están en un solo botón "Géneros ▾" que despliega un menú.

## Agenda y películas (ajustes)
- Si no se encuentra la señal de un evento sale "Emisión no disponible 📡" (con botón "Otro canal" si hay más de uno). La web nunca se abre.
- Los eventos terminados desaparecen de la Agenda 2 horas después de terminar (`EXPIRE_AFTER_MS` en MainActivity). El contador de la tarjeta solo cuenta los vigentes.
- Películas: la lista guardada se muestra mientras baja la nueva; el lector de la web se presenta como Chrome normal y tiene un respaldo por si la web cambia sus direcciones.

## Películas: Web 1 + Web 3 juntas
- Inicio, Últimas, géneros y búsqueda traen películas de las dos webs a la vez, intercaladas y sin repetir (MovieStore.kt: `MovieFetcher.fetchFeed`).
- Si una web está caída se muestra la otra (se le da 6 s de espera a la más lenta).
- "Más vistas" solo existe en Web 1. Géneros solo de Web 3: Crimen, Estrenos, Familia. Se editan en `MovieFeeds.categories`.
- Direcciones: `MovieSources.LOCO` y `MovieSources.FLIX`.

## Películas repetidas y dos reproductores
- Si una película está en las dos webs sale UNA sola vez en la lista (mismo nombre y año). La dirección de la otra web se guarda en `Movie.alt` (`mergeInto` en MovieStore.kt).
- Al darle "Ver" se analizan los reproductores de las dos webs: Opción 1 (primera web) y Opción 2 (la otra). Si la Opción 1 no da señal se pasa sola a la 2; si ninguna sale sola se muestra la pantalla de verificación con las dos opciones.
- Mientras carga dice "Cargando Opción N… X%" y debajo "Probando el reproductor N de 2".

## Versión 1.3
- Películas: Web 2 usaba las direcciones de Web 1 y por eso no cargaba. Ahora usa las suyas (/peliculas?page=N, /peliculas/populares, /generos/NOMBRE) y solo toma /pelicula/ (no series ni anime).
- Web 1 y Web 2 se leen a la vez en dos WebView invisibles; la primera que responde se muestra al momento y la otra se suma sola.
- Buscador de Web 2: la app lee su formulario la primera vez y recuerda la dirección.
- Reproductor: el medidor de red (rayo + velocidad) ya no lleva óvalo.

## Versión 1.4
- Sinopsis: se busca por orden de fiabilidad (datos estructurados, bloque de sinopsis, texto bajo "Sinopsis", primer párrafo del título) y nunca se toma de los comentarios de usuarios. Si la película está en las dos webs se leen las dos páginas y gana la más fiable. "También conocida como…" sale aparte.
- Buscador: salen al instante las películas ya guardadas que coinciden y se suman las de las webs. La búsqueda de la Web 2 prueba varias direcciones a la vez y recuerda la que funciona. Si nada responde se avisa sin nombrar ninguna web.
- Reproductor: siempre se prueban 2 opciones (1 de cada web, o las 2 primeras si solo hay una web) y luego los extras; en la Web 2 el reproductor "embed69" se prueba primero.
- Ningún mensaje de la app nombra las webs de origen.
