# Esteban TV

Navegador con reproductor de video integrado. Interfaz negro AMOLED + verde neón.
Hecho por: Esteban Ruiz

- Icono de Google en el inicio: un toque abre Google.
- Cualquier página se puede guardar con la estrella (☆/★) o con "+ Agregar" en el inicio. Mantén pulsado un favorito para borrarlo.
- Detecta streams .m3u8 / .mpd / .mp4 y los abre en ExoPlayer (Media3).
- Bloquea popups, popunders y dominios de anuncios (se puede apagar en el menú ⋮).

## Compilar

**Android Studio:** File > Open > carpeta EstebanTV > Run.

**Desde el celular (sin PC):** sube esta carpeta a un repositorio de GitHub. En la pestaña
Actions se ejecuta "Build APK"; al terminar, descarga el artefacto `EstebanTV-apk`
(app-debug.apk) e instálalo.
