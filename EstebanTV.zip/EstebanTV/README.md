# Esteban TV

Navegador con reproductor de video integrado. Interfaz negro AMOLED + color a elegir (paleta).
App hecha por Esteban Ruiz.

## Novedades v2.0
- **Rotación de pantalla** (Ajustes): sistema, automática, vertical u horizontal. En ExoPlayer hay botón "Rotar".
- **ExoPlayer con extras**: botón de resolución (lista las calidades disponibles del video), velocidad,
  aspecto, audio/subtítulos, doble toque ±10 s, brillo/volumen deslizando, bloqueo de controles,
  buffer ampliado, reintento y copiar enlace.
- **Aviso antes de ExoPlayer**: ventana Sí / No con el nombre del video en un renglón.
- **Inicio**: logo real de Google; al guardar una web pide el nombre (con sugerencia) y muestra su logotipo.
- **Anti-redirección**: desactivada / solo tras 2 toques / nunca (Ajustes). Menú ⋮ > "Permitir última redirección bloqueada".
- **Ajustes** en ⋮: buscador, texto, imágenes, cookies, última página, pantalla completa, paleta, datos y más.
- **Bienvenida** de 2 segundos al abrir.

## Compilar
**Android Studio:** File > Open > carpeta EstebanTV > Run.

**Desde el celular (sin PC):** sube esta carpeta a GitHub. En Actions se ejecuta "Build APK";
descarga el artefacto `EstebanTV-apk` (app-debug.apk) e instálalo.

## Versión 2.2
- Descargador de video en el menú principal (tarjeta "Descargar video") y "Mis descargas".
- Descargas guardadas en Descargas/EstebanTV, con barra, porcentaje, velocidad y tiempo restante.
- HLS: descarga en paralelo, reintentos y soporte de cifrado AES-128.
- "Redirección bloqueada ✔" sin mostrar la URL; la barra superior solo muestra el eslogan.
- Aviso de ExoPlayer: al pulsar "No", el siguiente video detectado vuelve a preguntar de inmediato; botón "Copiar enlace".

## Versión 2.9
- Recuadro "Agenda 📅" en el menú principal: lee los eventos de Rústico TV (AgendaStore.kt) y los muestra uno por uno, con buscador y botón Actualizar.
- Al tocar un evento se eligen sus canales y se abre el canal dentro de la app (el aviso de ExoPlayer sigue funcionando).
- Si la dirección de la agenda cambia, se edita `URL` en AgendaFetcher (AgendaStore.kt).

## Versión 3.0
- Al abrir un canal de la Agenda, la ventana ahora dice "Cargando señal… X%" con barra de progreso.
- La Agenda suma también los partidos de Dzri TV (dzritv.com/sport/football), cada uno con un solo canal llamado "Stream 1".
- Si un partido está en Rústico TV y en Dzri TV, el de Dzri TV aparece justo debajo con "(opc2)" en el nombre.
- La agenda se ordena por hora (el día de fútbol empieza a las 05:00) y se actualiza más seguido (cada 10–15 min).
- Direcciones editables en `AgendaFetcher`: `URL` (Rústico) y `DZRI_URL` (Dzri).

## Versión 2.10
- Agenda: sección "✅ Terminados" con el resultado final (marcadores de ESPN, ScoreStore.kt) y marcador en los partidos en vivo.
- Agenda: campana 🔔 en cada partido próximo → notificación 10 minutos antes (Reminders.kt). Al tocarla abre la Agenda.
- ExoPlayer: el botón "Eventos 📅" ahora está en la pantalla principal del reproductor, junto a "Avanzados".

## Versión 2.11
- Menú principal: quitadas (ocultas) las tarjetas Descargar video, Mis descargas y TV. El código sigue; Descargar video y Mis descargas se abren desde el menú ⋮. Para volver a mostrar una tarjeta, quita `android:visibility="gone"` en activity_main.xml (dlCard, dlListCard, tvCard).
- Orden: Google, Agenda Fútbol, Páginas Fútbol opc2.

## Versión 2.12
- Agenda Fútbol usa el emoji 🛰️ en vez de 📅. La tarjeta TV sigue oculta.

## Versión 2.13
- Eliminada por completo la función TV (tarjeta, canales, editor y archivos ChannelStore/DefaultChannels).
- El botón Eventos del reproductor ahora usa 🛰️.

## Versión 2.14
- Nuevo recuadro **Películas 🎬** en el menú principal (debajo de Agenda Fútbol): guía de LocoPelis con carátulas (MovieStore.kt).
- Cuadrícula de carátulas con buscador y listas: Inicio, Últimas, Más vistas y categorías. "Cargar más" baja la siguiente página.
- Al tocar una carátula se abre la ficha: carátula grande, año, género, calidad, idioma, sinopsis completa, director y reparto. "Abrir página" abre la película dentro de la app.
- Lo último visto se guarda para mostrarse al instante al abrir.
- Direcciones y categorías editables en `MovieFeeds` (MovieStore.kt); si la web cambia su diseño se ajusta `LIST_JS` / `DETAIL_JS` en `MovieFetcher`.

## Versión 2.15
- Nuevo recuadro **Adultos XXX 🔞** al final del menú principal, protegido con clave (por defecto `0000`, se cambia en `AdultStore.PIN`).
- Muestra los canales de la lista M3U `https://adultiptv.net/chs.m3u` (AdultStore.kt) con logo, buscador y grupos; al tocar un canal se abre en ExoPlayer.
- La última lista descargada se guarda para mostrarla al instante; el botón Actualizar la vuelve a bajar. La dirección se cambia en `AdultStore.URL`.

## Versión 2.16
- Ficha de película: botón **▶ Ver** (arriba de la sinopsis). Abre la página de la película en un WebView invisible, pulsa "Reproductor Opción 1/2" y el botón de play, saca la señal (.m3u8/.mpd/.mp4) y la reproduce directo en ExoPlayer, igual que la Agenda (MovieFetcher.fetchEmbeds + StreamResolver).
- Prueba hasta 3 reproductores; si ninguno da señal, abre la página de la película como antes.
- Si LocoPelis cambia su página y el botón deja de funcionar, se ajusta `EMBED_JS` en MovieStore.kt.
